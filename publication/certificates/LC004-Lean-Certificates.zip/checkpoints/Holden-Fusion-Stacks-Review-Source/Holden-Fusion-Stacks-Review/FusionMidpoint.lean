import LC004.FusionSeparators
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.Prod

namespace LC004

/-- The first color and one of two allowed successors per step encode a ternary
word of length k+1. Fin.succAbove skips the current color. -/
def ternaryWalk : (k : Nat) → Fin 3 → (Fin k → Fin 2) → List (Fin 3)
  | 0, a, _ => [a]
  | k + 1, a, f => a :: ternaryWalk k (a.succAbove (f 0)) (fun i => f i.succ)

theorem ternaryWalk_head (k : Nat) (a : Fin 3) (f : Fin k → Fin 2) :
    (ternaryWalk k a f).head? = some a := by
  cases k <;> rfl

theorem ternaryWalk_length (k : Nat) (a : Fin 3) (f : Fin k → Fin 2) :
    (ternaryWalk k a f).length = k + 1 := by
  induction k generalizing a with
  | zero => rfl
  | succ k ih => simp [ternaryWalk, ih]

theorem ternaryWalk_proper (k : Nat) (a : Fin 3) (f : Fin k → Fin 2) :
    FusionProper (ternaryWalk k a f) := by
  induction k generalizing a with
  | zero => simp [ternaryWalk, FusionProper]
  | succ k ih =>
    constructor
    · rw [ternaryWalk_head]
      exact fun h => Fin.succAbove_ne _ _ (Option.some.inj h)
    · exact ih _ _

theorem ternaryWalk_code_unique (k : Nat) (a b : Fin 3) (f g : Fin k → Fin 2)
    (h : ternaryWalk k a f = ternaryWalk k b g) : a = b ∧ f = g := by
  induction k generalizing a b with
  | zero => exact ⟨by simpa [ternaryWalk] using h, Subsingleton.elim _ _⟩
  | succ k ih =>
    obtain ⟨hab, ht⟩ := List.cons.inj h
    subst b
    obtain ⟨hhead, htail⟩ := ih _ _ _ _ ht
    refine ⟨rfl, funext ?_⟩
    exact Fin.cases (Fin.succAbove_right_injective hhead) (fun i => congrFun htail i)

/-- A deterministic midpoint state determines the decision on the remaining
m letters. Correctness is assumed only on pairs of equal, prescribed length. -/
theorem proper_midpoint_state_injective {q m : Nat} {State : Type*}
    (mid : List (Fin q) → State) (finish : State → List (Fin q) → Prop)
    (correct : ∀ u v, u.length = m → v.length = m →
      (finish (mid u) v ↔ RawMaxErases (u ++ v) []))
    {x y : List (Fin q)} (hx : FusionProper x) (hy : FusionProper y)
    (lx : x.length = m) (ly : y.length = m)
    (same : mid x.reverse = mid y.reverse) : x = y := by
  have rightWins := (proper_boundary_diagonal y y hy hy).mpr rfl
  have accept := (correct y.reverse y (by simpa using ly) ly).mpr rightWins
  rw [← same] at accept
  exact (proper_boundary_diagonal x y hx hy).mp
    ((correct x.reverse y (by simpa using lx) ly).mp accept)

/-- At least 3*2^(m-1) distinct states actually occur after m ternary letters.
The witness set consists only of reachable midpoint states. The state type may
be infinite and may include a clock or any other deterministic working data. -/
theorem ternary_midpoint_state_bound {m : Nat} (hm : 0 < m) {State : Type*}
    (mid : List (Fin 3) → State) (finish : State → List (Fin 3) → Prop)
    (correct : ∀ u v, u.length = m → v.length = m →
      (finish (mid u) v ↔ RawMaxErases (u ++ v) [])) :
    ∃ Q : Finset State, Q.card = 3 * 2^(m-1) ∧
      ∀ s ∈ Q, ∃ u : List (Fin 3), u.length = m ∧ mid u = s := by
  classical
  cases m with
  | zero => omega
  | succ k =>
    let reversedWalk := fun c : Fin 3 × (Fin k → Fin 2) => (ternaryWalk k c.1 c.2).reverse
    have inj : Function.Injective (fun c => mid (reversedWalk c)) := by
      rintro ⟨a,f⟩ ⟨b,g⟩ h
      have eqWord := proper_midpoint_state_injective mid finish correct
        (ternaryWalk_proper k a f) (ternaryWalk_proper k b g)
        (ternaryWalk_length k a f) (ternaryWalk_length k b g) h
      obtain ⟨rfl,rfl⟩ := ternaryWalk_code_unique k a b f g eqWord
      rfl
    refine ⟨Finset.univ.image (fun c => mid (reversedWalk c)), ?_, ?_⟩
    · rw [Finset.card_image_of_injective _ inj]
      simp
    · intro s hs
      obtain ⟨c, _, rfl⟩ := Finset.mem_image.mp hs
      exact ⟨reversedWalk c, by simp [reversedWalk, ternaryWalk_length], rfl⟩

/-- Direct streaming formulation. Correctness is required only at total length
2*m. No condition is imposed on the recognizer at other input lengths. -/
theorem ternary_one_pass_midpoint_bound {m : Nat} (hm : 0 < m) {State : Type*}
    (initial : State) (step : State → Fin 3 → State) (accept : State → Prop)
    (exactAt : ∀ w : List (Fin 3), w.length = 2 * m →
      (accept (w.foldl step initial) ↔ RawMaxErases w [])) :
    ∃ Q : Finset State, Q.card = 3 * 2^(m-1) ∧
      ∀ s ∈ Q, ∃ u : List (Fin 3), u.length = m ∧ u.foldl step initial = s := by
  apply ternary_midpoint_state_bound hm (fun u => u.foldl step initial)
    (fun s v => accept (v.foldl step s))
  intro u v hu hv
  have hlen : (u ++ v).length = 2 * m := by simp [hu, hv, two_mul]
  simpa only [List.foldl_append] using exactAt (u ++ v) hlen

end LC004
