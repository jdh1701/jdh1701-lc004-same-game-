import LC004.FusionHorizon

namespace LC004

/-- Every directed distinction has a proper witness no longer than the original
suffix.  The witness is a stack in the winning prefix's support alone. -/
theorem shorter_proper_separator {q : Nat} {u v w : List (Fin q)}
    (hu : RawMaxErases (u ++ w) []) (hv : ¬ RawMaxErases (v ++ w) []) :
    ∃ s, FusionProper s ∧ s.length ≤ w.length ∧
      s ∈ fusionReach [] u ∧ s ∉ fusionReach [] v ∧
      RawMaxErases (u ++ s) [] ∧ ¬ RawMaxErases (v ++ s) [] := by
  obtain ⟨s, hs, hw⟩ := (raw_max_win_append_iff_fusion_stack u w).mp hu
  have hp := fusionReach_proper hs
  have hlen : s.length ≤ w.length := by simpa using fusionEval_length_bound hw
  have hmiss : s ∉ fusionReach [] v := by
    intro h
    exact hv ((raw_max_win_append_iff_fusion_stack v w).mpr ⟨s, h, hw⟩)
  exact ⟨s, hp, hlen, hs, hmiss,
    (raw_max_win_append_proper_iff u s hp).mpr hs,
    fun h => hmiss ((raw_max_win_append_proper_iff v s hp).mp h)⟩

/-- Proper stacks and proper test words index an identity submatrix of the
word-boundary indicator. Both arguments are in top-first convention. -/
theorem proper_boundary_diagonal {q : Nat} (s t : List (Fin q))
    (hs : FusionProper s) (ht : FusionProper t) :
    RawMaxErases (s.reverse ++ t) [] ↔ s = t := by
  rw [raw_max_win_append_proper_iff _ _ ht, mem_fusionReach_iff]
  constructor
  · intro h
    have back : FusionEval t s [] := by
      simpa using fusionEval_reverse h (by trivial)
    exact ((fusionEval_proper_accept_iff t s hs).mp back).symm
  · rintro rfl
    exact fusionEval_reverse (fusionEval_pop_all s) hs

end LC004
