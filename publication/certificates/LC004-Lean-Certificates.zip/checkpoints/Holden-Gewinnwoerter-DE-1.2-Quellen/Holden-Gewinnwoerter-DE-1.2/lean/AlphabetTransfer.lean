import LC004.ConnectedCoefficientInterpolation
import LC004.WinningDiagonalBridge
import Mathlib.LinearAlgebra.Lagrange

/-! Reconstruction of the original labeled counts from a finite alphabet-by-length table. -/

namespace LC004
open scoped BigOperators Classical

/-- Evaluate the noncrossing moment sum at a sequence of connected weights. -/
noncomputable def ncMoment {R : Type*} [CommSemiring R] (k : Nat → R) (s : Nat) : R :=
  ∑ p : ColorPattern s, if PatternNoncrossing p then
    ∏ a : Quotient p, k (patternQuotientFiber p a).card else 0

private theorem fiber_pos {s : Nat} (p : ColorPattern s) (a : Quotient p) :
    0 < (patternQuotientFiber p a).card :=
  Finset.card_pos.mpr ⟨a.out, (mem_patternQuotientFiber p a _).mpr a.out_eq⟩

private theorem fiber_lt_of_proper {s : Nat} {p : ColorPattern s} (hp : p ≠ ⊤)
    (a : Quotient p) : (patternQuotientFiber p a).card < s := by
  by_contra! h
  have he := Finset.eq_univ_of_card (patternQuotientFiber p a)
    (by simpa using le_antisymm (card_finset_fin_le _) h)
  have hall (i : Fin s) : Quotient.mk p i = a :=
    (mem_patternQuotientFiber p a i).mp (he ▸ Finset.mem_univ i)
  exact hp (top_unique fun {i j} _ => Quotient.exact ((hall i).trans (hall j).symm))

private theorem top_term {s : Nat} (hs : 0 < s) (k : Nat → Int) :
    (if PatternNoncrossing (⊤ : ColorPattern s) then
      ∏ a : Quotient (⊤ : ColorPattern s), k (patternQuotientFiber ⊤ a).card else 0) = k s := by
  classical
  let p : ColorPattern s := ⊤
  let a := Quotient.mk p (⟨0,hs⟩ : Fin s)
  have allEq (x y : Quotient p) : x = y :=
    Quotient.inductionOn₂ x y (fun _ _ => Quotient.sound trivial)
  letI : Unique (Quotient p) := ⟨⟨a⟩, fun x => allEq x a⟩
  have hnc : PatternNoncrossing p := fun _ _ _ _ _ _ _ _ _ => trivial
  have hf : patternQuotientFiber p a = Finset.univ := by
    ext i
    simp [allEq (Quotient.mk p i) a]
  change (if PatternNoncrossing p then ∏ x : Quotient p, k (patternQuotientFiber p x).card
    else 0) = k s
  rw [if_pos hnc, Fintype.prod_unique]
  change k (patternQuotientFiber p a).card = k s
  simp [hf]

/-- Invert a column of moments by subtracting the proper-partition terms.
The zero-length connected weight is unused and is set to zero. -/
noncomputable def invertMomentColumn (m : Nat → Int) (s : Nat) : Int :=
  if s = 0 then 0 else m s -
    ∑ p ∈ (Finset.univ : Finset (ColorPattern s)).erase ⊤,
      if PatternNoncrossing p then ∏ a : Quotient p,
        let j := (patternQuotientFiber p a).card
        if _h : j < s then invertMomentColumn m j else 0
      else 0
termination_by s

theorem invertMomentColumn_correct (m k : Nat → Int) {n : Nat}
    (hm : ∀ s, 0 < s → s ≤ n → m s = ncMoment k s) :
    ∀ s, 0 < s → s ≤ n → invertMomentColumn m s = k s := by
  classical
  intro s
  induction s using Nat.strong_induction_on with
  | h s ih =>
    intro hs hsn
    rw [invertMomentColumn, if_neg (Nat.ne_of_gt hs), hm s hs hsn, ncMoment]
    rw [← Finset.sum_erase_add _ _ (Finset.mem_univ (⊤ : ColorPattern s)), top_term hs]
    have hproper : (∑ p ∈ (Finset.univ : Finset (ColorPattern s)).erase ⊤,
        if PatternNoncrossing p then ∏ a : Quotient p, k (patternQuotientFiber p a).card else 0) =
      ∑ p ∈ (Finset.univ : Finset (ColorPattern s)).erase ⊤,
        if PatternNoncrossing p then ∏ a : Quotient p,
          if h : (patternQuotientFiber p a).card < s then
            invertMomentColumn m (patternQuotientFiber p a).card else 0 else 0 := by
      apply Finset.sum_congr rfl
      intro p hp
      split_ifs
      · apply Finset.prod_congr rfl
        intro a _
        have lt := fiber_lt_of_proper (Finset.ne_of_mem_erase hp) a
        rw [dif_pos lt, ih _ lt (fiber_pos p a) (le_trans lt.le hsn)]
      · rfl
    rw [hproper]
    exact add_sub_cancel_left _ _

/-- Entry (i,j) records the winning count on i+1 colors at length j+1. -/
abbrev AlphabetSamples (n : Nat) := Fin (max 1 (n / 5)) → Fin n → Nat

private def sampleColumn {n : Nat} (data : AlphabetSamples n) (b s : Nat) : Int :=
  if h : 0 < b ∧ b ≤ max 1 (n / 5) ∧ 0 < s ∧ s ≤ n then
    data ⟨b-1, by omega⟩ ⟨s-1, by omega⟩ else 0

/-- Reconstruct a connected polynomial over the rationals from finite count data.
Zero is a known node from the constant-term theorem and consumes no table entry. -/
noncomputable def interpolateConnected {n : Nat} (data : AlphabetSamples n) (s : Nat) :
    Polynomial ℚ :=
  Lagrange.interpolate (Finset.range (max 1 (n / 5) + 1)) (fun b : Nat => (b : ℚ))
    (fun b => if b = 0 then 0 else (invertMomentColumn (sampleColumn data b) s : ℚ))

theorem interpolateConnected_correct {n : Nat} (data : AlphabetSamples n)
    (hd : ∀ i j, data i j = labeledWinningCount (i.val+1) (j.val+1))
    {s : Nat} (hs : 0 < s) (hsn : s ≤ n) :
    interpolateConnected data s = (connectedGamePolynomial s).map (Int.castRingHom ℚ) := by
  classical
  symm
  apply Lagrange.eq_interpolate_of_eval_eq
  · intro i _ j _ hij
    change (i : ℚ) = (j : ℚ) at hij
    exact_mod_cast hij
  · rw [Finset.card_range]
    apply lt_of_le_of_lt Polynomial.degree_le_natDegree
    apply WithBot.coe_lt_coe.mpr
    have hdeg := (Polynomial.natDegree_map_le (f := Int.castRingHom ℚ)
      (p := connectedGamePolynomial s)).trans (connectedGamePolynomial_natDegree_le s)
    exact_mod_cast Nat.lt_succ_of_le (hdeg.trans (max_le_max_left 1 (Nat.div_le_div_right hsn)))
  · intro b hb
    have hb' := Finset.mem_range.mp hb
    change ((connectedGamePolynomial s).map (Int.castRingHom ℚ)).eval (b : ℚ) = _
    rw [Polynomial.eval_map, Polynomial.eval₂_at_natCast]
    split_ifs with hz
    · subst b
      simp [← Polynomial.coeff_zero_eq_eval_zero, connectedGamePolynomial_constant_zero s hs]
    · have hcol : ∀ j, 0 < j → j ≤ n → sampleColumn data b j =
          ncMoment (connectedGameWeight (b : Int)) j := by
        intro j hj hjn
        have hvalid : 0 < b ∧ b ≤ max 1 (n/5) ∧ 0 < j ∧ j ≤ n := by omega
        rw [sampleColumn, dif_pos hvalid, hd]
        simpa [Nat.sub_add_cancel (Nat.one_le_iff_ne_zero.mpr hz),
          Nat.sub_add_cancel hj] using labeledWinningCount_connected_expansion b j
      rw [invertMomentColumn_correct _ _ hcol s hs hsn, connectedGamePolynomial_eval]
      rfl

/-- The reconstructed ordinary winning-count polynomial at length n. -/
noncomputable def alphabetTransfer {n : Nat} (data : AlphabetSamples n) : Polynomial ℚ :=
  ncMoment (interpolateConnected data) n

/-- The counts at positive lengths through n on 1,...,max(1,⌊n/5⌋) colors
determine the count on every finite alphabet, including the empty alphabet. -/
theorem alphabetTransfer_correct {n : Nat} (data : AlphabetSamples n)
    (hd : ∀ i j, data i j = labeledWinningCount (i.val+1) (j.val+1)) (b : Nat) :
    (alphabetTransfer data).eval (b : ℚ) = (labeledWinningCount b n : ℚ) := by
  classical
  have h := congrArg (Int.castRingHom ℚ) (labeledWinningCount_connected_expansion b n)
  simp only [map_sum, apply_ite (Int.castRingHom ℚ), map_prod, map_zero] at h
  rw [show (labeledWinningCount b n : ℚ) = (Int.castRingHom ℚ) (labeledWinningCount b n : Int)
    by simp, h]
  unfold alphabetTransfer ncMoment
  rw [Polynomial.eval_finset_sum]
  apply Finset.sum_congr rfl
  intro p _
  split_ifs
  · rw [Polynomial.eval_prod]
    apply Finset.prod_congr rfl
    intro a _
    rw [interpolateConnected_correct data hd (fiber_pos p a)
      (card_finset_fin_le _), Polynomial.eval_map, Polynomial.eval₂_at_natCast,
      connectedGamePolynomial_eval]
  · simp

/-- At length zero the table has no entries; there is one winning empty word. -/
theorem labeledWinningCount_empty (b : Nat) : labeledWinningCount b 0 = 1 := by
  let f : Fin 0 → Fin b := Fin.elim0
  have hf : RawMaxErases (List.ofFn f) [] := by simpa using (RawMaxErases.refl ([] : List (Fin b)))
  letI : Unique {g : Fin 0 → Fin b // RawMaxErases (List.ofFn g) []} :=
    uniqueOfSubsingleton ⟨f, hf⟩
  exact Nat.card_unique

/-- The interpolant is the integer winning polynomial embedded in ℚ[X]. -/
theorem alphabetTransfer_eq_winningPolynomial {n : Nat} (data : AlphabetSamples n)
    (hd : ∀ i j, data i j = labeledWinningCount (i.val+1) (j.val+1)) :
    alphabetTransfer data = (WinningDiagonal.winningPolynomial n).map (Int.castRingHom ℚ) := by
  apply Polynomial.eq_of_infinite_eval_eq
  have hi : Set.Infinite (Set.range (fun b : Nat => (b : ℚ))) :=
    Set.infinite_range_of_injective (fun a b h => by exact_mod_cast h)
  apply hi.mono
  rintro _ ⟨b, rfl⟩
  change (alphabetTransfer data).eval (b : ℚ) = _
  rw [alphabetTransfer_correct data hd, Polynomial.eval_map, Polynomial.eval₂_at_natCast,
    WinningDiagonal.winningPolynomial_eval_count]
  simp

#print axioms invertMomentColumn_correct
#print axioms interpolateConnected_correct
#print axioms alphabetTransfer_eq_winningPolynomial
#print axioms alphabetTransfer_correct
#print axioms labeledWinningCount_empty
end LC004
