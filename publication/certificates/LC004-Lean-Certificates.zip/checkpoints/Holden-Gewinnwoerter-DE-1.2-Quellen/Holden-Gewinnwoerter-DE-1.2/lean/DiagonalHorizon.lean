import Lean

namespace LC004.Diagonal

def Admissible (b : Nat × Nat) : Prop :=
  2 ≤ b.1 ∧ 1 ≤ b.2 ∧ (2 ≤ b.2 → 5 * b.2 ≤ b.1)

def deficit (b : Nat × Nat) : Nat := b.1 - 2 * b.2

theorem twice_degree_le_size {b : Nat × Nat} (h : Admissible b) : 2 * b.2 ≤ b.1 := by
  rcases h with ⟨hs, he, hw⟩
  by_cases h₂ : 2 ≤ b.2
  · have := hw h₂
    omega
  · omega

theorem connected_block_horizon {b : Nat × Nat} (h : Admissible b)
    {δ : Nat} (hd : deficit b ≤ δ) :
    b.2 ≤ max 1 (δ / 3) ∧ b.1 ≤ δ + 2 * max 1 (δ / 3) := by
  have hl := twice_degree_le_size h
  have add := Nat.sub_add_cancel hl
  change b.1 - 2 * b.2 ≤ δ at hd
  have hE : b.2 ≤ max 1 (δ / 3) := by
    by_cases h₂ : 2 ≤ b.2
    · have hw := h.2.2 h₂
      exact Nat.le_trans (show b.2 ≤ δ / 3 by omega) (Nat.le_max_right _ _)
    · exact Nat.le_trans (show b.2 ≤ 1 by omega) (Nat.le_max_left _ _)
  exact ⟨hE, by omega⟩

theorem low_deficit_type {b : Nat × Nat} (h : Admissible b)
    (hd : deficit b ≤ 2) : b.2 = 1 ∧ b.1 = 2 + deficit b := by
  have hl := twice_degree_le_size h
  have add := Nat.sub_add_cancel hl
  have he := (connected_block_horizon h hd).1
  have hp := h.2.1
  change b.2 ≤ 1 at he
  change b.1 - 2 * b.2 ≤ 2 at hd
  change b.2 = 1 ∧ b.1 = 2 + (b.1 - 2 * b.2)
  omega

theorem profile_deficit_add (bs : List (Nat × Nat)) (h : ∀ b ∈ bs, Admissible b) :
    (bs.map deficit).sum + 2 * (bs.map Prod.snd).sum = (bs.map Prod.fst).sum := by
  induction bs with
  | nil => rfl
  | cons a bs ih =>
    have ha := twice_degree_le_size (h a (by simp))
    have hb := ih (fun b hb => h b (by simp [hb]))
    simp only [List.map_cons, List.sum_cons, deficit] at *
    omega

theorem member_deficit_le (bs : List (Nat × Nat)) {b : Nat × Nat} (hb : b ∈ bs) :
    deficit b ≤ (bs.map deficit).sum := by
  induction bs with
  | nil => simp at hb
  | cons a bs ih =>
    simp only [List.mem_cons] at hb
    simp only [List.map_cons, List.sum_cons]
    rcases hb with rfl | hb
    · omega
    · have := ih hb
      omega

theorem profile_block_horizon (bs : List (Nat × Nat))
    (h : ∀ b ∈ bs, Admissible b) {δ : Nat}
    (ht : (bs.map Prod.fst).sum ≤ 2 * (bs.map Prod.snd).sum + δ)
    {b : Nat × Nat} (hb : b ∈ bs) :
    b.2 ≤ max 1 (δ / 3) ∧ b.1 ≤ δ + 2 * max 1 (δ / 3) := by
  have heq := profile_deficit_add bs h
  have hm := member_deficit_le bs hb
  exact connected_block_horizon (h b hb) (by omega)

theorem maximal_exceptional_profile (bs : List (Nat × Nat))
    (h : ∀ b ∈ bs, Admissible b ∧ 1 ≤ deficit b) :
    bs.length ≤ (bs.map deficit).sum ∧
      (bs.length = (bs.map deficit).sum → ∀ b ∈ bs, b = (3, 1)) := by
  induction bs with
  | nil => simp
  | cons a bs ih =>
    have ha := h a (by simp)
    have ht := ih (fun b hb => h b (by simp [hb]))
    simp only [List.length_cons, List.map_cons, List.sum_cons]
    refine ⟨by have := ht.1; have := ha.2; omega, ?_⟩
    intro heq b hb
    have hOne : deficit a = 1 := by have := ht.1; have := ha.2; omega
    have htEq : bs.length = (bs.map deficit).sum := by omega
    simp only [List.mem_cons] at hb
    rcases hb with hb | hb
    · subst b
      have hLow := low_deficit_type ha.1 (by omega : deficit a ≤ 2)
      apply Prod.ext
      · change a.1 = 3
        omega
      · exact hLow.1
    · exact ht.2 htEq b hb

theorem horizon_caps_connected_degree_bound {s δ : Nat}
    (hs : s ≤ δ + 2 * max 1 (δ / 3)) :
    max 1 (s / 5) ≤ max 1 (δ / 3) := by
  have h1 : 1 ≤ max 1 (δ / 3) := Nat.le_max_left _ _
  have h2 : δ / 3 ≤ max 1 (δ / 3) := Nat.le_max_right _ _
  have hd : δ ≤ 3 * max 1 (δ / 3) + 2 := by omega
  have h3 : s / 5 ≤ max 1 (δ / 3) := by omega
  omega

theorem unique_small_deficit {s e δ : Nat} (he : 0 < e)
    (hs : s = 2 * e + δ) (hδ : δ < 6)
    (hSupport : 2 ≤ e → 5 * e ≤ s) : e = 1 ∧ s = δ + 2 := by
  by_cases h : 2 ≤ e
  · have := hSupport h
    omega
  · omega

#print axioms horizon_caps_connected_degree_bound
#print axioms unique_small_deficit

theorem near_maximal_exceptional_profile (bs : List (Nat × Nat))
    (h : ∀ b ∈ bs, Admissible b ∧ 1 ≤ deficit b)
    (ht : bs.length + 1 = (bs.map deficit).sum) :
    ∃ pre post : List (Nat × Nat),
      bs = pre ++ (4, 1) :: post ∧ ∀ b ∈ pre ++ post, b = (3, 1) := by
  induction bs with
  | nil => simp at ht
  | cons a bs ih =>
    have ha := h a (by simp)
    have hbs : ∀ b ∈ bs, Admissible b ∧ 1 ≤ deficit b :=
      fun b hb => h b (by simp [hb])
    have hm := maximal_exceptional_profile bs hbs
    have hd := ha.2
    simp only [List.length_cons, List.map_cons, List.sum_cons] at ht
    have ha2 : deficit a ≤ 2 := by have := hm.1; omega
    have hl := low_deficit_type ha.1 ha2
    by_cases ha1 : deficit a = 1
    · have hae : a = (3,1) := by
        apply Prod.ext
        · change a.1 = 3
          omega
        · exact hl.1
      have hbEq : bs.length + 1 = (bs.map deficit).sum := by omega
      obtain ⟨pre, post, hEq, hRest⟩ := ih hbs hbEq
      refine ⟨a :: pre, post, ?_, ?_⟩
      · exact congrArg (List.cons a) hEq
      · intro b hb
        simp only [List.cons_append, List.mem_cons] at hb
        rcases hb with hh | hh
        · exact hh.trans hae
        · exact hRest b hh
    · have hae : a = (4,1) := by
        apply Prod.ext
        · change a.1 = 4
          omega
        · exact hl.1
      have hbEq : bs.length = (bs.map deficit).sum := by omega
      exact ⟨[], bs, congrArg (fun z => z :: bs) hae,
        fun b hb => hm.2 hbEq b hb⟩

example : 6 + 2 * max 1 (6 / 3) = 10 := by decide
example : 7 + 2 * max 1 (7 / 3) = 11 := by decide

#print axioms near_maximal_exceptional_profile

#print axioms connected_block_horizon
#print axioms profile_block_horizon
#print axioms maximal_exceptional_profile


/-- Coefficient of the product of the block polynomials, defined by convolution. -/
def productCoeff (c : Nat → Nat → Int) : List Nat → Nat → Int
  | [], d => if d = 0 then 1 else 0
  | s :: ss, d => ((List.range (d + 1)).map
      (fun e => c s e * productCoeff c ss (d - e))).sum

private theorem list_sum_map_eq_zero {α : Type} (xs : List α) (f : α → Int)
    (hf : ∀ x ∈ xs, f x = 0) : (xs.map f).sum = 0 := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.map_cons, List.sum_cons]
    rw [hf x (by simp), ih (fun y hy => hf y (by simp [hy]))]
    decide

theorem productCoeff_witness (c : Nat → Nat → Int) (ss : List Nat) (d : Nat)
    (hne : productCoeff c ss d ≠ 0) :
    ∃ bs : List (Nat × Nat), bs.map Prod.fst = ss ∧ (bs.map Prod.snd).sum = d ∧
      ∀ b ∈ bs, c b.1 b.2 ≠ 0 := by
  induction ss generalizing d with
  | nil =>
    have hd : d = 0 := by
      apply Classical.byContradiction
      intro hn
      exact hne (by simp [productCoeff, hn])
    subst d
    exact ⟨[], rfl, rfl, by simp⟩
  | cons s ss ih =>
    have hw : ∃ e ∈ List.range (d + 1), c s e * productCoeff c ss (d - e) ≠ 0 := by
      apply Classical.byContradiction
      intro hn
      apply hne
      unfold productCoeff
      apply list_sum_map_eq_zero
      intro e he
      apply Classical.byContradiction
      intro hez
      exact hn ⟨e,he,hez⟩
    obtain ⟨e,he,hn⟩ := hw
    have hel : e < d + 1 := List.mem_range.mp he
    have hce : c s e ≠ 0 := by intro hz; exact hn (by simp [hz])
    have hrest : productCoeff c ss (d - e) ≠ 0 := by intro hz; exact hn (by simp [hz])
    obtain ⟨bs, hs, ht, hc⟩ := ih (d - e) hrest
    refine ⟨(s,e) :: bs, by simp [hs], ?_, ?_⟩
    · simp only [List.map_cons, List.sum_cons, ht]
      omega
    · intro b hb
      simp only [List.mem_cons] at hb
      rcases hb with rfl | hb
      · exact hce
      · exact hc b hb

theorem productCoeff_vanishes_above_horizon (c : Nat → Nat → Int) (ss : List Nat)
    (hcap : ∀ s ∈ ss, ∀ e, c s e ≠ 0 → Admissible (s,e))
    {d δ : Nat} (ht : ss.sum ≤ 2 * d + δ)
    {s : Nat} (hs : s ∈ ss) (hl : δ + 2 * max 1 (δ / 3) < s) :
    productCoeff c ss d = 0 := by
  apply Classical.byContradiction
  intro hn
  obtain ⟨bs, hs', hd, hc⟩ := productCoeff_witness c ss d hn
  have hmem : s ∈ bs.map Prod.fst := by rw [hs']; exact hs
  obtain ⟨b,hb,hbe⟩ := List.mem_map.mp hmem
  have had : ∀ q ∈ bs, Admissible q := by
    intro q hq
    have hm : q.1 ∈ ss := by
      rw [← hs']
      exact List.mem_map.mpr ⟨q,hq,rfl⟩
    exact hcap q.1 hm q.2 (hc q hq)
  have htd : (bs.map Prod.fst).sum ≤ 2 * (bs.map Prod.snd).sum + δ := by
    rw [hs', hd]; exact ht
  have hbnd := (profile_block_horizon bs had htd hb).2
  change b.1 = s at hbe
  omega

theorem productCoeff_congr (c c' : Nat → Nat → Int) (ss : List Nat) (d : Nat)
    (h : ∀ s ∈ ss, ∀ e, c s e = c' s e) :
    productCoeff c ss d = productCoeff c' ss d := by
  induction ss generalizing d with
  | nil => rfl
  | cons s ss ih =>
    simp only [productCoeff]
    have hs := h s (by simp)
    have hss : ∀ d, productCoeff c ss d = productCoeff c' ss d :=
      fun k => ih k (fun s hs => h s (by simp [hs]))
    simp only [hs, hss]

/-- Uniform finite transfer: only bounded-size block coefficients can affect the
target of a profile product, regardless of the total list length. -/
theorem productCoeff_transfer (c c' : Nat → Nat → Int) (ss : List Nat) {d δ : Nat}
    (hc : ∀ s ∈ ss, ∀ e, c s e ≠ 0 → Admissible (s,e))
    (hc' : ∀ s ∈ ss, ∀ e, c' s e ≠ 0 → Admissible (s,e))
    (ht : ss.sum ≤ 2 * d + δ)
    (heq : ∀ s ≤ δ + 2 * max 1 (δ / 3), ∀ e, c s e = c' s e) :
    productCoeff c ss d = productCoeff c' ss d := by
  by_cases hb : ∃ s ∈ ss, δ + 2 * max 1 (δ / 3) < s
  · obtain ⟨s,hs,hl⟩ := hb
    rw [productCoeff_vanishes_above_horizon c ss hc ht hs hl,
      productCoeff_vanishes_above_horizon c' ss hc' ht hs hl]
  · apply productCoeff_congr
    intro s hs e
    exact heq s (by
      apply Classical.byContradiction
      intro nh
      exact hb ⟨s,hs,by omega⟩) e

#print axioms productCoeff_witness
#print axioms productCoeff_vanishes_above_horizon
#print axioms productCoeff_transfer


/-- Near the top, terms above a prescribed connected degree have no effect. -/
theorem productCoeff_degree_truncation (c : Nat → Nat → Int) (ss : List Nat)
    {d δ r : Nat} (hr : 1 ≤ r)
    (hc : ∀ s e, c s e ≠ 0 → Admissible (s,e))
    (ht : ss.sum ≤ 2 * d + δ) (hδ : δ < 3 * (r + 1)) :
    productCoeff c ss d = productCoeff (fun s e => if e ≤ r then c s e else 0) ss d := by
  refine productCoeff_transfer c _ ss (fun s _ e => hc s e) ?_ ht ?_
  · intro s _ e hn
    by_cases he : e ≤ r
    · exact hc s e (by simpa [he] using hn)
    · simp [he] at hn
  · intro s hs e
    by_cases he : e ≤ r
    · simp [he]
    · suffices hz : c s e = 0 by simp [he, hz]
      apply Classical.byContradiction
      intro hn
      have had := hc s e hn
      have hE : max 1 (δ / 3) ≤ r := by
        have he' : δ / 3 ≤ r := by omega
        omega
      have hEs := horizon_caps_connected_degree_bound hs
      have h₅ := had.2.2 (show 2 ≤ e by omega)
      change 5 * e ≤ s at h₅
      have hse : e ≤ s / 5 := by omega
      omega

#print axioms productCoeff_degree_truncation


def momentCoeff (c : Nat → Nat → Int) (profiles : List (List Nat)) (d : Nat) : Int :=
  (profiles.map (fun ss => productCoeff c ss d)).sum

/-- The cutoff survives summation over any family of block partitions. -/
theorem momentCoeff_degree_truncation (c : Nat → Nat → Int) (profiles : List (List Nat))
    {n d r : Nat} (hr : 1 ≤ r)
    (hc : ∀ s e, c s e ≠ 0 → Admissible (s,e))
    (hs : ∀ ss ∈ profiles, ss.sum = n)
    (hn : n < 2 * d + 3 * (r + 1)) :
    momentCoeff c profiles d = momentCoeff (fun s e => if e ≤ r then c s e else 0) profiles d := by
  unfold momentCoeff
  have hmaps : ∀ xs : List (List Nat), (∀ ss ∈ xs, ss.sum = n) →
      xs.map (fun ss => productCoeff c ss d) =
      xs.map (fun ss => productCoeff (fun s e => if e ≤ r then c s e else 0) ss d) := by
    intro xs
    induction xs with
    | nil => intro _; rfl
    | cons ss xs ih =>
      intro hx
      simp only [List.map_cons]
      congr 1
      · have hsn := hx ss (by simp)
        exact productCoeff_degree_truncation c ss (δ := n - 2 * d) hr hc
          (by omega) (by omega)
      · exact ih (fun t ht => hx t (by simp [ht]))
  rw [hmaps profiles hs]

theorem momentCoeff_linear_for_top_three (c : Nat → Nat → Int)
    (profiles : List (List Nat)) {n k j : Nat}
    (hn : n = 2 * k ∨ n = 2 * k + 1) (hj : j ≤ 2)
    (hc : ∀ s e, c s e ≠ 0 → Admissible (s,e))
    (hs : ∀ ss ∈ profiles, ss.sum = n) :
    momentCoeff c profiles (k-j) =
      momentCoeff (fun s e => if e ≤ 1 then c s e else 0) profiles (k-j) :=
  momentCoeff_degree_truncation c profiles (by decide) hc hs (by omega)

#print axioms momentCoeff_degree_truncation
#print axioms momentCoeff_linear_for_top_three


def nonlinearIndicator (b : Nat × Nat) : Nat := if 2 ≤ b.2 then 1 else 0

/-- Each nonlinear connected factor consumes at least six units of deficit. -/
theorem nonlinear_profile_budget (bs : List (Nat × Nat))
    (h : ∀ b ∈ bs, Admissible b) :
    6 * (bs.map nonlinearIndicator).sum ≤ (bs.map deficit).sum := by
  induction bs with
  | nil => decide
  | cons b bs ih =>
    have hb := h b (by simp)
    have ht := ih (fun a ha => h a (by simp [ha]))
    simp only [List.map_cons, List.sum_cons, nonlinearIndicator]
    by_cases he : 2 ≤ b.2
    · have h5 := hb.2.2 he
      have hd : 6 ≤ deficit b := by unfold deficit; omega
      simp only [if_pos he]
      omega
    · simp only [if_neg he, Nat.zero_add]
      omega

theorem nonlinear_profile_count_le (bs : List (Nat × Nat))
    (h : ∀ b ∈ bs, Admissible b) {δ : Nat}
    (ht : (bs.map Prod.fst).sum ≤ 2 * (bs.map Prod.snd).sum + δ) :
    (bs.map nonlinearIndicator).sum ≤ δ / 6 := by
  have heq := profile_deficit_add bs h
  have hb := nonlinear_profile_budget bs h
  omega

theorem at_most_one_nonlinear_below_twelve (bs : List (Nat × Nat))
    (h : ∀ b ∈ bs, Admissible b) {δ : Nat}
    (ht : (bs.map Prod.fst).sum ≤ 2 * (bs.map Prod.snd).sum + δ)
    (hδ : δ < 12) :
    (bs.map nonlinearIndicator).sum ≤ 1 := by
  have := nonlinear_profile_count_le bs h ht
  omega

#print axioms nonlinear_profile_count_le
#print axioms at_most_one_nonlinear_below_twelve


/-- In the first three deficits where degree m may occur, an omitted block
has exactly degree m. Its length is between 5m and 5m+2. -/
theorem first_omitted_block {b : Nat × Nat} (hb : Admissible b)
    {m r : Nat} (hm : 2 ≤ m) (hr : r ≤ 2) (he : m ≤ b.2)
    (hd : deficit b ≤ 3 * m + r) :
    b.2 = m ∧ 5 * m ≤ b.1 ∧ b.1 ≤ 5 * m + r := by
  have hs := hb.2.2 (show 2 ≤ b.2 by omega)
  change b.1 - 2 * b.2 ≤ 3 * m + r at hd
  omega

/-- Isolate the unique omitted-degree block and the exact remaining deficit. -/
theorem first_omitted_profile (b : Nat × Nat) (rest : List (Nat × Nat))
    (hb : Admissible b) (ha : ∀ x ∈ rest, Admissible x)
    {m r : Nat} (hm : 2 ≤ m) (hr : r ≤ 2) (he : m ≤ b.2)
    (ht : deficit b + (rest.map deficit).sum = 3 * m + r) :
    b.2 = m ∧ ∃ t ≤ r, b.1 = 5 * m + t ∧
      (rest.map deficit).sum = r - t ∧
      ∀ x ∈ rest, x.2 = 1 ∧ x.1 = 2 + deficit x := by
  obtain ⟨hdegree, hmin, hmax⟩ := first_omitted_block hb hm hr he (by omega)
  have hdb : deficit b = b.1 - 2 * m := by simp [deficit, hdegree]
  refine ⟨hdegree, b.1 - 5 * m, by omega, by omega, by omega, ?_⟩
  intro x hx
  have hdx := member_deficit_le rest hx
  exact low_deficit_type (ha x hx) (by omega)

/-- For deficit twelve or thirteen, any two nonlinear blocks both have
degree two. Only one unit of deficit can be distributed beyond their minima. -/
theorem first_two_nonlinear_profile (a b : Nat × Nat) (rest : List (Nat × Nat))
    (ha : Admissible a) (hb : Admissible b) (hrst : ∀ x ∈ rest, Admissible x)
    (hea : 2 ≤ a.2) (heb : 2 ≤ b.2) {r : Nat} (hr : r ≤ 1)
    (ht : deficit a + deficit b + (rest.map deficit).sum = 12 + r) :
    a.2 = 2 ∧ b.2 = 2 ∧ 10 ≤ a.1 ∧ 10 ≤ b.1 ∧
      (a.1 - 10) + (b.1 - 10) + (rest.map deficit).sum = r ∧
      ∀ x ∈ rest, x.2 = 1 ∧ x.1 = 2 + deficit x := by
  have hsa := ha.2.2 hea
  have hsb := hb.2.2 heb
  have hda : deficit a = a.1 - 2 * a.2 := rfl
  have hdb : deficit b = b.1 - 2 * b.2 := rfl
  refine ⟨by omega, by omega, by omega, by omega, by omega, ?_⟩
  intro x hx
  have hdx := member_deficit_le rest hx
  exact low_deficit_type (hrst x hx) (by omega)

#print axioms first_omitted_profile
#print axioms first_two_nonlinear_profile

end LC004.Diagonal
