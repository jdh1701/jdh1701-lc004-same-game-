import LC004.AlphabetTransfer
import LC004.WinningDiagonalBridge
import LC004.SecondDiagonalClosedForm

#print axioms LC004.Diagonal.twice_degree_le_size
#print axioms LC004.Diagonal.connected_block_horizon
#print axioms LC004.Diagonal.low_deficit_type
#print axioms LC004.Diagonal.profile_deficit_add
#print axioms LC004.Diagonal.member_deficit_le
#print axioms LC004.Diagonal.profile_block_horizon
#print axioms LC004.Diagonal.maximal_exceptional_profile
#print axioms LC004.Diagonal.horizon_caps_connected_degree_bound
#print axioms LC004.Diagonal.unique_small_deficit
#print axioms LC004.Diagonal.near_maximal_exceptional_profile
#print axioms LC004.Diagonal.productCoeff_witness
#print axioms LC004.Diagonal.productCoeff_vanishes_above_horizon
#print axioms LC004.Diagonal.productCoeff_congr
#print axioms LC004.Diagonal.productCoeff_transfer
#print axioms LC004.Diagonal.productCoeff_degree_truncation
#print axioms LC004.Diagonal.momentCoeff_degree_truncation
#print axioms LC004.Diagonal.momentCoeff_linear_for_top_three
#print axioms LC004.Diagonal.nonlinear_profile_budget
#print axioms LC004.Diagonal.nonlinear_profile_count_le
#print axioms LC004.Diagonal.at_most_one_nonlinear_below_twelve
#print axioms LC004.Diagonal.first_omitted_block
#print axioms LC004.Diagonal.first_omitted_profile
#print axioms LC004.Diagonal.first_two_nonlinear_profile
#print axioms LC004.WinningDiagonal.no_certificate_one
#print axioms LC004.WinningDiagonal.connectedPolynomial_one
#print axioms LC004.WinningDiagonal.blockCoeff_admissible
#print axioms LC004.WinningDiagonal.winningPolynomial_eval_count
#print axioms LC004.WinningDiagonal.profiles_sum
#print axioms LC004.WinningDiagonal.winningPolynomial_expansion
#print axioms LC004.WinningDiagonal.coeff_product
#print axioms LC004.WinningDiagonal.winningPolynomial_coeff_moment
#print axioms LC004.WinningDiagonal.winningPolynomial_size_transfer
#print axioms LC004.WinningDiagonal.winningPolynomial_degree_truncation
#print axioms LC004.WinningDiagonal.winningPolynomial_linear_for_top_three
#print axioms LC004.winningJoinCoefficient_crossed_four_zero
#print axioms LC004.ncConnected_nonzero_every_class_min_five
#print axioms LC004.connectedGamePolynomial_natDegree_le
#print axioms LC004.labeledWinningCount_connected_expansion
#print axioms LC004.connectedGamePolynomial_constant_zero
#print axioms LC004.winningColorPatternCount_second_diagonal

#print axioms LC004.invertMomentColumn_correct
#print axioms LC004.interpolateConnected_correct
#print axioms LC004.alphabetTransfer_eq_winningPolynomial
#print axioms LC004.alphabetTransfer_correct
#print axioms LC004.labeledWinningCount_empty
