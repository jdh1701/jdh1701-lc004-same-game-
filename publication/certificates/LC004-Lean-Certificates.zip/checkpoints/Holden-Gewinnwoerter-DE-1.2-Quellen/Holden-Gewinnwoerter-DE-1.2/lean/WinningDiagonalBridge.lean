import LC004.LabeledConnectedExpansion
import LC004.ConnectedCoefficientInterpolation
import LC004.DiagonalHorizon
import Mathlib.Algebra.Polynomial.Roots

namespace LC004.WinningDiagonal
open scoped Classical BigOperators
open LC004.Diagonal

theorem no_certificate_one (p : ColorPattern 1) : ¬ CertificateConstraint p := by
  intro h
  have hcard := h.1 (0 : Fin 1)
  have hle := Finset.card_le_univ (patternClassPositions p 0)
  simp only [Fintype.card_fin] at hle
  omega

theorem connectedPolynomial_one : connectedGamePolynomial 1 = 0 := by
  classical
  have hnil : certificateConstraints 1 = [] :=
    List.eq_nil_iff_forall_not_mem.mpr fun p hp =>
      no_certificate_one p ((mem_certificateConstraints p).mp hp)
  simp [connectedGamePolynomial, winningJoinCoefficient, hnil,
    certificateJoinTerms, collectedJoinCoefficient]

/-- Size zero never labels a block. Extend the positive-size family by zero there. -/
noncomputable def blockPolynomial (s : Nat) : Polynomial Int :=
  if s = 0 then 0 else connectedGamePolynomial s

noncomputable def blockCoeff (s e : Nat) : Int := (blockPolynomial s).coeff e

theorem blockCoeff_admissible (s e : Nat) (hne : blockCoeff s e ≠ 0) :
    Admissible (s, e) := by
  by_cases hz : s = 0
  · simp [blockCoeff, blockPolynomial, hz] at hne
  have hp : (connectedGamePolynomial s).coeff e ≠ 0 := by
    simpa [blockCoeff, blockPolynomial, hz] using hne
  have ho : s ≠ 1 := by
    rintro rfl
    simp [connectedPolynomial_one] at hp
  have he : e ≠ 0 := by
    rintro rfl
    exact hp (connectedGamePolynomial_constant_zero s (by omega))
  refine ⟨by change 2 ≤ s; omega, by change 1 ≤ e; omega, ?_⟩
  intro h
  change 5 * e ≤ s
  by_contra! hlt
  exact hp (connectedGamePolynomial_coeff_zero s e h hlt)

/-- Collected signed joins define the count polynomial independently of the block expansion. -/
noncomputable def winningPolynomial (n : Nat) : Polynomial Int :=
  ∑ p : ColorPattern n, Polynomial.C (winningJoinCoefficient n p) *
    Polynomial.X ^ Nat.card (Quotient p)

theorem winningPolynomial_eval_count (n b : Nat) :
    (winningPolynomial n).eval (b : Int) = (labeledWinningCount b n : Int) := by
  rw [labeledWinningCount_collected]
  simp [winningPolynomial, weightedGameCoefficient, Polynomial.eval_finset_sum]

noncomputable def blockSizes {n : Nat} (p : ColorPattern n) : List Nat :=
  (Finset.univ : Finset (Quotient p)).toList.map (fun x => (patternQuotientFiber p x).card)

noncomputable def ncSet (n : Nat) : Finset (ColorPattern n) :=
  Finset.univ.filter PatternNoncrossing

/-- One list per noncrossing partition, preserving multiplicity even for equal size lists. -/
noncomputable def profiles (n : Nat) : List (List Nat) := (ncSet n).toList.map blockSizes

theorem profiles_sum (n : Nat) (ss : List Nat) (hs : ss ∈ profiles n) : ss.sum = n := by
  obtain ⟨p, _, rfl⟩ := List.mem_map.mp hs
  simpa [blockSizes] using (pattern_card_sum_class_sizes p).symm

private theorem fiber_pos {n : Nat} (p : ColorPattern n) (x : Quotient p) :
    0 < (patternQuotientFiber p x).card := by
  apply Finset.card_pos.mpr
  exact ⟨x.out, Finset.mem_filter.mpr ⟨Finset.mem_univ _, Quotient.out_eq _⟩⟩

/-- Identity in ℤ[X], obtained from the evaluated identity at every integer. -/
theorem winningPolynomial_expansion (n : Nat) :
    winningPolynomial n = ∑ p ∈ ncSet n, ((blockSizes p).map blockPolynomial).prod := by
  apply Polynomial.funext
  intro z
  simp only [winningPolynomial, Polynomial.eval_finset_sum, Polynomial.eval_mul,
    Polynomial.eval_C, Polynomial.eval_pow, Polynomial.eval_X]
  change (∑ p : ColorPattern n, weightedGameCoefficient z n p) = _
  rw [weighted_game_noncrossing_expansion]
  unfold ncSet
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro p _
  by_cases hn : PatternNoncrossing p
  · rw [if_pos hn, if_pos hn]
    simp only [blockSizes, List.map_map, Function.comp_def, Finset.prod_map_toList,
      Polynomial.eval_prod]
    apply Finset.prod_congr rfl
    intro x _
    rw [blockPolynomial, if_neg (Nat.ne_of_gt (fiber_pos p x)), connectedGamePolynomial_eval]
  · simp [hn]

/-- Polynomial multiplication has precisely the list convolution used by the horizon certificate. -/
theorem coeff_product (f : Nat → Polynomial Int) (ss : List Nat) (d : Nat) :
    ((ss.map f).prod).coeff d = productCoeff (fun s e => (f s).coeff e) ss d := by
  induction ss generalizing d with
  | nil => simp [productCoeff, Polynomial.coeff_one, eq_comm]
  | cons s ss ih =>
    simp only [List.map_cons, List.prod_cons, Polynomial.coeff_mul,
      productCoeff]
    simp_rw [ih]
    rw [Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk]
    have hRange : (List.range (d+1)).toFinset = Finset.range (d+1) := by
      ext i
      simp
    simpa only [hRange] using (List.sum_toFinset (fun e => (f s).coeff e *
      productCoeff (fun a b => (f a).coeff b) ss (d-e)) (show (List.range (d+1)).Nodup from List.nodup_range))

theorem winningPolynomial_coeff_moment (n d : Nat) :
    (winningPolynomial n).coeff d = momentCoeff blockCoeff (profiles n) d := by
  rw [winningPolynomial_expansion]
  simp [momentCoeff, profiles, List.map_map, Function.comp_def, Polynomial.finset_sum_coeff,
    coeff_product, blockCoeff]
  rfl

/-- A second admissible family that agrees up to the size horizon gives the same coefficient. -/
theorem winningPolynomial_size_transfer {n d δ : Nat} (c : Nat → Nat → Int)
    (hc : ∀ s e, c s e ≠ 0 → Admissible (s,e)) (hnt : n ≤ 2*d + δ)
    (heq : ∀ s ≤ δ + 2 * max 1 (δ/3), ∀ e, blockCoeff s e = c s e) :
    (winningPolynomial n).coeff d = momentCoeff c (profiles n) d := by
  rw [winningPolynomial_coeff_moment]
  unfold momentCoeff
  apply congrArg List.sum
  apply List.map_congr_left
  intro ss hss
  exact productCoeff_transfer _ _ ss (fun s _ => blockCoeff_admissible s)
    (fun s _ => hc s) (by rw [profiles_sum n ss hss]; exact hnt) heq

theorem winningPolynomial_degree_truncation {n d r : Nat} (hr : 1 ≤ r)
    (h : n < 2*d + 3*(r+1)) :
    (winningPolynomial n).coeff d =
      momentCoeff (fun s e => if e ≤ r then blockCoeff s e else 0) (profiles n) d := by
  rw [winningPolynomial_coeff_moment]
  exact momentCoeff_degree_truncation _ _ hr blockCoeff_admissible (profiles_sum n) h

theorem winningPolynomial_linear_for_top_three {n k j : Nat}
    (hn : n = 2*k ∨ n = 2*k+1) (hj : j ≤ 2) :
    (winningPolynomial n).coeff (k-j) =
      momentCoeff (fun s e => if e ≤ 1 then blockCoeff s e else 0) (profiles n) (k-j) := by
  rw [winningPolynomial_coeff_moment]
  exact momentCoeff_linear_for_top_three _ _ hn hj blockCoeff_admissible (profiles_sum n)

end LC004.WinningDiagonal
