import TernaryBudget
#print axioms LC004.EntropyBudget.weighted_mono
#print axioms LC004.EntropyBudget.weighted_scale
#print axioms LC004.EntropyBudget.budget_all_horizons
#print axioms LC004.EntropyBudget.certified_decimal_rounding
