import Std

namespace LC004.EntropyBudget

/-- A state may store the full past. The three entries give the possible next colors. -/
structure Kernel (S : Type) where
  next : S → Fin 3 → S
  weight : S → Fin 3 → Nat
  denominator : Nat
  normalized : ∀ s, weight s 0 + weight s 1 + weight s 2 = denominator

def weighted {S : Type} (k : Kernel S) (s : S) (f : S → Int) : Int :=
  (k.weight s 0 : Int)*f (k.next s 0) +
  (k.weight s 1 : Int)*f (k.next s 1) +
  (k.weight s 2 : Int)*f (k.next s 2)

theorem weighted_mono {S : Type} (k : Kernel S) (s : S) {f g : S → Int}
    (h : ∀ t, f t ≤ g t) : weighted k s f ≤ weighted k s g := by
  unfold weighted
  apply Int.add_le_add
  · apply Int.add_le_add
    · exact Int.mul_le_mul_of_nonneg_left (h _) (by omega)
    · exact Int.mul_le_mul_of_nonneg_left (h _) (by omega)
  · exact Int.mul_le_mul_of_nonneg_left (h _) (by omega)

theorem weighted_scale {S : Type} (k : Kernel S) (s : S) (a : Int) (f : S → Int) :
    weighted k s (fun t => a*f t) = a*weighted k s f := by
  unfold weighted
  simp only [Int.mul_add]
  ac_rfl

/-- Dividing by D^n gives expected terminal credit plus the expected sum of
n net charges, each divided by D. 'charge' is D times the scaled excess cost. -/
def netBill {S : Type} (k : Kernel S) (charge credit : S → Int) : Nat → S → Int
  | 0, s => credit s
  | n+1, s => (k.denominator : Int)^n * charge s + weighted k s (netBill k charge credit n)

/-- A pointwise one-step amortized certificate covers every finite horizon. -/
theorem budget_all_horizons {S : Type} (k : Kernel S) (charge credit : S → Int)
    (step : ∀ s, charge s + weighted k s credit ≤ (k.denominator : Int)*credit s)
    (n : Nat) (s : S) : netBill k charge credit n s ≤ (k.denominator : Int)^n * credit s := by
  induction n generalizing s with
  | zero => simp [netBill]
  | succ n ih =>
    unfold netBill
    calc
      _ ≤ (k.denominator : Int)^n * charge s +
          weighted k s (fun t => (k.denominator : Int)^n*credit t) :=
        Int.add_le_add_left (weighted_mono k s ih) _
      _ = (k.denominator : Int)^n * (charge s + weighted k s credit) := by
        rw [weighted_scale, Int.mul_add]
      _ ≤ (k.denominator : Int)^n * ((k.denominator : Int)*credit s) :=
        Int.mul_le_mul_of_nonneg_left (step s) (Int.pow_nonneg (by omega : 0 ≤ (k.denominator : Int)))
      _ = _ := by rw [Int.pow_succ]; ac_rfl

/-- Cross-multiplied rational part of the advertised exponential Taylor lower
bound. The analytic inequality for exp and the identification of the finite
row maximum are separate steps. -/
theorem certified_decimal_rounding :
    let a : Nat := 2004461089829
    let b : Nat := 2500000000000000
    2*b^3*2997595610721 + 10^12*(6*a*b^2+a^3) ≤ 10^12*(6*b^3+3*a^2*b) := by decide

end LC004.EntropyBudget
