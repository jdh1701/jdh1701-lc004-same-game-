import FiniteBlock
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
namespace LC004.RawGrowth

abbrev Named (n : ℕ) (s : List (Fin 3)) :=
  {f : Fin n → Fin 3 // FusionEval [] (List.ofFn f) s}

private def back {n : ℕ} (f : Fin n → Fin 3) (i : Fin n) :=
  (List.ofFn f).reverse.get (i.cast (by simp))

private theorem ofFn_back {n : ℕ} (f : Fin n → Fin 3) :
    List.ofFn (back f) = (List.ofFn f).reverse :=
  (List.ofFn_congr (show (List.ofFn f).reverse.length = n by simp)
    (List.ofFn f).reverse.get).symm.trans (List.ofFn_get _)

/-- A common stack of arbitrary height yields a rectangular family of winners. -/
theorem named_product (n m : ℕ) (s : List (Fin 3)) :
    Nat.card (Named n s) * Nat.card (Named m s) ≤ labeledWinningCount 3 (n+m) := by
  let F (p : Named n s × Named m s) :
      {w : Fin (n+m) → Fin 3 // RawMaxErases (List.ofFn w) []} :=
    ⟨Fin.append p.1.val (back p.2.val),by
      rw [List.ofFn_fin_append,ofFn_back,raw_max_win_iff_fusionEval]
      exact fusionEval_append p.1.property (fusionEval_reverse p.2.property trivial)⟩
  rw [← Nat.card_prod]
  apply Nat.card_le_card_of_injective F
  intro p t h
  apply Prod.ext
  · apply Subtype.ext; funext i
    simpa [F,Fin.append_left] using congrArg (fun w => w.val (Fin.castAdd m i)) h
  · apply Subtype.ext
    have hb : back p.2.val = back t.2.val := by
      funext i
      simpa [F,Fin.append_right] using congrArg (fun w => w.val (Fin.natAdd n i)) h
    have hr := congrArg List.reverse (congrArg List.ofFn hb)
    simpa [ofFn_back] using hr

theorem full_of_named_rates (named : ∀ r : ℝ, 1 < r → r < 3 →
    ∃ n : ℕ, 0 < n ∧ ∃ s, r^n ≤ Nat.card (Named n s)) : FullTernaryGrowth := by
  apply full_iff_finite_blocks.mpr
  intro r hr hr3
  obtain ⟨n,hn,s,h⟩ := named r hr hr3
  refine ⟨n+n,by omega,?_⟩
  rw [pow_add]
  have pos : 0 ≤ r^n := by positivity
  exact (mul_le_mul h h pos (by positivity)).trans (by exact_mod_cast named_product n n s)

/-- Assign each distinct covered prefix one reachable dictionary entry. Only
equal-entry pairs are used, hence no pair of inputs is counted twice. -/
theorem dictionary_collision {α ι : Type} [Fintype α] [Fintype ι]
    (n : ℕ) (encode : α → Fin n → Fin 3) (inject : Function.Injective encode)
    (label : α → ι) (stack : ι → List (Fin 3))
    (reach : ∀ a, FusionEval [] (List.ofFn (encode a)) (stack (label a))) :
    Nat.card α ^ 2 ≤ Nat.card ι * labeledWinningCount 3 (n+n) := by
  classical
  let A (i : ι) := {a : α // label a = i}
  let P := Σ i, A i × A i
  let F (p : P) : {w : Fin (n+n) → Fin 3 // RawMaxErases (List.ofFn w) []} :=
    ⟨Fin.append (encode p.2.1.val) (back (encode p.2.2.val)),by
      rw [List.ofFn_fin_append,ofFn_back,raw_max_win_iff_fusionEval]
      have h := reach p.2.1.val
      have g := reach p.2.2.val
      rw [p.2.1.property] at h
      rw [p.2.2.property] at g
      exact fusionEval_append h (fusionEval_reverse g trivial)⟩
  have inj : Function.Injective F := by
    rintro ⟨i,⟨⟨a,ha⟩,⟨b,hb⟩⟩⟩ ⟨j,⟨⟨c,hc⟩,⟨d,hd⟩⟩⟩ eq
    have e : a = c := inject (funext fun k => by
      simpa [F,Fin.append_left] using congrArg (fun w => w.val (Fin.castAdd n k)) eq)
    have hh : back (encode b) = back (encode d) := by
      funext k
      simpa only [F,Fin.append_right] using congrArg (fun w => w.val (Fin.natAdd n k)) eq
    have hr := congrArg List.reverse (congrArg List.ofFn hh)
    have g : b = d := inject (by simpa [ofFn_back] using hr)
    subst c; subst d; subst i; subst j; rfl
  have pairs := Nat.card_le_card_of_injective F inj
  change Nat.card (Σ i, A i × A i) ≤ labeledWinningCount 3 (n+n) at pairs
  rw [Nat.card_sigma] at pairs
  simp_rw [Nat.card_prod,←sq] at pairs
  have total : (∑ i, Nat.card (A i)) = Nat.card α := by
    rw [← Nat.card_sigma]
    exact Nat.card_congr (Equiv.sigmaFiberEquiv label)
  have cs := Finset.sum_mul_sq_le_sq_mul_sq (s := Finset.univ) (fun _ : ι => (1:ℕ)) (fun i => Nat.card (A i))
  rw [←total]
  exact (by simpa [Nat.card_eq_fintype_card] using cs :
    (∑ i, Nat.card (A i))^2 ≤ Nat.card ι * ∑ i, Nat.card (A i)^2).trans (Nat.mul_le_mul_left _ pairs)

/-- Collision transfer in integer arithmetic: the loss from dictionary size
is paid once per pair, even if the reachable stacks themselves are long. -/
theorem full_of_dictionary_rates
    (cover : ∀ r : ℝ, 1 < r → r < 3 →
      ∃ n : ℕ, 0 < n ∧ ∃ A B : ℕ, 0 < B ∧
      (∃ encode : Fin A → Fin n → Fin 3, Function.Injective encode ∧
       ∃ label : Fin A → Fin B, ∃ stack : Fin B → List (Fin 3),
         ∀ a, FusionEval [] (List.ofFn (encode a)) (stack (label a))) ∧
      (B:ℝ) * r^(n+n) ≤ (A:ℝ)^2) : FullTernaryGrowth := by
  apply full_iff_finite_blocks.mpr
  intro r hr hr3
  obtain ⟨n,hn,A,B,hB,⟨f,hf,g,s,h⟩,rate⟩ := cover r hr hr3
  have natbound := dictionary_collision n f hf g s h
  simp only [Nat.card_eq_fintype_card,Fintype.card_fin] at natbound
  have rb : (A:ℝ)^2 ≤ B * (labeledWinningCount 3 (n+n) : ℝ) := by exact_mod_cast natbound
  exact ⟨n+n,by omega,le_of_mul_le_mul_left (rate.trans rb) (by exact_mod_cast hB : (0:ℝ)<B)⟩

/-- Independent color renaming of the halves can turn a losing pair into
a matching pair. Equality of shapes alone is insufficient for a fixed pair. -/
theorem shape_only_false_pair :
    RawMaxErases ([0,1,1,0] : List (Fin 3)) [] ∧
    ¬ RawMaxErases ([0,1,2,0] : List (Fin 3)) [] := by
  simp only [raw_max_win_iff_fusionReach]
  decide

#print axioms shape_only_false_pair
#print axioms full_of_dictionary_rates
#print axioms dictionary_collision
#print axioms full_of_named_rates
end LC004.RawGrowth
