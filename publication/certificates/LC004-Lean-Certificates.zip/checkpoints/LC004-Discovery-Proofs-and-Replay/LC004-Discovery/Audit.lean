import HeavySchedule

#print axioms LC004.doubledSchedule
#print axioms LC004.fusionEval_stack_sublist
#print axioms LC004.proper_collapse_pair
#print axioms LC004.doubledSchedule_support_iff
#print axioms LC004.doubledSchedule_proper_test
#print axioms LC004.doubledSchedule_mixed_test
#print axioms LC004.sum_schedule_cons
#print axioms LC004.scheduleHits
#print axioms LC004.ternaryHitTail
#print axioms LC004.scheduleHits_nil
#print axioms LC004.scheduleHits_cons
#print axioms LC004.scheduleHits_eq_tail
#print axioms LC004.paired_prefix_fixed_suffix_count
#print axioms LC004.missSum
#print axioms LC004.ternaryHitTail_closed
#print axioms LC004.paired_prefix_fixed_suffix_binomial
#print axioms LC004.heavySchedule
#print axioms LC004.heavySchedule_support_iff
#print axioms LC004.heavySchedule_proper_test
#print axioms LC004.heavy_fixed_lengths_suffix_binomial
