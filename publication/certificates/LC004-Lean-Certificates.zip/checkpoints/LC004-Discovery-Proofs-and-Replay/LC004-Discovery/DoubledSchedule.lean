import LC004.FusionStack

namespace LC004

/-- Double the colors of the reversed, top-first schedule. -/
def doubledSchedule {q : Nat} : List (Fin q) → List (Fin q)
  | [] => []
  | a :: h => doubledSchedule h ++ [a, a]

theorem fusionEval_stack_sublist {q : Nat} {s w t : List (Fin q)}
    (h : FusionEval s w t) : t.Sublist (w.reverse ++ s) := by
  induction h with
  | done s => simp
  | push a _ _ ih => simpa [List.reverse_cons, List.append_assoc] using ih
  | @pop s w t a _ ih =>
    have sub := (((List.Sublist.refl s).cons a).cons a).append_left w.reverse
    simpa [List.reverse_cons, List.append_assoc] using ih.trans sub
  | @stay s w t a _ ih =>
    have sub := ((List.Sublist.refl (a :: s)).cons a).append_left w.reverse
    simpa [List.reverse_cons, List.append_assoc] using ih.trans sub

theorem proper_collapse_pair {q : Nat} {s u : List (Fin q)} {a : Fin q}
    (hp : FusionProper s) (hs : s.Sublist (a :: a :: u)) : s.Sublist (a :: u) := by
  rcases List.sublist_cons_iff.mp hs with skip | ⟨r, rfl, hr⟩
  · exact skip
  · rcases List.sublist_cons_iff.mp hr with hskip | ⟨t, rfl, _⟩
    · exact hskip.cons₂ a
    · exact (hp.1 rfl).elim

/-- Top-first reachable stacks of a doubled schedule are exactly its proper
scattered subsequences. No stack multiplicity enters this equality. -/
theorem doubledSchedule_support_iff {q : Nat} (h s : List (Fin q)) :
    s ∈ fusionReach [] (doubledSchedule h) ↔ FusionProper s ∧ s.Sublist h := by
  induction h generalizing s with
  | nil => cases s <;> simp [doubledSchedule, fusionReach, FusionProper]
  | cons a h ih =>
    constructor
    · intro hs
      have hp := fusionReach_proper hs
      obtain ⟨v, hv, last⟩ := fusionEval_split
        ((mem_fusionReach_iff [] (doubledSchedule (a :: h)) s).mp hs :
          FusionEval [] (doubledSchedule h ++ [a, a]) s)
      have hvSub := ((ih v).mp ((mem_fusionReach_iff _ _ _).mpr hv)).2
      have hsSub : s.Sublist (a :: a :: v) := by
        simpa using fusionEval_stack_sublist last
      exact ⟨hp,(proper_collapse_pair hp hsSub).trans (hvSub.cons₂ a)⟩
    · rintro ⟨hp, hs⟩
      apply (mem_fusionReach_iff _ _ _).mpr
      rcases List.sublist_cons_iff.mp hs with skip | ⟨v, rfl, hv⟩
      · exact fusionEval_append ((mem_fusionReach_iff _ _ _).mp ((ih s).mpr ⟨hp,skip⟩))
          (fusionEval_pair_loop s a)
      · exact fusionEval_append ((mem_fusionReach_iff _ _ _).mp ((ih v).mpr ⟨hp.2,hv⟩))
          (FusionEval.push a hp.1 (FusionEval.stay a (FusionEval.done _)))

theorem doubledSchedule_proper_test {q : Nat} (h s : List (Fin q)) (hp : FusionProper s) :
    RawMaxErases (doubledSchedule h ++ s) [] ↔ s.Sublist h := by
  rw [raw_max_win_append_proper_iff _ _ hp, doubledSchedule_support_iff]
  simp [hp]

/-- A mixed suffix wins iff its reverse support meets the subsequences
of the top-first schedule. -/
theorem doubledSchedule_mixed_test {q : Nat} (h v : List (Fin q)) :
    RawMaxErases (doubledSchedule h ++ v) [] ↔
      ∃ s ∈ fusionReach [] v.reverse, s.Sublist h := by
  rw [raw_max_win_append_iff_common_fusion_stack]
  constructor
  · rintro ⟨s, hl, hr⟩
    exact ⟨s,hr,((doubledSchedule_support_iff h s).mp hl).2⟩
  · rintro ⟨s,hr,sub⟩
    exact ⟨s,(doubledSchedule_support_iff h s).mpr ⟨fusionReach_proper hr,sub⟩,hr⟩

end LC004
