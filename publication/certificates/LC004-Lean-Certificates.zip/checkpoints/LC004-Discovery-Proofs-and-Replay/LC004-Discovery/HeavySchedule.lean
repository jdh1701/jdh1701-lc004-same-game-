import PairedBinomial

namespace LC004

/-- Top-first list of (color, excess over two); every block is nonempty and heavy. -/
def heavySchedule {q : Nat} : List (Fin q × Nat) → List (Fin q)
  | [] => []
  | (a,e) :: h => heavySchedule h ++ List.replicate (e+2) a

private theorem stayPrefix {q : Nat} (a : Fin q) (s : List (Fin q)) (n : Nat)
    {w t : List (Fin q)} (h : FusionEval (a :: s) w t) :
    FusionEval (a :: s) (List.replicate n a ++ w) t := by
  induction n with
  | zero => exact h
  | succ n ih => simpa [List.replicate_succ] using FusionEval.stay a ih

private theorem heavyLoop {q : Nat} (s : List (Fin q)) (a : Fin q) (n : Nat) :
    FusionEval s (List.replicate (n+2) a) s := by
  by_cases e : s.head? = some a
  · obtain ⟨t,rfl⟩ := List.head?_eq_some_iff.mp e
    simpa using stayPrefix a t (n+2) (FusionEval.done _)
  · rw [List.replicate_succ, List.replicate_succ']
    exact FusionEval.push a e (stayPrefix a s n (FusionEval.pop a (FusionEval.done _)))

private theorem collapseRun {q : Nat} (n : Nat) {a : Fin q} {s t : List (Fin q)}
    (hp : FusionProper s) (hs : s.Sublist (List.replicate (n+1) a ++ t)) :
    s.Sublist (a :: t) := by
  induction n with
  | zero => simpa using hs
  | succ n ih =>
    apply ih
    have step : s.Sublist (a :: a :: (List.replicate n a ++ t)) := by
      simpa [List.replicate_succ] using hs
    simpa [List.replicate_succ] using proper_collapse_pair hp step

/-- Every positive excess over two disappears from the reachable support. -/
theorem heavySchedule_support_iff {q : Nat} (h : List (Fin q × Nat)) (s : List (Fin q)) :
    s ∈ fusionReach [] (heavySchedule h) ↔ FusionProper s ∧ s.Sublist (h.map Prod.fst) := by
  induction h generalizing s with
  | nil => cases s <;> simp [heavySchedule, fusionReach, FusionProper]
  | cons block h ih =>
    obtain ⟨a,e⟩ := block
    constructor
    · intro hs
      have hp := fusionReach_proper hs
      obtain ⟨t, ht, last⟩ := fusionEval_split
        ((mem_fusionReach_iff [] _ s).mp hs :
          FusionEval [] (heavySchedule h ++ List.replicate (e+2) a) s)
      have htSub := ((ih t).mp ((mem_fusionReach_iff _ _ _).mpr ht)).2
      have hsSub : s.Sublist (List.replicate (e+2) a ++ t) := by
        simpa using fusionEval_stack_sublist last
      exact ⟨hp,(collapseRun (e+1) hp hsSub).trans (htSub.cons₂ a)⟩
    · rintro ⟨hp, hs⟩
      apply (mem_fusionReach_iff _ _ _).mpr
      rcases List.sublist_cons_iff.mp hs with skip | ⟨t,rfl,ht⟩
      · exact fusionEval_append ((mem_fusionReach_iff _ _ _).mp ((ih s).mpr ⟨hp,skip⟩))
          (heavyLoop s a e)
      · apply fusionEval_append ((mem_fusionReach_iff _ _ _).mp ((ih t).mpr ⟨hp.2,ht⟩))
        rw [List.replicate_succ]
        exact FusionEval.push a hp.1 (by simpa using stayPrefix a t (e+1) (FusionEval.done _))

theorem heavySchedule_proper_test {q : Nat} (h : List (Fin q × Nat)) (s : List (Fin q))
    (hp : FusionProper s) :
    RawMaxErases (heavySchedule h ++ s) [] ↔ s.Sublist (h.map Prod.fst) := by
  rw [raw_max_win_append_proper_iff _ _ hp, heavySchedule_support_iff]
  simp [hp]

/-- Exact count for every fixed vector of block lengths at least two. Neighboring
block colors may coincide. The sum is over all ternary assignments to the blocks. -/
theorem heavy_fixed_lengths_suffix_binomial (m : Nat) (e : Fin m → Nat)
    (s : List (Fin 3)) (hp : FusionProper s) :
    (∑ v : Fin m → Fin 3, @ite Nat
        (RawMaxErases (heavySchedule (List.ofFn (fun i => (v i, e i))) ++ s) [])
        (Classical.propDecidable _) 1 0) =
      if s.length ≤ m then ∑ j ∈ Finset.range (m-s.length+1), m.choose j * 2^j else 0 := by
  calc
    _ = scheduleHits m s := by
      unfold scheduleHits
      apply Finset.sum_congr rfl
      intro v _
      classical
      have hw : RawMaxErases (heavySchedule (List.ofFn (fun i => (v i,e i))) ++ s) [] ↔
          s.Sublist (List.ofFn v) := by
        simpa [List.map_ofFn,Function.comp_def] using
          heavySchedule_proper_test (List.ofFn (fun i => (v i,e i))) s hp
      simp only [hw]
    _ = _ := by
      rw [scheduleHits_eq_tail, ternaryHitTail_closed]
      rfl

end LC004
