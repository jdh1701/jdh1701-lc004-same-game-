import PairedSuffixCount
import Mathlib.Data.Nat.Choose.Sum

namespace LC004

/-- Number of schedules encoded by at most d misses; each miss has two colors. -/
def missSum (m d : Nat) : Nat :=
  ∑ j ∈ Finset.range (d+1), m.choose j * 2^j

private theorem missSum_succ (m d : Nat) :
    missSum m (d+1) = missSum m d + m.choose (d+1) * 2^(d+1) := by
  exact Finset.sum_range_succ _ _

private theorem missSum_zero (m : Nat) : missSum m 0 = 1 := by simp [missSum]

private theorem missSum_next (m d : Nat) :
    missSum (m+1) (d+1) = missSum m (d+1) + 2 * missSum m d := by
  induction d with
  | zero => simp [missSum_succ, missSum_zero]; omega
  | succ d ih =>
    rw [missSum_succ (m+1) (d+1), ih, missSum_succ m (d+1),
      missSum_succ m d, Nat.choose_succ_succ m (d+1), pow_succ 2 (d+1)]
    ring

private theorem missSum_full (m : Nat) : missSum m m = 3^m := by
  simpa [missSum, Nat.mul_comm] using (add_pow (2 : Nat) 1 m).symm

theorem ternaryHitTail_closed (m k : Nat) :
    ternaryHitTail m k = if k ≤ m then missSum m (m-k) else 0 := by
  induction m generalizing k with
  | zero => cases k <;> simp [ternaryHitTail, missSum_zero]
  | succ m ih =>
    cases k with
    | zero => simp [ternaryHitTail, missSum_full]
    | succ k =>
      simp only [ternaryHitTail, ih, Nat.succ_le_succ_iff, Nat.succ_sub_succ_eq_sub]
      by_cases hk : k ≤ m
      · simp only [if_pos hk]
        by_cases hs : k+1 ≤ m
        · rw [if_pos hs]
          let d := m-(k+1)
          have hd : m-k=d+1 := by dsimp [d]; omega
          rw [hd, missSum_next]
        · have he : k=m := by omega
          subst k
          simp [missSum_zero]
      · have hs : ¬k+1 ≤ m := by omega
        simp [hk, hs]

/-- Exact all-m count for a fixed proper suffix in the original game,
in the finite family with a doubled ternary prefix. -/
theorem paired_prefix_fixed_suffix_binomial (m : Nat) (s : List (Fin 3))
    (hp : FusionProper s) :
    (∑ v : Fin m → Fin 3, @ite Nat
      (RawMaxErases (doubledSchedule (List.ofFn v) ++ s) []) (Classical.propDecidable _) 1 0) =
    if s.length ≤ m then ∑ j ∈ Finset.range (m-s.length+1), m.choose j * 2^j else 0 := by
  rw [paired_prefix_fixed_suffix_count _ _ hp, ternaryHitTail_closed]
  rfl

end LC004
