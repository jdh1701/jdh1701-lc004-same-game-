import DoubledSchedule
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fin.Tuple.Basic

namespace LC004

/-- Split a sum over all schedules into its first ternary letter and its tail. -/
theorem sum_schedule_cons (m : Nat) (f : List (Fin 3) → Nat) :
    (∑ v : Fin (m+1) → Fin 3, f (List.ofFn v)) =
      ∑ a : Fin 3, ∑ v : Fin m → Fin 3, f (a :: List.ofFn v) := by
  rw [← (Fin.consEquiv (fun _ : Fin (m+1) => Fin 3)).sum_comp (fun v => f (List.ofFn v))]
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro v _
  rw [List.ofFn_succ]
  simp

def scheduleHits (m : Nat) (s : List (Fin 3)) : Nat :=
  ∑ v : Fin m → Fin 3, if s.Sublist (List.ofFn v) then 1 else 0

/-- Count the schedules with at least k matches of a prescribed proper suffix. -/
def ternaryHitTail : Nat → Nat → Nat
  | 0, 0 => 1
  | 0, _+1 => 0
  | m+1, 0 => 3^(m+1)
  | m+1, k+1 => ternaryHitTail m k + 2 * ternaryHitTail m (k+1)

theorem scheduleHits_nil (m : Nat) : scheduleHits m [] = 3^m := by
  simp [scheduleHits]

theorem scheduleHits_cons (m : Nat) (a : Fin 3) (s : List (Fin 3)) :
    scheduleHits (m+1) (a::s) = scheduleHits m s + 2 * scheduleHits m (a::s) := by
  unfold scheduleHits
  rw [sum_schedule_cons m (fun v => if (a :: s).Sublist v then 1 else 0)]
  have first (b : Fin 3) (v : List (Fin 3)) :
      (if (a::s).Sublist (b::v) then 1 else 0 : Nat) =
        if b=a then (if s.Sublist v then 1 else 0)
        else (if (a::s).Sublist v then 1 else 0) := by
    by_cases h : b=a
    · subst b; simp [List.cons_sublist_cons]
    · simp [List.sublist_cons_iff, h, Ne.symm h]
  simp_rw [first, Finset.sum_ite_irrel]
  rw [Fin.sum_univ_three]
  fin_cases a <;> simp <;> omega

theorem scheduleHits_eq_tail (m : Nat) (s : List (Fin 3)) :
    scheduleHits m s = ternaryHitTail m s.length := by
  induction m generalizing s with
  | zero => cases s <;> simp [scheduleHits, ternaryHitTail]
  | succ m ih =>
    cases s with
    | nil => simp [scheduleHits_nil, ternaryHitTail]
    | cons a s => rw [scheduleHits_cons, ih, ih]; rfl

/-- The indicator sum uses actual maximal-run winning on the doubled prefix
and the fixed proper suffix. Each tuple selects one distinct paired prefix. -/
theorem paired_prefix_fixed_suffix_count (m : Nat) (s : List (Fin 3))
    (hp : FusionProper s) :
    (∑ v : Fin m → Fin 3, @ite Nat
      (RawMaxErases (doubledSchedule (List.ofFn v) ++ s) []) (Classical.propDecidable _) 1 0) =
      ternaryHitTail m s.length := by
  rw [← scheduleHits_eq_tail m s]
  unfold scheduleHits
  apply Finset.sum_congr rfl
  intro v _
  classical
  by_cases h : s.Sublist (List.ofFn v)
  · have hw := (doubledSchedule_proper_test _ s hp).mpr h
    simp [hw,h]
  · have hw : ¬ RawMaxErases (doubledSchedule (List.ofFn v) ++ s) [] := fun hwin => h ((doubledSchedule_proper_test _ s hp).mp hwin)
    simp [hw,h]

end LC004
