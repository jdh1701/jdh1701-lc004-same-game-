import SparseRepair
namespace LC004.RawGrowth

abbrev Input (n : ℕ) := Fin n → Fin 3
abbrev Resid := List (Fin 3)

def blockResid {L : ℕ} (step : Resid → Input L → Resid) :
    (t : ℕ) → Input (L*t) → Resid
  | 0, _ => []
  | t+1, f => step (blockResid step t (fun i => f (Fin.castAdd L i)))
                    (fun i => f (Fin.natAdd (L*t) i))

private theorem legal_blocks {L : ℕ} (step : Resid → Input L → Resid)
    (legal : ∀ s b, Erases (s ++ List.ofFn b) (step s b)) (t : ℕ) (f : Input (L*t)) :
    Erases (List.ofFn f) (blockResid step t f) := by
  induction t with
  | zero => simpa [blockResid] using Erases.refl ([] : Resid)
  | succ t ih =>
    let u := fun i => f (Fin.castAdd L i)
    let v := fun i => f (Fin.natAdd (L*t) i)
    have h := erases_context (ih u) [] (List.ofFn v)
    change Erases (List.ofFn f) (step (blockResid step t u) v)
    rw [List.ofFn_add]
    exact erases_trans (by simpa [u,v] using h) (legal _ _)

private theorem mass_blocks {L C : ℕ} (step : Resid → Input L → Resid)
    (localBound : ∀ s, (∑ b, (step s b).length^2) ≤ 3^L * (s.length^2+C)) (t : ℕ) :
    (∑ f, (blockResid step t f).length^2) ≤ 3^(L*t)*(C*t) := by
  induction t with
  | zero => simp [blockResid]
  | succ t ih =>
    let e := Fin.appendEquiv (α := Fin 3) (L*t) L
    apply le_trans (le_of_eq (e.sum_comp (fun f => (blockResid step (t+1) f).length^2)).symm)
    rw [Fintype.sum_prod_type]
    have recur (u : Input (L*t)) (v : Input L) :
        blockResid step (t+1) (e (u,v)) = step (blockResid step t u) v := by
      simp only [e,Fin.appendEquiv,Equiv.coe_fn_mk,blockResid,Fin.append_left,Fin.append_right]
    simp_rw [recur]
    apply le_trans (Finset.sum_le_sum (fun u _ => localBound (blockResid step t u)))
    rw [←Finset.mul_sum, Finset.sum_add_distrib]
    simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fun,Fintype.card_fin, nsmul_eq_mul]
    rw [Nat.mul_succ,pow_add]
    nlinarith [Nat.mul_le_mul_left (3^L) ih]

private theorem accessible (s w : Resid) : ∃ t, FusionEval s w t ∧ t.length ≤ s.length+w.length := by
  induction w generalizing s with
  | nil => exact ⟨s,.done _,by simp⟩
  | cons a w ih =>
    by_cases h : s.head? = some a
    · obtain ⟨v,rfl⟩ := List.head?_eq_some_iff.mp h
      obtain ⟨t,run,ht⟩ := ih v
      exact ⟨t,.pop a run,by simp_all; omega⟩
    · obtain ⟨t,run,ht⟩ := ih (a::s)
      exact ⟨t,.push a h run,by simp_all; omega⟩

private theorem mark_half {X : Type} [Fintype X] (h : X → ℕ) (k : ℕ) (hk : 0 < k)
    (bound : 2*(∑ x,h x^2) ≤ Fintype.card X * k^2) :
    Fintype.card X ≤ 2 * Nat.card {x // h x ≤ k} := by
  classical
  let bad := Finset.univ.filter (fun x => ¬h x ≤ k)
  have hb : bad.card * k^2 ≤ ∑ x,h x^2 := by
    calc
      _ = ∑ _x ∈ bad, k^2 := by simp
      _ ≤ ∑ x ∈ bad,h x^2 := Finset.sum_le_sum (fun x hx =>
        Nat.pow_le_pow_left (by have := (Finset.mem_filter.mp hx).2; omega) _)
      _ ≤ _ := Finset.sum_le_univ_sum_of_nonneg (fun _ => Nat.zero_le _)
  have scaled : (2*bad.card)*k^2 ≤ Fintype.card X*k^2 := by
    rw [Nat.mul_assoc]; exact (Nat.mul_le_mul_left 2 hb).trans bound
  have bh := Nat.le_of_mul_le_mul_right scaled (by positivity : 0<k^2)
  have c : bad.card = Fintype.card X - Nat.card {x // h x ≤ k} := by
    rw [Nat.card_eq_fintype_card]
    simpa [bad, Fintype.card_subtype] using (Fintype.card_subtype_compl (fun x => h x ≤ k))
  omega

theorem full_of_square_drift {L C : ℕ} (hL : 0<L) (step : Resid → Input L → Resid)
    (legal : ∀ s b, Erases (s ++ List.ofFn b) (step s b))
    (bound : ∀ s, (∑ b, (step s b).length^2) ≤ 3^L * (s.length^2+C)) :
    FullTernaryGrowth := by
  apply full_of_sparse_repairs
  intro m
  let k := 4*C*(m+1)+4
  let t := (m+1)*(k+2)
  have hk : 0<k := by dsimp [k]; omega
  have hsq : 2*(C*t) ≤ k^2 := by
    have ha : k+2 ≤ 2*k := by dsimp [k]; omega
    have hb : 4*C*(m+1) ≤ k := by dsimp [k]; omega
    dsimp [t]
    nlinarith [Nat.mul_le_mul_left (2*C*(m+1)) ha,Nat.mul_le_mul_right k hb]
  have ms := mass_blocks step bound t
  have mh := mark_half (fun f => (blockResid step t f).length) k hk (by
    simp only [Fintype.card_fun,Fintype.card_fin]
    nlinarith [Nat.mul_le_mul_left 2 ms,Nat.mul_le_mul_left (3^(L*t)) hsq])
  let F (x : {f : Input (L*t) // (blockResid step t f).length ≤ k}) : Short (L*t) k := by
    refine ⟨x.val,?_⟩
    obtain ⟨z,ev,hz⟩ := accessible [] (blockResid step t x.val)
    exact ⟨z,erases_lifts_fusionEval (legal_blocks step legal t x.val) ev,
      (by simpa using hz : z.length ≤ _).trans x.property⟩
  have hi : Function.Injective F := by
    intro a b h; exact Subtype.ext (congrArg (fun y : Short (L*t) k => y.val) h)
  letI : Finite (Short (L*t) k) := Finite.of_injective Subtype.val Subtype.val_injective
  have hh := Nat.card_le_card_of_injective F hi
  simp only [Fintype.card_fun,Fintype.card_fin] at mh
  refine ⟨L*t,k,k+2,le_rfl,?_,?_⟩
  · have := Nat.mul_le_mul_left (k+2) (Nat.le_succ m)
    have := Nat.mul_le_mul_right t hL
    dsimp [t] at *; nlinarith
  · exact mh.trans (Nat.mul_le_mul (by
      calc 2 = 2^1 := by decide
           _ ≤ 2^(k+2) := Nat.pow_le_pow_right (by decide) (by omega)) hh)

private theorem erase_length {s t : Resid} (h : Erases s t) : t.length ≤ s.length := by
  induction h with
  | refl => rfl
  | next hs _ ih =>
    apply ih.trans
    cases hs <;> simp <;> omega

private theorem properize (s : Resid) : ∃ t, Erases s t ∧ FusionProper t := by
  induction s with
  | nil => exact ⟨[],.refl _,trivial⟩
  | cons a s ih =>
    obtain ⟨t,he,hp⟩ := ih
    have h : Erases (a::s) (a::t) := by simpa using erases_context he [a] []
    by_cases eq : t.head? = some a
    · obtain ⟨u,rfl⟩ := List.head?_eq_some_iff.mp eq
      exact ⟨u,erases_trans h (.next (SmallErase.pair [] u a) (.refl _)),hp.2⟩
    · exact ⟨a::t,h,eq,hp⟩

private theorem proper_drop (s : Resid) (hp : FusionProper s) (n : ℕ) :
    FusionProper (s.drop n) := by
  induction n generalizing s with
  | zero => simpa using hp
  | succ n ih =>
    cases s with
    | nil => trivial
    | cons a s => exact ih s hp.2

/-- A finite certificate with one unweighted row for each proper length-K
raw-letter tail. Erasure witnesses may depend on the whole next L-letter
block. The rows need only have nonpositive mean change. -/
theorem full_of_finite_tail_mean {K L : ℕ} (hL : 0<L)
    (cert : ∀ u : Resid, u.length = K → FusionProper u →
      ∃ r : Input L → Resid,
        (∀ b, Erases (u ++ List.ofFn b) (r b)) ∧ (∑ b, (r b).length) ≤ 3^L*K) :
    FullTernaryGrowth := by
  classical
  let C := (K+L)^2
  have policy (s : Resid) : ∃ rule : Input L → Resid,
      (∀ b, Erases (s ++ List.ofFn b) (rule b)) ∧
        (∑ b, (rule b).length^2) ≤ 3^L*(s.length^2+C) := by
    obtain ⟨t,et,pt⟩ := properize s
    have ht := erase_length et
    have start (b : Input L) : Erases (s++List.ofFn b) (t++List.ofFn b) := by
      simpa using erases_context et [] (List.ofFn b)
    by_cases long : K ≤ t.length
    · let p := t.take (t.length-K)
      let u := t.drop (t.length-K)
      have pu : p++u = t := List.take_append_drop _ _
      have hu : u.length = K := by simp [u];omega
      have split : p.length + K = t.length := by
        simpa [hu] using congrArg List.length pu
      obtain ⟨r,leg,mean⟩ := cert u hu (proper_drop t pt _)
      refine ⟨fun b => p++r b,?_,?_⟩
      · intro b
        apply erases_trans (start b)
        have h := erases_context (leg b) p []
        simpa only [List.append_nil,←List.append_assoc,pu] using h
      · have each (b : Input L) : (r b).length^2 ≤ C := by
          have h := erase_length (leg b)
          simp only [List.length_append,List.length_ofFn,hu] at h
          exact Nat.pow_le_pow_left h 2
        calc
          _ ≤ ∑ b : Input L, ((p.length^2+C)+(2*p.length)*(r b).length) := by
              apply Finset.sum_le_sum
              intro b _
              simp only [List.length_append,add_sq]
              have := each b
              omega
          _ = 3^L*(p.length^2+C) + (2*p.length)*∑ b,(r b).length := by
              rw [Finset.sum_add_distrib,←Finset.mul_sum]
              simp
          _ ≤ 3^L*(p.length^2+C)+(2*p.length)*(3^L*K) :=
              Nat.add_le_add_left (Nat.mul_le_mul_left _ mean) _
          _ ≤ _ := by
              have small : p.length^2+2*p.length*K ≤ s.length^2 := by
                have h := Nat.pow_le_pow_left (split ▸ ht : p.length+K ≤ s.length) 2
                nlinarith
              nlinarith [Nat.mul_le_mul_left (3^L) small]
    · refine ⟨fun b => t++List.ofFn b,start,?_⟩
      have h : (t.length+L)^2 ≤ C := Nat.pow_le_pow_left (by omega) 2
      simp only [List.length_append,List.length_ofFn,Finset.sum_const,
        Finset.card_univ,Fintype.card_fun,Fintype.card_fin,nsmul_eq_mul]
      exact Nat.mul_le_mul_left _ (by omega)
  choose rule leg bounds using policy
  exact full_of_square_drift hL rule leg bounds

private theorem residue_exists (u : Resid) : ∃ d : ℕ, ∃ r, Erases u r ∧ r.length=d :=
  ⟨u.length,u,.refl _,rfl⟩

noncomputable def minResidue (u : Resid) : ℕ := by
  classical
  exact Nat.find (residue_exists u)

private theorem attains (u : Resid) : ∃ r, Erases u r ∧ r.length = minResidue u := by
  classical
  exact Nat.find_spec (residue_exists u)

private theorem rename_erase (e : Equiv.Perm (Fin 3)) {s t : Resid} (h : Erases s t) :
    Erases (s.map e) (t.map e) := by
  induction h with
  | refl => exact .refl _
  | next hs _ ih =>
    apply Erases.next _ ih
    cases hs with
    | pair l r a => simpa using SmallErase.pair (l.map e) (r.map e) (e a)
    | triple l r a => simpa using SmallErase.triple (l.map e) (r.map e) (e a)

private theorem min_rename (e : Equiv.Perm (Fin 3)) (u : Resid) :
    minResidue (u.map e) = minResidue u := by
  classical
  have le (g : Equiv.Perm (Fin 3)) (v : Resid) : minResidue (v.map g) ≤ minResidue v := by
    obtain ⟨r,er,hl⟩ := attains v
    apply Nat.find_min' (residue_exists _) _
    exact ⟨r.map g,rename_erase g er,by simpa using hl⟩
  exact le_antisymm (le e u) (by simpa [List.map_map] using le e.symm (u.map e))

private theorem proper_map (e : Equiv.Perm (Fin 3)) (u : Resid) (hu : FusionProper u) :
    FusionProper (u.map e) := by
  induction u with
  | nil => trivial
  | cons a u ih =>
    refine ⟨?_,ih hu.2⟩
    cases u with
    | nil => simp
    | cons b v => simpa using (show b ≠ a from fun h => hu.1 (by simp [h]))

/-- For length-eight tails it suffices to check the 64 normalized rows,
each summing over exactly 3^L equally weighted raw words. -/
theorem full_of_normalized_eight {L : ℕ} (hL : 0<L)
    (rows : ∀ u : Resid, u.length=8 → FusionProper u → u.drop 6=[1,0] →
      (∑ b : Input L, minResidue (u++List.ofFn b)) ≤ 3^L*8) : FullTernaryGrowth := by
  classical
  apply full_of_finite_tail_mean (K:=8) hL
  intro u hu hp
  have dl : (u.drop 6).length=2 := by simp [hu]
  have dp := proper_drop u hp 6
  generalize he : u.drop 6 = tail at dl dp
  obtain ⟨a,b,ht⟩ : ∃ a b : Fin 3, tail=[a,b] := by
    cases tail with
    | nil => simp at dl
    | cons a l =>
      cases l with
      | nil => simp at dl
      | cons b r => use a,b; simpa using dl
  subst tail
  rw [ht] at dp
  have ab : a ≠ b := by rintro rfl; exact dp.1 rfl
  let f := Equiv.swap b (0 : Fin 3)
  have fb : f b=0 := Equiv.swap_apply_left _ _
  have fa : f a ≠ 0 := by rw [←fb]; exact fun h => ab (f.injective h)
  let e := f.trans (Equiv.swap (f a) 1)
  have ea : e a = 1 := Equiv.swap_apply_left _ _
  have eb : e b = 0 := by simp [e,fb,Equiv.swap_apply_of_ne_of_ne,Ne.symm fa]
  have r := rows (u.map e) (by simpa using hu) (proper_map e u hp) (by
    rw [←List.map_drop,ht]; simp [ea,eb])
  let perm : Input L ≃ Input L := Equiv.arrowCongr (Equiv.refl _) e
  have reindex := perm.sum_comp (fun b : Input L => minResidue (u.map e ++ List.ofFn b))
  have term (b : Input L) : minResidue (u.map e ++ List.ofFn (perm b)) =
      minResidue (u ++ List.ofFn b) := by
    convert min_rename e (u++List.ofFn b) using 2
    simp [List.map_ofFn,perm,Function.comp_def]; rfl
  simp_rw [term] at reindex
  choose rule leg hl using fun b : Input L => attains (u++List.ofFn b)
  exact ⟨rule,leg,by simpa only [hl] using reindex.le.trans r⟩

#print axioms full_of_normalized_eight
#print axioms full_of_finite_tail_mean
#print axioms full_of_square_drift
end LC004.RawGrowth
