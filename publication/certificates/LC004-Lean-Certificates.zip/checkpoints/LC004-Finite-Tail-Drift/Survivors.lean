import LC004.RawCertificateEquivalence
namespace LC004

/-- The output consists of retained single letters, separated by empty-erasing spans. -/
inductive ResiduePlan {q : ℕ} : List (Fin q) → List (Fin q) → Prop where
  | nil : ResiduePlan [] []
  | keep (a) {w r} : ResiduePlan w r → ResiduePlan (a::w) (a::r)
  | skip {g w r} : Erases g [] → ResiduePlan w r → ResiduePlan (g++w) r

private theorem plan_refl {q : ℕ} (w : List (Fin q)) : ResiduePlan w w := by
  induction w with
  | nil => exact .nil
  | cons a w ih => exact .keep a ih

private theorem plan_insert {q : ℕ} {w z g : List (Fin q)} (p : ResiduePlan w z)
    (eg : Erases g []) : ∀ l r, w=l++r → ResiduePlan (l++g++r) z := by
  induction p with
  | nil =>
    intro l r eq
    have ht := List.append_eq_nil_iff.mp eq.symm
    simpa [ht.1,ht.2] using (ResiduePlan.skip eg ResiduePlan.nil)
  | @keep a w z p ih =>
    intro l r eq
    cases l with
    | nil =>
      simp only [List.nil_append] at eq ⊢
      subst r
      exact .skip eg (.keep a p)
    | cons b l =>
      obtain ⟨rfl,hh⟩ := List.cons.inj eq
      exact .keep a (ih l r hh)
  | @skip c w z ec p ih =>
    intro l r eq
    rcases List.append_eq_append_iff.mp eq with ⟨v,rfl,hw⟩ | ⟨v,rfl,hr⟩
    · simpa [List.append_assoc] using ResiduePlan.skip ec (ih v r hw)
    · have shrink : Erases (l++g++v) (l++v) := by simpa using erases_context eg l v
      simpa [hr,List.append_assoc] using ResiduePlan.skip (erases_trans shrink ec) p

theorem erases_iff_residue_plan {q : ℕ} (w r : List (Fin q)) :
    Erases w r ↔ ResiduePlan w r := by
  constructor
  · intro h
    induction h with
    | refl v => exact plan_refl v
    | next step _ ih =>
      cases step with
      | pair l t a =>
        apply plan_insert ih (g:=[a,a]) _ l t rfl
        exact .next (SmallErase.pair [] [] a) (.refl [])
      | triple l t a =>
        apply plan_insert ih (g:=[a,a,a]) _ l t rfl
        exact .next (SmallErase.triple [] [] a) (.refl [])
  · intro h
    induction h with
    | nil => exact .refl []
    | keep a _ ih => simpa using erases_context ih [a] []
    | @skip g v r eg _ ih => exact erases_trans (by simpa using erases_context eg [] v) ih

#print axioms erases_iff_residue_plan
end LC004
