import Std

namespace DirectDeletionWeightedNumerics
set_option maxRecDepth 10000
set_option maxHeartbeats 0

-- Exact unreduced rational pairs. Every comparison also checks denominators.
abbrev Q := Int × Int
def q (n : Int) (d : Int := 1) : Q := (n,d)
def add (a b : Q) : Q := (a.1*b.2+b.1*a.2,a.2*b.2)
def sub (a b : Q) : Q := (a.1*b.2-b.1*a.2,a.2*b.2)
def mul (a b : Q) : Q := (a.1*b.1,a.2*b.2)
def div (a b : Q) : Q := (a.1*b.2,a.2*b.1)
def pow (a : Q) (n : Nat) : Q := (a.1^n,a.2^n)
def lt (a b : Q) : Bool := decide (0<a.2 ∧ 0<b.2 ∧ a.1*b.2 < b.1*a.2)
local infixl:65 " +q " => add
local infixl:65 " -q " => sub
local infixl:70 " *q " => mul
local infixl:70 " /q " => div

def x (s : Q) : Q := s /q ((q 1 -q s) *q (q 2 +q s))
def z (t : Q) : Q := q 2 *q t /q (q 1 -q t)
def pure8 (a : Q) : Q :=
  a/q q 2 +q q 1 4 *q pow a 2 +q q 3 8 *q pow a 3 +q q 5 16 *q pow a 4 +q
  q 11 32 *q pow a 5 +q q 21 64 *q pow a 6 +q q 43 128 *q pow a 7 +q q 85 256 *q pow a 8

def root (t s a y : Q) : Bool :=
  lt (q 0) y && lt (z t *q y) (q 1) &&
  lt (a +q pow (z t) 2 *q y /q (q 1 -q z t *q y)) s

theorem letters_root :
    let t := q 7641 20000
    let u := q 103 500
    root t (q 21 200) (z t *q t *q pow u 2 *q (q 1 -q t) /q (q 1 -q t *q u)) (x (q 21 200)) = true := by decide

theorem short_root :
    let t := q 6961 20000
    let u := q 23 1000
    root t (q 26 125) (z t *q (pow t 3 +q u *q (t -q pow t 3))) (x (q 26 125)) = true := by decide

theorem merge_root :
    let t := q 3391 10000
    let s := q 359 1000
    let a := z t *q t
    (lt a s && root t s a (x s -q (q 1 -q q 1 1000) *q x a)) = true := by decide

theorem short_gap_root :
    let t := q 3389 10000
    let s := q 359 1000
    let a := z t *q t
    (lt a s && root t s a (x s -q (q 1 -q q 1 1000) *q pure8 a)) = true := by decide

theorem letters_bound :
    (20000*5000 : Nat)^2000 * 500^167 <
    (7641*14933 : Nat)^2000 * 103^167 := by decide +kernel

theorem short_bound :
    (20000*5000 : Nat)^5000 * 1000^51 <
    (6961*14933 : Nat)^5000 * 23^51 := by decide +kernel

theorem merge_bound :
    (10000*500 : Nat)^5000 * 1000^9 <
    (3391*1493 : Nat)^5000 := by decide +kernel

theorem short_gap_bound :
    (10000*500 : Nat)^10000 * 1000^17 <
    (3389*1493 : Nat)^10000 := by decide +kernel

#print axioms letters_root
#print axioms short_root
#print axioms merge_root
#print axioms short_gap_root
#print axioms letters_bound
#print axioms short_bound
#print axioms merge_bound
#print axioms short_gap_bound
end DirectDeletionWeightedNumerics
