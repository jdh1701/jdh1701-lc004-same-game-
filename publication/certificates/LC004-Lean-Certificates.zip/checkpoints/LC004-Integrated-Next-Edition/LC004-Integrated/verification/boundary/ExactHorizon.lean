import Std

namespace ExactHorizon

variable {α : Type}

/-- A positive Boolean language respects the support relation aa = 1 OR a
in every two-sided context. -/
def Square (L : List α → Prop) : Prop :=
  ∀ (l : List α) (a : α) (r : List α),
    L (l ++ a :: a :: r) ↔ L (l ++ r) ∨ L (l ++ a :: r)

def Proper (w : List α) : Prop :=
  ¬ ∃ (l : List α) (a : α) (r : List α), w = l ++ a :: a :: r

/-- The single displayed long can include a like-colored adjacent boundary
letter. The proper child ensures there is precisely one nonsingleton run. -/
def Probe (h : Nat) (w : List α) : Prop :=
  w.length = h ∧ (Proper w ∨ ∃ (l : List α) (a : α) (r : List α) (k : Nat),
    w = l ++ List.replicate (k + 2) a ++ r ∧
    (Proper (l ++ r) ∨ Proper (l ++ a :: r)))

theorem padding {L : List α → Prop} (hs : Square L)
    (l : List α) (a : α) (r : List α) (k : Nat) :
    L (l ++ List.replicate (k+2) a ++ r) ↔ L (l ++ a :: a :: r) := by
  have triple (v : List α) : L (l ++ a :: a :: a :: v) ↔ L (l ++ a :: a :: v) := by
    rw [hs l a (a :: v), hs l a v]
    exact ⟨fun z => z.elim Or.inr id, Or.inr⟩
  induction k with
  | zero => simp [List.replicate_succ]
  | succ k ih =>
    simp only [List.replicate_succ, List.cons_append, List.append_assoc] at ih ⊢
    exact (triple (List.replicate k a ++ r)).trans ih

private theorem last_pair {L M : List α → Prop} (hs : Square L) (ht : Square M)
    (w : List α) (hn : ¬ Proper w) (hl : L w) (hm : ¬ M w) :
    ∃ (l : List α) (a : α) (r : List α),
      (l ++ a :: a :: r).length ≤ w.length ∧
      (Proper (l ++ r) ∨ Proper (l ++ a :: r)) ∧
      L (l ++ a :: a :: r) ∧ ¬ M (l ++ a :: a :: r) := by
  classical
  obtain ⟨l,a,r,rfl⟩ := Classical.byContradiction (fun h => hn h)
  have hbad : ¬ (M (l ++ r) ∨ M (l ++ a :: r)) := fun j => hm ((ht l a r).mpr j)
  rcases (hs l a r).mp hl with left | right
  · by_cases p : Proper (l ++ r)
    · exact ⟨l,a,r,Nat.le_refl _,Or.inl p,hl,hm⟩
    · obtain ⟨x,b,y,k,d,e,f⟩ := last_pair hs ht (l ++ r) p left
        (fun h => hbad (Or.inl h))
      exact ⟨x,b,y,by simp_all only [List.length_append, List.length_cons]; omega,d,e,f⟩
  · by_cases p : Proper (l ++ a :: r)
    · exact ⟨l,a,r,Nat.le_refl _,Or.inr p,hl,hm⟩
    · obtain ⟨x,b,y,k,d,e,f⟩ := last_pair hs ht (l ++ a :: r) p right
        (fun h => hbad (Or.inr h))
      exact ⟨x,b,y,by simp_all only [List.length_append, List.length_cons]; omega,d,e,f⟩
termination_by w.length
decreasing_by all_goals subst_vars; simp_all <;> omega

private theorem separator {L M : List α → Prop} (hs : Square L) (ht : Square M)
    (w : List α) (hl : L w) (hm : ¬ M w) :
    ∃ v, Probe w.length v ∧ L v ∧ ¬ M v := by
  classical
  by_cases p : Proper w
  · exact ⟨w,⟨rfl,Or.inl p⟩,hl,hm⟩
  obtain ⟨l,a,r,k,d,e,f⟩ := last_pair hs ht w p hl hm
  let n := w.length - (l ++ a :: a :: r).length
  let v := l ++ List.replicate (n+2) a ++ r
  have len : v.length = w.length := by
    simp only [v,n,List.length_append,List.length_replicate,List.length_cons] at *
    omega
  exact ⟨v,⟨len,Or.inr ⟨l,a,r,n,rfl,d⟩⟩,(padding hs l a r n).mpr e,
      fun h => f ((padding ht l a r n).mp h)⟩

theorem exact_horizon_iff_probes {L M : List α → Prop}
    (hs : Square L) (ht : Square M) (h : Nat) :
    (∀ w : List α, w.length = h → (L w ↔ M w)) ↔
    (∀ w : List α, Probe h w → (L w ↔ M w)) := by
  classical
  constructor
  · exact fun allw w p => allw w p.1
  · intro tests w hw
    subst h
    constructor
    · intro l
      apply Classical.byContradiction
      intro m
      obtain ⟨v,p,a,b⟩ := separator hs ht w l m
      exact b ((tests v p).mp a)
    · intro m
      apply Classical.byContradiction
      intro l
      obtain ⟨v,p,a,b⟩ := separator ht hs w m l
      exact b ((tests v p).mpr a)



section Fusion
variable [DecidableEq α]

/-- Top first. The same push/pop/stay transition as the public FusionStack. -/
def good : List α → Prop
  | [] => True
  | a :: s => s.head? ≠ some a ∧ good s

def act (a : α) (F : List α → Prop) (s : List α) : Prop :=
  if s.head? = some a then F s ∨ F s.tail else F (a :: s)

def eval (w : List α) (F : List α → Prop) (s : List α) : Prop :=
  match w with
  | [] => F s
  | a :: r => act a (eval r F) s

theorem square_at (a : α) (F : List α → Prop) (s : List α) (g : good s) :
    act a (act a F) s ↔ F s ∨ act a F s := by
  cases s with
  | nil => simp [act,or_comm]
  | cons b u =>
    by_cases e : b = a
    · subst b
      have n := g.1
      simp [act,n,or_assoc,or_left_comm,or_comm]
    · simp [act,e,or_comm]

theorem eval_agrees_on_good {F G : List α → Prop}
    (agree : ∀ s, good s → (F s ↔ G s)) (w s : List α) (g : good s) :
    eval w F s ↔ eval w G s := by
  induction w generalizing s with
  | nil => exact agree s g
  | cons a r ih =>
    by_cases c : s.head? = some a
    · obtain ⟨t,rfl⟩ := List.head?_eq_some_iff.mp c
      simpa [eval,act] using (or_congr (ih (a::t) g) (ih t g.2))
    · simpa [eval,act,c] using ih (a::s) ⟨c,g⟩

theorem eval_or (F G : List α → Prop) (w s : List α) :
    eval w (fun t => F t ∨ G t) s ↔ eval w F s ∨ eval w G s := by
  induction w generalizing s with
  | nil => rfl
  | cons a w ih =>
    by_cases c : s.head? = some a
    · simp [eval,act,c,ih,or_assoc,or_left_comm,or_comm]
    · simp [eval,act,c,ih]

theorem eval_append (l r s : List α) (F : List α → Prop) :
    eval (l ++ r) F s ↔ eval l (eval r F) s := by
  induction l generalizing s with
  | nil => rfl
  | cons a l ih =>
    by_cases c : s.head? = some a <;> simp [eval,act,c,ih]

theorem square_from_stack (s : List α) (g : good s) (F : List α → Prop) :
    Square (fun w => eval w F s) := by
  intro l a r
  simp only [eval_append,eval]
  exact (eval_agrees_on_good (fun t p => square_at a (eval r F) t p) l s g).trans
    (eval_or (eval r F) (act a (eval r F)) l s)

def accepts (S : List α → Prop) (w : List α) : Prop :=
  ∃ s, S s ∧ good s ∧ eval w (fun t => t = []) s

theorem accepts_square (S : List α → Prop) : Square (accepts S) := by
  intro l a r
  constructor
  · rintro ⟨s,ss,gs,h⟩
    rcases (square_from_stack s gs (fun t => t = []) l a r).mp h with x | y
    · exact Or.inl ⟨s,ss,gs,x⟩
    · exact Or.inr ⟨s,ss,gs,y⟩
  · intro h
    rcases h with ⟨s,ss,gs,x⟩ | ⟨s,ss,gs,y⟩
    · exact ⟨s,ss,gs,(square_from_stack s gs (fun t => t = []) l a r).mpr (Or.inl x)⟩
    · exact ⟨s,ss,gs,(square_from_stack s gs (fun t => t = []) l a r).mpr (Or.inr y)⟩

theorem fusion_exact_horizon (S T : List α → Prop) (h : Nat) :
    (∀ w : List α, w.length = h → (accepts S w ↔ accepts T w)) ↔
    (∀ w : List α, Probe h w → (accepts S w ↔ accepts T w)) :=
  exact_horizon_iff_probes (accepts_square S) (accepts_square T) h

#print axioms fusion_exact_horizon
end Fusion
end ExactHorizon
