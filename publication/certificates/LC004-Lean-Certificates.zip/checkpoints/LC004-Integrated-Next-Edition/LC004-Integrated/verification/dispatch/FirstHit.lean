import Lean

namespace LC004.PhaseDispatch

abbrev Packet (α : Type) := α × Bool  -- true permits singleton-block deletion
inductive Clears {α : Type} : List (Packet α) → Prop where
  | nil : Clears []
  | skip (c : α) (t : List (Packet α)) : Clears t → Clears ((c,true) :: t)
  | pair (c : α) (b f : Bool) (g t : List (Packet α)) :
      Clears g → Clears t → Clears ((c,b) :: (g ++ [(c,f)] ++ t))
  | triple (c : α) (b d f : Bool) (g h t : List (Packet α)) :
      Clears g → Clears h → Clears t →
      Clears ((c,b) :: (g ++ [(c,d)] ++ h ++ [(c,f)] ++ t))

/-- A mandatory first packet is discharged at an equal-colored endpoint
of a nonempty winning prefix. A following suffix may also be present. -/
theorem rootedPrefix {α} (c : α) (xs : List (Packet α))
    (h : Clears ((c,false)::xs)) :
    ∃ (p : List (Packet α)) (f : Bool) (t : List (Packet α)),
      (c,false)::xs = (p ++ [(c,f)]) ++ t ∧ Clears (p ++ [(c,f)]) := by
  cases h with
  | pair _ _ f g t hg _ =>
    refine ⟨(c,false)::g, f, t, rfl, ?_⟩
    simpa using (Clears.pair c false f g [] hg Clears.nil)
  | triple _ _ d f g h t hg hh _ =>
    refine ⟨(c,false)::(g ++ [(c,d)] ++ h), f, t, rfl, ?_⟩
    simpa using (Clears.triple c false d f g h [] hg hh Clears.nil)

/-- The final color of a first winning prefix equals its mandatory root color. -/
theorem firstHitEndpoint {α} (c : α) (xs : List (Packet α))
    (hc : Clears ((c,false)::xs))
    (first : ∀ (p t : List (Packet α)), (c,false)::xs = p ++ t →
      p ≠ [] → t ≠ [] → ¬ Clears p) :
    ∃ (p : List (Packet α)) (f : Bool), (c,false)::xs = p ++ [(c,f)] := by
  obtain ⟨p,f,t,form,hp⟩ := rootedPrefix c xs hc
  cases t with
  | nil => exact ⟨p,f,by simpa using form⟩
  | cons z zs => exact False.elim ((first _ _ form (by simp) (by simp)) hp)

/-- H+499/1000 times the E flag, on the one-step N dispatch.
The numerator is measured in units of 1/(6*1000). -/
theorem differingDrift : (2 : Int)*(1000+499) - 3*1000 = -2 := by decide

/-- The miss and the terminal fallback cost may be arbitrarily dependent. -/
theorem hockey (c d u : Int) (miss finalEqual : Bool) :
    (if miss then 1000*d + (if finalEqual then 0 else -725) else -c)
      ≤ -c + (c+1000*u)*(if miss then 1 else 0) + 1000*max 0 (d-u) := by
  cases miss <;> cases finalEqual <;> simp <;> omega

/-- Given the external upper enclosures on the excess (units 1e-9),
these comparisons imply strict negative drift for the indicated miss fractions. -/
def driftCheck (k u ppm nano : Nat) : Prop :=
  (1000*u+1000*k+725)*ppm*1000 + 1000*nano < (1000*k+725)*1000000000
instance (k u ppm nano : Nat) : Decidable (driftCheck k u ppm nano) :=
  inferInstanceAs (Decidable (_ < _))
theorem scalarMargins : driftCheck 1 157 10192 107179230 ∧
    driftCheck 2 152 16494 172932507 ∧ driftCheck 3 148 22908 249251187 := by
  decide +kernel
#print axioms scalarMargins
#print axioms rootedPrefix
#print axioms firstHitEndpoint
#print axioms differingDrift
#print axioms hockey
end LC004.PhaseDispatch
