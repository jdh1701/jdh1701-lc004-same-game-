import FirstHit
import AdaptiveRepair

namespace LC004.PhaseDispatch
open LC004.AdaptiveRepair
open LC004.CorePeel

/-- A mandatory logical packet may have any positive physical multiplicity.
An optional logical packet needs suffix least two. -/
inductive Realizes {α : Type} : List (Packet α) → List (Token α) → Prop where
  | nil : Realizes [] []
  | cons (c : α) (b : Bool) (k : Nat) {w v} (ok : b = true → 0 < k) :
      Realizes w v → Realizes ((c,b)::w) ((c,k)::v)

theorem realizesSplit {α} {u v : List (Packet α)} {xs}
    (h : Realizes (u ++ v) xs) :
    ∃ a b, xs = a ++ b ∧ Realizes u a ∧ Realizes v b := by
  induction u generalizing xs with
  | nil => exact ⟨[],xs,rfl,.nil,h⟩
  | cons p u ih =>
    cases h with
    | cons c f k ok tail =>
      obtain ⟨a,b,rfl,ha,hb⟩ := ih tail
      exact ⟨(c,k)::a,b,rfl,.cons _ _ _ ok ha,hb⟩

theorem realizesCons {α} {c : α} {f u xs}
    (h : Realizes ((c,f)::u) xs) :
    ∃ k vs, xs = (c,k)::vs ∧ (f = true → 0 < k) ∧ Realizes u vs := by
  cases h with | cons _ _ k ok tail => exact ⟨k,_,rfl,ok,tail⟩

/-- Each grammar witness with arbitrary compatible physical multiplicities
acts inside any fixed frame. This is a soundness statement. -/
theorem grammarFramed {α} {w : List (Packet α)} (h : Clears w) :
    ∀ {xs} (_ : Realizes w xs) (l r : List (Token α)) {out},
    PacketReduced (l ++ r) out → PacketReduced (l ++ xs ++ r) out := by
  induction h with
  | nil =>
    intro xs hs l r out endpf
    cases hs
    simpa using endpf
  | skip c t ht ih =>
    intro xs hs l r out endpf
    obtain ⟨k,ys,rfl,ok,hy⟩ := realizesCons hs
    have pos := ok rfl
    cases k with
    | zero => omega
    | succ k =>
      simpa [List.append_assoc] using
        (PacketReduced.drop l (ys++r) c k (by simpa [List.append_assoc] using ih hy l r endpf))
  | pair c b f g t hg ht ig it =>
    intro xs hs l r out endpf
    obtain ⟨i,_,rfl,_,hr⟩ := realizesCons hs
    obtain ⟨ag,suffix',rfl,hag,hat'⟩ := realizesSplit (by simpa [List.append_assoc] using hr : Realizes (g ++ ([(c,f)] ++ t)) _)
    obtain ⟨j,suffix,rfl,_,hat⟩ := realizesCons hat'
    have ht' := it hat l r endpf
    have pair := PacketReduced.pair l (suffix++r) c i j (by simpa [List.append_assoc] using ht')
    have res := ig hag (l++[(c,i)]) ((c,j)::(suffix++r)) (by simpa [List.append_assoc] using pair)
    simpa [List.append_assoc] using res
  | triple c b d f g h t hg hh ht ig ih it =>
    intro xs hs l r out endpf
    obtain ⟨i,_,rfl,_,hr⟩ := realizesCons hs
    obtain ⟨ag,_,rfl,hag,hrest⟩ := realizesSplit
      (by simpa [List.append_assoc] using hr : Realizes (g ++ ([(c,d)] ++ h ++ [(c,f)] ++ t)) _)
    obtain ⟨j,_,rfl,_,hrest⟩ := realizesCons hrest
    obtain ⟨ah,_,rfl,hah,hrest⟩ := realizesSplit
      (by simpa [List.append_assoc] using hrest : Realizes (h ++ ([(c,f)] ++ t)) _)
    obtain ⟨k,suffix,rfl,_,hat⟩ := realizesCons hrest
    have ht' := it hat l r endpf
    have trip := PacketReduced.triple l (suffix++r) c i j k (by simpa [List.append_assoc] using ht')
    have rh := ih hah (l++[(c,i),(c,j)]) ((c,k)::(suffix++r)) (by simpa [List.append_assoc] using trip)
    have rg := ig hag (l++[(c,i)]) ((c,j)::(ah++(c,k)::(suffix++r))) (by simpa [List.append_assoc] using rh)
    simpa [List.append_assoc] using rg

theorem inflatedFrame {α} {w : List (Packet α)} {xs} (h : Clears w) (hr : Realizes w xs)
    (l r : List α) : Reduced (l ++ expand xs ++ r) (l ++ r) := by
  have p : PacketReduced xs [] := by simpa using grammarFramed h hr [] [] (.same [])
  simpa [expand] using surround (lift_packets p) l r

#print axioms grammarFramed
#print axioms inflatedFrame
end LC004.PhaseDispatch
