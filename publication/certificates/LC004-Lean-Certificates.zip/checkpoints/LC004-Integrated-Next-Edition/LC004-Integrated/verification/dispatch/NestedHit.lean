import FirstHit

namespace LC004.PhaseDispatch

theorem firstMate {α} (a : α) (ys : List (Packet α))
    (h : Clears ((a,false)::ys)) :
    ∃ (g : List (Packet α)) (f : Bool) (t : List (Packet α)),
        ys = g ++ (a,f)::t ∧ Clears g := by
  cases h with
  | pair _ _ f g t hg _ => exact ⟨g,f,t,by simp,hg⟩
  | triple _ _ f b g h t hg _ _ => exact ⟨g,f,h ++ [(a,b)] ++ t,by simp [List.append_assoc],hg⟩

theorem oneMandatoryNever {α} (a : α) : ¬ Clears [(a,false)] := by
  intro h
  obtain ⟨g,f,t,eq,_⟩ := firstMate a [] h
  cases g <;> simp at eq

theorem twoProperNever {α} {a b : α} (ne : a ≠ b) : ¬ Clears [(a,false),(b,false)] := by
  intro h
  obtain ⟨g,f,t,eq,_⟩ := firstMate a [(b,false)] h
  cases g with
  | nil => simp at eq; exact ne eq.1.1.symm
  | cons p ps => simp at eq

/-- On one raw transcript every clearing of the three old mandatory packets
forces a strictly earlier nonempty clearing prefix for the top two. -/
theorem tripleHitForcesPair {α} {a b c : α} (ab : a ≠ b) (bc : b ≠ c)
    {x : List (Packet α)} (win : Clears ((a,false)::(b,false)::(c,false)::x)) :
    ∃ u v, x = u ++ v ∧ u ≠ [] ∧ v ≠ [] ∧ Clears ((b,false)::(c,false)::u) := by
  obtain ⟨g,f,t,eq,hg⟩ := firstMate a _ win
  cases g with
  | nil => simp at eq; exact False.elim (ab eq.1.1.symm)
  | cons p ps =>
    have ep : (b,false) = p := (List.cons.inj eq).1
    subst p
    have rem := (List.cons.inj eq).2
    cases ps with
    | nil => exact False.elim (oneMandatoryNever b hg)
    | cons q qs =>
      have eq2 : (c,false) = q := (List.cons.inj rem).1
      subst q
      have tail := (List.cons.inj rem).2
      refine ⟨qs,(a,f)::t,tail,?_,by simp,hg⟩
      intro h
      subst qs
      exact twoProperNever bc hg

#print axioms tripleHitForcesPair
end LC004.PhaseDispatch
