import CorePeel

namespace LC004.AdaptiveRepair
open LC004.CorePeel
variable {α : Type}

abbrev Token (α : Type) := α × Nat

def expand : List (Token α) → List α
  | [] => []
  | (a,k) :: t => List.replicate (k+1) a ++ expand t

theorem expand_append (p t : List (Token α)) :
    expand (p++t) = expand p ++ expand t := by
  induction p with
  | nil => simp [expand]
  | cons a p ih => cases a <;> simp [expand,ih,List.append_assoc]

theorem repeat_add (a : α) (x y : Nat) :
    List.replicate (x+y) a = List.replicate x a ++ List.replicate y a := by
  induction x with
  | zero => simp
  | succ x ih =>
    have e : x+1+y = x+y+1 := by omega
    rw [e]
    simp only [List.replicate_succ,List.cons_append,ih]

theorem long_clears (a : α) (n : Nat) (h : 2 ≤ n) :
    Reduced (List.replicate n a) [] := by
  induction n using Nat.strongRecOn with
  | ind n ih =>
    by_cases h2 : n = 2
    · subst n
      exact Reduced.pair [] [] a (Reduced.same [])
    by_cases h3 : n = 3
    · subst n
      exact Reduced.triple [] [] a (Reduced.same [])
    have hrec := ih (n-2) (by omega) (by omega)
    have hn : n = 2 + (n-2) := by omega
    rw [hn,repeat_add]
    exact Reduced.pair [] (List.replicate (n-2) a) a hrec

/-- The logical moves used in the window recurrence. Second components
    record the number of copies beyond the first. -/
inductive PacketReduced : List (Token α) → List (Token α) → Prop where
  | same (w) : PacketReduced w w
  | drop (p t : List (Token α)) (a : α) (k : Nat) :
      PacketReduced (p++t) v → PacketReduced (p++[(a,k+1)]++t) v
  | pair (p t : List (Token α)) (a : α) (i j : Nat) :
      PacketReduced (p++t) v → PacketReduced (p++[(a,i),(a,j)]++t) v
  | triple (p t : List (Token α)) (a : α) (i j k : Nat) :
      PacketReduced (p++t) v → PacketReduced (p++[(a,i),(a,j),(a,k)]++t) v

theorem lift_packets {w v : List (Token α)} (h : PacketReduced w v) :
    Reduced (expand w) (expand v) := by
  induction h with
  | same w => exact Reduced.same _
  | drop p t a k h ih =>
    apply chain (v := expand p ++ expand t)
    · simpa [expand_append,expand,List.append_assoc] using
        surround (long_clears a (k+1+1) (by omega)) (expand p) (expand t)
    · simpa [expand_append] using ih
  | pair p t a i j h ih =>
    apply chain (v := expand p ++ expand t)
    · have hr := long_clears a ((i+1)+(j+1)) (by omega)
      rw [repeat_add] at hr
      simpa only [expand_append,expand,List.append_assoc,List.append_nil,List.nil_append] using surround hr (expand p) (expand t)
    · simpa [expand_append] using ih
  | triple p t a i j k h ih =>
    apply chain (v := expand p ++ expand t)
    · have hr := long_clears a ((i+1)+((j+1)+(k+1))) (by omega)
      rw [repeat_add,repeat_add a (j+1)] at hr
      simpa only [expand_append,expand,List.append_assoc,List.append_nil,List.nil_append] using surround hr (expand p) (expand t)
    · simpa [expand_append] using ih

def complement : List (Token α) → List α
  | [] => []
  | (a,_) :: t => complement t ++ [a]

theorem complement_length (s : List (Token α)) :
    (complement s).length = s.length := by
  induction s with
  | nil => rfl
  | cons x s ih => cases x <;> simp [complement,ih]

theorem complement_clears (s : List (Token α)) :
    Reduced (expand s ++ complement s) [] := by
  induction s with
  | nil => exact Reduced.same []
  | cons x s ih =>
    obtain ⟨a,k⟩ := x
    apply chain (v := List.replicate (k+1) a ++ [a])
    · simpa [expand,complement,List.append_assoc] using surround ih (List.replicate (k+1) a) [a]
    · rw [show [a] = List.replicate 1 a from rfl,← repeat_add]
      exact long_clears a (k+1+1) (by omega)

def finishWord (a : α) (w : List α) (s : List (Token α)) (B : Nat) : List α :=
  w ++ complement s ++ List.replicate (B-s.length) a

theorem finish_clears {w : List α} {s : List (Token α)} (h : Reduced w (expand s))
    (a : α) (B : Nat) (enough : s.length+2 ≤ B) :
    Reduced (finishWord a w s B) [] := by
  apply chain (v := expand s ++ complement s ++ List.replicate (B-s.length) a)
  · simpa [finishWord,List.append_assoc] using surround h [] (complement s ++ List.replicate (B-s.length) a)
  apply chain (v := List.replicate (B-s.length) a)
  · simpa using surround (complement_clears s) [] (List.replicate (B-s.length) a)
  · exact long_clears a _ (by omega)

theorem finish_length (a : α) (w : List α) (s : List (Token α)) (B : Nat)
    (enough : s.length ≤ B) : (finishWord a w s B).length = w.length+B := by
  simp [finishWord,complement_length]
  omega

theorem finish_prefix (a : α) (w : List α) (s : List (Token α)) (B : Nat) :
    (finishWord a w s B).take w.length = w := by
  simp [finishWord,List.append_assoc]

theorem finish_injective_on_length (a : α) (B : Nat)
    {w v : List α} {s t : List (Token α)} (sameLength : w.length = v.length)
    (sameOutput : finishWord a w s B = finishWord a v t B) : w = v := by
  have ht := congrArg (List.take w.length) sameOutput
  rw [finish_prefix, sameLength, finish_prefix] at ht
  exact ht

#print axioms lift_packets
#print axioms finish_clears
#print axioms finish_length
#print axioms finish_prefix
#print axioms finish_injective_on_length
end LC004.AdaptiveRepair
