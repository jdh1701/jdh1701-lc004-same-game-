import Lean

namespace LC004.CorePeel
variable {α : Type}

/-- Exterior stacks are listed nearest-core first. Skip disposes of uncharged
exterior positions; left and right charge the corresponding end of the core. -/
inductive Peel : List α → List α → List α → Prop where
  | done (u z : List α) : Peel u [] z
  | skipL (a : α) : Peel u v z → Peel (a::u) v z
  | skipR (a : α) : Peel u v z → Peel u v (a::z)
  | left (a : α) : Peel u v z → Peel (a::u) (a::v) z
  | right (a : α) : Peel u v z → Peel u (v++[a]) (a::z)

theorem peel_split {u v z : List α} (e : Peel u v z) :
    ∃ p t, v=p++t ∧ List.Sublist p u ∧ List.Sublist t.reverse z := by
  induction e with
  | done u z => exact ⟨[],[],rfl,List.nil_sublist _,List.nil_sublist _⟩
  | skipL a _ ih =>
    obtain ⟨p,t,h,hp,ht⟩ := ih
    exact ⟨p,t,h,List.Sublist.cons a hp,ht⟩
  | skipR a _ ih =>
    obtain ⟨p,t,h,hp,ht⟩ := ih
    exact ⟨p,t,h,hp,List.Sublist.cons a ht⟩
  | left a _ ih =>
    obtain ⟨p,t,h,hp,ht⟩ := ih
    exact ⟨a::p,t,congrArg (List.cons a) h,List.Sublist.cons₂ a hp,ht⟩
  | right a _ ih =>
    obtain ⟨p,t,h,hp,ht⟩ := ih
    refine ⟨p,t++[a],by simp [h,List.append_assoc],hp,?_⟩
    simpa using List.Sublist.cons₂ a ht

theorem peel_budget {u v z : List α} (e : Peel u v z) :
    v.length ≤ u.length+z.length := by
  obtain ⟨p,t,rfl,hp,ht⟩ := peel_split e
  have h := hp.length_le
  have g := ht.length_le
  simp at g ⊢
  omega

theorem peel_equal {u v z : List α} (e : Peel u v z)
    (h : v.length=u.length+z.length) :
    v=u++z.reverse := by
  obtain ⟨p,t,rfl,hp,ht⟩ := peel_split e
  have h1 := hp.length_le
  have h2 := ht.length_le
  simp at h h2
  have eq1 : p.length=u.length := by omega
  have eq2 : t.reverse.length=z.length := by simpa using (show t.length=z.length by omega)
  have same1 := hp.eq_of_length eq1
  have same2 := congrArg List.reverse (ht.eq_of_length eq2)
  simpa [same1] using congrArg (List.append u) (by simpa using same2)

-- The sufficient constructions are checked against the auxiliary pair/triple reduction.
inductive Reduced : List α → List α → Prop where
  | same (w) : Reduced w w
  | pair (p s : List α) (a : α) : Reduced (p++s) w → Reduced (p++[a,a]++s) w
  | triple (p s : List α) (a : α) : Reduced (p++s) w → Reduced (p++[a,a,a]++s) w

theorem surround {u v : List α} (e : Reduced u v) (l r : List α) :
    Reduced (l ++ u ++ r) (l ++ v ++ r) := by
  induction e with
  | same => exact Reduced.same _
  | pair p s a _ ih =>
    simpa only [List.append_assoc] using
      (Reduced.pair (l ++ p) (s ++ r) a (by simpa only [List.append_assoc] using ih))
  | triple p s a _ ih =>
    simpa only [List.append_assoc] using
      (Reduced.triple (l ++ p) (s ++ r) a (by simpa only [List.append_assoc] using ih))

theorem chain {u v w : List α} (e : Reduced u v) (f : Reduced v w) : Reduced u w := by
  induction e with
  | same => exact f
  | pair p s a _ ih => exact Reduced.pair p s a (ih f)
  | triple p s a _ ih => exact Reduced.triple p s a (ih f)

theorem paired (p : List α) : Reduced (p.reverse++p) [] := by
  induction p with
  | nil => exact Reduced.same []
  | cons a t ih =>
    simpa [List.append_assoc] using Reduced.pair t.reverse t a ih

theorem even_construction (p t : List α) :
    Reduced (p.reverse++p++t++t.reverse) [] := by
  have ht : Reduced (t++t.reverse) [] := by simpa using paired t.reverse
  have h := surround (paired p) [] (t++t.reverse)
  exact chain (by simpa [List.append_assoc] using h) ht

theorem spanning_construction (a : α) (p t : List α) :
    Reduced ([a]++p.reverse++p++[a]++t++t.reverse++[a]) [] := by
  have ht : Reduced (t++t.reverse) [] := by simpa using paired t.reverse
  apply chain (v := [a,a]++t++t.reverse++[a])
  · simpa [List.append_assoc] using surround (paired p) [a] ([a]++t++t.reverse++[a])
  apply chain (v := [a,a,a])
  · simpa [List.append_assoc] using surround ht [a,a] [a]
  exact Reduced.triple [] [] a (Reduced.same [])

#print axioms peel_split
#print axioms peel_budget
#print axioms peel_equal
#print axioms even_construction
#print axioms spanning_construction
end LC004.CorePeel

namespace LC004.CorePeel
set_option exponentiation.threshold 256
theorem ternary_n_over_three_certificate :
    24*100000000000^3 < (988*292020529)^3 := by decide
theorem ternary_width_328_certificate :
    (2*100000000*2000)^125*3^43 < (292020529*1999)^125 := by decide
#print axioms ternary_n_over_three_certificate
#print axioms ternary_width_328_certificate
end LC004.CorePeel
