import Lean
namespace LC004.FlagDefect
-- A true bit in the first mask marks a one-packet block of the partition.
-- The second mask marks long raw runs.
def charge : List Bool → List Bool → Nat
  | b :: bs, l :: ls => (if b && !l then 1 else 0) + charge bs ls
  | _, _ => 0

theorem upgrade_charge (pre : List Bool) (tail pattern : List Bool) :
    charge pattern (pre ++ true :: tail) ≤ charge pattern (pre ++ false :: tail) ∧
    charge pattern (pre ++ false :: tail) ≤ charge pattern (pre ++ true :: tail) + 1 := by
  induction pre generalizing pattern with
  | nil => cases pattern with
    | nil => simp [charge]
    | cons b bs => cases b <;> simp [charge] <;> omega
  | cons d ds ih =>
    cases pattern with
    | nil => simp [charge]
    | cons b bs =>
      obtain ⟨h,j⟩ := ih bs
      cases b <;> cases d <;> simp [charge] at * <;> omega

-- The baseline can be any common upper bound, for instance the total run count.
def best (baseline : Nat) (patterns : List (List Bool)) (flags : List Bool) : Nat :=
  patterns.foldr (fun mask k => min (charge mask flags) k) baseline

theorem upgrade_best (baseline : Nat) (patterns : List (List Bool)) (pre tail : List Bool) :
    best baseline patterns (pre ++ true :: tail) ≤ best baseline patterns (pre ++ false :: tail) ∧
    best baseline patterns (pre ++ false :: tail) ≤ best baseline patterns (pre ++ true :: tail) + 1 := by
  induction patterns with
  | nil => simp [best]
  | cons m ms ih =>
    have h := upgrade_charge pre tail m
    change min _ (best baseline ms _) ≤ min _ (best baseline ms _) ∧
      min _ (best baseline ms _) ≤ min _ (best baseline ms _) + 1
    omega

-- In a block of two or three positions, delete every altered member.
-- If one original member remains, delete it as well. In all other cases
-- the unaffected members form a valid pair, triple, or empty block.
def discarded (size altered : Nat) := altered + if size-altered=1 then 1 else 0
theorem repair_block (size altered : Nat) (s : size=2 ∨ size=3) (h : altered ≤ size) :
    discarded size altered ≤ 2 * altered ∧
    (size - discarded size altered = 0 ∨ size - discarded size altered = 2 ∨
      size - discarded size altered = 3) := by
  unfold discarded
  split <;> omega

#print axioms upgrade_charge
#print axioms upgrade_best
#print axioms repair_block
end LC004.FlagDefect
