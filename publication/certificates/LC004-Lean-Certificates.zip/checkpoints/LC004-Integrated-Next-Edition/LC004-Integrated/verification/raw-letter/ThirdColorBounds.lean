import PolicyBounds

namespace LC004.ThirdColor

/-- Entering recovery by lowering each target credit preserves the weighted
row. The common positive denominator can be left intact in the application. -/
theorem lower_target_credits (w₀ w₁ w₂ u₀ u₁ u₂ v₀ v₁ v₂ : Int)
    (h₀ : 0 ≤ w₀) (h₁ : 0 ≤ w₁) (h₂ : 0 ≤ w₂)
    (l₀ : v₀ ≤ u₀) (l₁ : v₁ ≤ u₁) (l₂ : v₂ ≤ u₂) :
    w₀*v₀ + w₁*v₁ + w₂*v₂ ≤ w₀*u₀ + w₁*u₁ + w₂*u₂ := by
  have a := Int.mul_le_mul_of_nonneg_left l₀ h₀
  have b := Int.mul_le_mul_of_nonneg_left l₁ h₁
  have c := Int.mul_le_mul_of_nonneg_left l₂ h₂
  omega

theorem recovery_budget :
    (4396702853 : Nat) * 30000000000000000000000000 <
    14507157909669737758843 * 32000000000000 := by decide

/-- 3(1-C+C²/2-C³/6) is strictly larger than the printed decimal. -/
theorem growth_floor_arithmetic :
    let a : Nat := 14507157909669737758843
    let b : Nat := 30000000000000000000000000
    2*b^3*2998549634915 + 10^12*(6*a*b^2 + a^3) < 10^12*(6*b^3 + 3*a^2*b) := by decide

#print axioms LC004.retained_move_lift
#print axioms LC004.fusion_relabel
#print axioms lower_target_credits
#print axioms recovery_budget
#print axioms growth_floor_arithmetic
end LC004.ThirdColor
