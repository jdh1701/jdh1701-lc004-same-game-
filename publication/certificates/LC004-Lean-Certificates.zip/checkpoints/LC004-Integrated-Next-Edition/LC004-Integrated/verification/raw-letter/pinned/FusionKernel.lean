import Std

namespace LC004

/-- A stack is stored with its top first. Equal incoming colors may pop or
stay; a different incoming color is pushed. This counts no deletion histories. -/
inductive FusionEval {q : Nat} : List (Fin q) → List (Fin q) → List (Fin q) → Prop where
  | done (s) : FusionEval s [] s
  | push {s w t} (a : Fin q) (h : s.head? ≠ some a) :
      FusionEval (a :: s) w t → FusionEval s (a :: w) t
  | pop {s w t} (a : Fin q) :
      FusionEval s w t → FusionEval (a :: s) (a :: w) t
  | stay {s w t} (a : Fin q) :
      FusionEval (a :: s) w t → FusionEval (a :: s) (a :: w) t

end LC004
