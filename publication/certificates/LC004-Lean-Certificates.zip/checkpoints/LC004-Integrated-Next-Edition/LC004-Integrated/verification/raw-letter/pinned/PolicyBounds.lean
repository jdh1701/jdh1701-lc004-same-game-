import FusionKernel

namespace LC004

/-- A single legal move on a nonempty stack survives appending an arbitrary
older bottom, in the top-first order of the pinned game. -/
theorem fusion_one_letter_lift {q : Nat} {s t : List (Fin q)} {a : Fin q}
    (hs : s ≠ []) (m : FusionEval s [a] t) (bottom : List (Fin q)) :
    FusionEval (s ++ bottom) [a] (t ++ bottom) := by
  cases m with
  | push _ hn tail =>
    cases tail
    apply FusionEval.push
    · cases s with
      | nil => exact False.elim (hs rfl)
      | cons x xs => exact hn
    · exact FusionEval.done _
  | pop _ tail =>
    cases tail
    exact FusionEval.pop _ (FusionEval.done _)
  | stay _ tail =>
    cases tail
    exact FusionEval.stay _ (FusionEval.done _)

/-- Relabel the input and both end stacks by the same injective color map. -/
theorem fusion_relabel {q k : Nat} {s w t : List (Fin q)} (f : Fin q → Fin k)
    (inj : ∀ {a b}, f a = f b → a = b) (m : FusionEval s w t) :
    FusionEval (s.map f) (w.map f) (t.map f) := by
  induction m with
  | done _ => exact FusionEval.done _
  | @push s w t a hn _ ih =>
    apply FusionEval.push
    · cases s with
      | nil => simp
      | cons x xs =>
        intro eqn
        have hx : f x = f a := Option.some.inj eqn
        exact hn (congrArg some (inj hx))
    · exact ih
  | pop a _ ih => exact FusionEval.pop (f a) ih
  | stay a _ ih => exact FusionEval.stay (f a) ih

/-- Lift every witness for a retained target set, including witnesses coming
from different members of the source support. -/
theorem retained_move_lift {q : Nat} {a : Fin q} (S T : List (Fin q) → Prop)
    (nonempty : ∀ s, S s → s ≠ [])
    (edges : ∀ t, T t → ∃ s, S s ∧ FusionEval s [a] t) (bottom : List (Fin q)) :
    ∀ t, T t → ∃ s, S s ∧ FusionEval (s ++ bottom) [a] (t ++ bottom) := by
  intro t ht
  obtain ⟨s, hs, step⟩ := edges t ht
  exact ⟨s, hs, fusion_one_letter_lift (nonempty s hs) step bottom⟩

/-- At a state maximizing witness minus candidate, monotonicity and translation
covariance transfer a Bellman lower residual to any candidate potential. With
a nonempty finite state set the maximizing state always exists. -/
theorem residual_obstruction {S : Type} (T : (S → Int) → S → Int)
    (mono : ∀ f g, (∀ s, f s ≤ g s) → ∀ i, T f i ≤ T g i)
    (shift : ∀ f (v : Int) i, T (fun s => f s + v) i = T f i + 3*v)
    (w f : S → Int) (k : Int) (i : S)
    (largest : ∀ s, w s - f s ≤ w i - f i) (lower : 3*w i + k ≤ T w i) :
    3*f i + k ≤ T f i := by
  have h := mono w (fun s => f s + (w i - f i)) (by intro s; change w s ≤ f s + (w i - f i); have := largest s; omega) i
  rw [shift] at h
  omega

theorem primal_decimal :
    let a : Nat := 8884110677501
    let b : Nat := 15000000000000000
    2*b^3*2998223703943 + 10^12*(6*a*b^2 + a^3) ≤ 10^12*(6*b^3 + 3*a^2*b) := by decide

theorem dual_decimal :
    (30272546975676156660263671875 : Nat) * 1000000000000 <
      2998243556586 * 10096760454694095398945312500 := by decide

theorem context_decimal :
    let a : Nat := 1600311836743
    let b : Nat := 3000000000000000
    2*b^3*2998400114920 + 10^12*(6*a*b^2 + a^3) ≤ 10^12*(6*b^3 + 3*a^2*b) := by decide

end LC004
