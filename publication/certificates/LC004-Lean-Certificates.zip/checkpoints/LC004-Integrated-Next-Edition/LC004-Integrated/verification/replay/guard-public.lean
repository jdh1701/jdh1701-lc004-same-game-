import Lean.Util.CollectAxioms
import LC004.ConnectedCoefficientSupport
import LC004.LabeledConnectedExpansion
#print axioms LC004.labeledWinningCount_connected_expansion
#print axioms LC004.weighted_game_noncrossing_expansion
#print axioms LC004.winningJoinCoefficient_nonzero_crossed_min_five
#print axioms LC004.ncConnected_nonzero_size_bound
#print axioms LC004.connectedGamePolynomial_eval
#print axioms LC004.connectedGamePolynomial_natDegree_le

open Lean Elab Command in
set_option maxHeartbeats 0 in
run_cmd do
  let names := [`LC004.weighted_game_noncrossing_expansion, `LC004.labeledWinningCount_connected_expansion,
    `LC004.winningJoinCoefficient_nonzero_crossed_min_five, `LC004.ncConnected_nonzero_size_bound,
    `LC004.connectedGamePolynomial_eval, `LC004.connectedGamePolynomial_natDegree_le]
  for n in names do
    let axioms ← collectAxioms n
    for ax in axioms do
      unless ax == `propext || ax == `Classical.choice || ax == `Quot.sound do
        throwError "Unexpected dependency {ax} for {n}"
    logInfo m!"{n}: {axioms}"
