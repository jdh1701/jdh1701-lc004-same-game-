import Lean

namespace LC004.AdaptiveBellman

/-- A depth-indexed four-branch read tree. Optional stop is absent at
    the root, enforcing at least one read. Leaf costs can already be
    conservative integer ceilings in any common scale. -/
inductive Tree : Nat → Type where
  | leaf (stop : Nat) : Tree 0
  | node (stop : Option Nat) (a b c d : Tree n) : Tree (n+1)

def mass (p l : Nat) := p+l+p+l

def up (x m : Nat) := (x + (m-1))/m

theorem le_up_mul (x m : Nat) (hm : 0 < m) : x ≤ up x m * m := by
  have hq := Nat.mod_add_div (x+(m-1)) m
  have hr := Nat.mod_lt (x+(m-1)) hm
  rw [Nat.mul_comm]
  unfold up
  omega

def upper (p l : Nat) : Tree n → Nat
  | .leaf s => s
  | .node opt a b c d =>
    let v := up (p*upper p l a+l*upper p l b+p*upper p l c+l*upper p l d) (mass p l)
    match opt with
    | none => v
    | some s => min s v

/-- Expected cost numerator over the common denominator (mass p l)^n
    for the actual policy that compares the rounded upper bounds. -/
def cost (p l : Nat) : (tree : Tree n) → Nat
  | .leaf s => s
  | .node (n := h) opt a b c d =>
    let est := up (p*upper p l a+l*upper p l b+p*upper p l c+l*upper p l d) (mass p l)
    let subtotal := p*cost p l a+l*cost p l b+p*cost p l c+l*cost p l d
    match opt with
    | none => subtotal
    | some s => if s ≤ est then s*(mass p l)^(h+1) else subtotal

theorem upper_sound (p l : Nat) (hm : 0 < mass p l) {n : Nat} (t : Tree n) :
    cost p l t ≤ upper p l t * (mass p l)^n := by
  induction t with
  | leaf s => simp [cost,upper]
  | @node n opt a b c d ha hb hc hd =>
    let x := p*upper p l a+l*upper p l b+p*upper p l c+l*upper p l d
    let v := up x (mass p l)
    let w := p*cost p l a+l*cost p l b+p*cost p l c+l*cost p l d
    have hw : w ≤ x*(mass p l)^n := by
      change p*cost p l a+l*cost p l b+p*cost p l c+l*cost p l d ≤ _
      simp only [x,Nat.add_mul,Nat.mul_assoc]
      have h1 := Nat.mul_le_mul_left p ha
      have h2 := Nat.mul_le_mul_left l hb
      have h3 := Nat.mul_le_mul_left p hc
      have h4 := Nat.mul_le_mul_left l hd
      omega
    have hv : w ≤ v*(mass p l)^(n+1) := by
      calc
        w ≤ x*(mass p l)^n := hw
        _ ≤ (v * (mass p l))*(mass p l)^n :=
          Nat.mul_le_mul_right _ (le_up_mul x (mass p l) hm)
        _ = v*(mass p l)^(n+1) := by rw [Nat.pow_succ]; ac_rfl
    change (match opt with
      | none => w
      | some s => if s ≤ v then s*(mass p l)^(n+1) else w) ≤
      (match opt with | none => v | some s => min s v)*(mass p l)^(n+1)
    cases opt with
    | none => exact hv
    | some s =>
      by_cases hh : s ≤ v
      · simp [hh,Nat.min_eq_left hh]
      · simpa [hh,Nat.min_eq_right (show v ≤ s by omega)] using hv

#print axioms upper_sound
end LC004.AdaptiveBellman
