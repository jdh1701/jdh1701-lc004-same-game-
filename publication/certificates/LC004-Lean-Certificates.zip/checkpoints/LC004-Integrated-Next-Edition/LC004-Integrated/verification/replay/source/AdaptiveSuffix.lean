import AdaptiveRepair

namespace LC004.AdaptiveSuffix
open LC004.CorePeel LC004.AdaptiveRepair
variable {α : Type}

/-- A certified suffix policy preserving its first old token works on the
    same suffix above an arbitrary untouched deeper stack. -/
theorem anchored_frame (pre : List (Token α)) (head : Token α)
    {w v : List (Token α)} (h : PacketReduced (head::w) (head::v)) :
    Reduced (expand (pre ++ head::w)) (expand (pre ++ head::v)) := by
  simpa [expand_append] using surround (lift_packets h) (expand pre) []

/-- The multiplicative potential ratio is unchanged by the untouched stack:
    its additive contribution to the exponent cancels. -/
theorem exponent_delta (pre oldHeight newHeight : Nat) (k b : Nat)
    (oldMatch newMatch : Bool) :
    (b : Int) * (pre + newHeight : Nat) + (if newMatch then (k : Int) else 0) -
      ((b : Int) * (pre + oldHeight : Nat) + (if oldMatch then (k : Int) else 0)) =
    (b : Int) * newHeight + (if newMatch then (k : Int) else 0) -
      ((b : Int) * oldHeight + (if oldMatch then (k : Int) else 0)) := by
  simp only [Int.natCast_add,Int.mul_add]
  omega

#print axioms anchored_frame
#print axioms exponent_delta
end LC004.AdaptiveSuffix
