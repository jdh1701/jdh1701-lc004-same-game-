import PackedFallback
namespace FilteredFallback
open PackedFallback

/-- Each input bin consists of phase, nonnegative offset height, and integer mass. -/
def pack (bins : List (Bool × Nat × Nat)) (phase : Bool) : Nat :=
  bins.foldl (fun s (e,h,w) => if e == phase then s + (w <<< (h*width)) else s) 0

def safe (bins : List (Bool × Nat × Nat)) (u q : Nat) : Bool :=
  let initialE := pack bins true
  let initialN := pack bins false
  let final := evolve 500 initialE initialN
  let tail := weighted (512-u) 1 ((final.1+final.2) >>> ((u+3)*width))
  decide ((3+u)*q*6^512 + 1000000*tail < 3000000*6^512)

set_option maxRecDepth 20000
set_option maxHeartbeats 0

def bins0100 : List (Bool × Nat × Nat) := [(false, 0, 29943852), (false, 1, 42078618), (false, 2, 58837782), (false, 3, 71902578), (false, 4, 83634828), (false, 5, 91380328), (false, 6, 93028848), (false, 7, 90157216), (false, 8, 80662528), (false, 9, 67515904), (false, 10, 52660224), (false, 11, 35004416), (false, 12, 23068672), (false, 13, 8388608), (true, 1, 11600544), (true, 2, 22655544), (true, 3, 38866176), (true, 4, 53919276), (true, 5, 70234056), (true, 6, 84762032), (true, 7, 93986592), (true, 8, 100842176), (true, 9, 95879168), (true, 10, 90401792), (true, 11, 73863168), (true, 12, 57425920), (true, 13, 46137344), (true, 14, 16777216)]
theorem checked0100 : safe bins0100 188 14904 = true ∧ safe bins0100 188 14905 = false := by decide +kernel
#print axioms checked0100

def bins0101 : List (Bool × Nat × Nat) := [(false, 0, 25831074), (false, 1, 35320662), (false, 2, 49313765), (false, 3, 59791994), (false, 4, 68940312), (false, 5, 74015656), (false, 6, 74353872), (false, 7, 69070848), (false, 8, 60476224), (false, 9, 46658048), (false, 10, 33966080), (false, 11, 20647936), (false, 12, 11534336), (false, 13, 4194304), (true, 1, 10122894), (true, 2, 18893262), (true, 3, 32140714), (true, 4, 44823364), (true, 5, 57929376), (true, 6, 70967504), (true, 7, 77516448), (true, 8, 81608064), (true, 9, 77953664), (true, 10, 66282496), (true, 11, 52203520), (true, 12, 35004416), (true, 13, 23068672), (true, 14, 8388608)]
theorem checked0101 : safe bins0101 184 15154 = true ∧ safe bins0101 184 15155 = false := by decide +kernel
#print axioms checked0101

def bins0102 : List (Bool × Nat × Nat) := [(false, 0, 25811688), (false, 1, 35322426), (false, 2, 50105005), (false, 3, 60728344), (false, 4, 70046196), (false, 5, 75016320), (false, 6, 75178464), (false, 7, 69678496), (false, 8, 60844224), (false, 9, 46834688), (false, 10, 34029568), (false, 11, 20647936), (false, 12, 11534336), (false, 13, 4194304), (true, 1, 10098858), (true, 2, 18886998), (true, 3, 32449886), (true, 4, 45693032), (true, 5, 59211432), (true, 6, 72263904), (true, 7, 78703872), (true, 8, 82595648), (true, 9, 78597504), (true, 10, 66635776), (true, 11, 52330496), (true, 12, 35004416), (true, 13, 23068672), (true, 14, 8388608)]
theorem checked0102 : safe bins0102 185 15146 = true ∧ safe bins0102 185 15147 = false := by decide +kernel
#print axioms checked0102

def bins2100 : List (Bool × Nat × Nat) := [(false, 0, 30259296), (false, 1, 42575964), (false, 2, 56331692), (false, 3, 70767076), (false, 4, 81493328), (false, 5, 89647016), (false, 6, 91450128), (false, 7, 89157248), (false, 8, 80093824), (false, 9, 67348736), (false, 10, 52598784), (false, 11, 35004416), (false, 12, 23068672), (false, 13, 8388608), (true, 1, 11747724), (true, 2, 22348704), (true, 3, 35902996), (true, 4, 51571352), (true, 5, 66977344), (true, 6, 81628912), (true, 7, 91242336), (true, 8, 98835712), (true, 9, 94784768), (true, 10, 90042880), (true, 11, 73740288), (true, 12, 57425920), (true, 13, 46137344), (true, 14, 16777216)]
theorem checked2100 : safe bins2100 188 14916 = true ∧ safe bins2100 188 14917 = false := by decide +kernel
#print axioms checked2100

def bins2101 : List (Bool × Nat × Nat) := [(false, 0, 25777782), (false, 1, 35181586), (false, 2, 47103983), (false, 3, 57835548), (false, 4, 66483028), (false, 5, 71740960), (false, 6, 72280048), (false, 7, 67570080), (false, 8, 59491136), (false, 9, 46286336), (false, 10, 33935360), (false, 11, 20647936), (false, 12, 11534336), (false, 13, 4194304), (true, 1, 10104378), (true, 2, 18661358), (true, 3, 30224386), (true, 4, 42662112), (true, 5, 55128920), (true, 6, 67951040), (true, 7, 74548640), (true, 8, 79058880), (true, 9, 76008064), (true, 10, 65526784), (true, 11, 52142080), (true, 12, 35004416), (true, 13, 23068672), (true, 14, 8388608)]
theorem checked2101 : safe bins2101 184 15173 = true ∧ safe bins2101 184 15174 = false := by decide +kernel
#print axioms checked2101

def bins2102 : List (Bool × Nat × Nat) := [(false, 0, 25800552), (false, 1, 35235344), (false, 2, 47120109), (false, 3, 57890080), (false, 4, 67009756), (false, 5, 72194248), (false, 6, 72758240), (false, 7, 67958240), (false, 8, 59763008), (false, 9, 46449408), (false, 10, 33998848), (false, 11, 20647936), (false, 12, 11534336), (false, 13, 4194304), (true, 1, 10114218), (true, 2, 18508270), (true, 3, 29481138), (true, 4, 42471368), (true, 5, 55581608), (true, 6, 68400560), (true, 7, 75131200), (true, 8, 79617856), (true, 9, 76453504), (true, 10, 65852928), (true, 11, 52269056), (true, 12, 35004416), (true, 13, 23068672), (true, 14, 8388608)]
theorem checked2102 : safe bins2102 184 15170 = true ∧ safe bins2102 184 15171 = false := by decide +kernel
#print axioms checked2102
end FilteredFallback
