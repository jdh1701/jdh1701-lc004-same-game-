/- Final scalar implication. The stop-loss envelope and bin generation are external. -/
namespace FilteredPairMargin

theorem negative : (149*40+109)*16703*1000 + 40*190731133 < 109*10^9 :=
  by decide +kernel

#print axioms negative
end FilteredPairMargin
