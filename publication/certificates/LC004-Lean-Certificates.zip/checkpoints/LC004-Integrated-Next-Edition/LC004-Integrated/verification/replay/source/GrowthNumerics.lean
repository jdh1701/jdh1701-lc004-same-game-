/- Arithmetic part only. The adaptive-window controller and density transfer
are the separate hypotheses in ADAPTIVE-SUFFIX-CERT.md and ADAPTIVE-GROWTH.md. -/
def entropyComparison (p q a b : Nat) : Prop :=
  (2 * q)^q * b^(2*q - p) >
    p^p * (q-p)^(q-p) * a^q * (a-b)^(q-p)

instance (p q a b : Nat) : Decidable (entropyComparison p q a b) :=
  inferInstanceAs (Decidable ((2*q)^q * b^(2*q-p) >
      p^p * (q-p)^(q-p) * a^q * (a-b)^(q-p)))

theorem growth_cross_602 : entropyComparison 602 1000 298287 100000 := by decide +kernel
theorem growth_cross_607 : entropyComparison 607 1000 298531 100000 := by decide +kernel
theorem growth_cross_610 : entropyComparison 610 1000 298670 100000 := by decide +kernel
#print axioms growth_cross_610
