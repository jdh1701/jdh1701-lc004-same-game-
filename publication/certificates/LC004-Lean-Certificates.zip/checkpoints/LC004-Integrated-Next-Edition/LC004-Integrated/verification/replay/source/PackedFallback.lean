import Std

/- Finite arithmetic for the two-phase killed walk, with height -2 in
   the lowest digit. The correspondence to integer path counts is given
   by the carry bound in PACKED-FALLBACK.md. -/
namespace PackedFallback

def width : Nat := 1536
def lowMask : Nat := (1 <<< width) - 1

def evolve (n : Nat) (e s : Nat) : Nat × Nat :=
  match n with
  | 0 => (e, s)
  | m+1 => evolve m (((4*e + 2*s) <<< width)) (2*e + s + 3*(s >>> width))

def weighted (n k a : Nat) : Nat :=
  match n with
  | 0 => 0
  | m+1 => k * (a &&& lowMask) + weighted m (k+1) (a >>> width)

def excess (L u : Nat) (startE : Bool) : Nat :=
  let one := 1 <<< (2*width)
  let (e,s) := if startE then evolve L one 0 else evolve L 0 one
  weighted (L-u) 1 ((e+s) >>> ((u+3)*width))

def safe (early late : Nat) (q : Nat) : Prop :=
  ((early+3)*q*6^512 + 10000*excess 512 early true < 30000*6^512)
  ∧ ((late+3)*q*6^512 + 10000*excess 512 late false < 30000*6^512)

instance (a b q : Nat) : Decidable (safe a b q) := inferInstanceAs (Decidable (_ ∧ _))

set_option maxRecDepth 20000
set_option maxHeartbeats 0
theorem digitSpace : 6^512 < (1 : Nat) <<< width := by decide +kernel
theorem safe512 : safe 189 186 148 := by decide +kernel
def testPhase (u q : Nat) (e : Bool) : Bool :=
  decide ((u+3)*q*6^512+1000000*excess 512 u e < 3000000*6^512)

theorem phaseE : testPhase 189 14859 true = true ∧ testPhase 189 14860 true = false :=
  by decide +kernel
theorem phaseN : testPhase 186 15061 false = true ∧ testPhase 186 15062 false = false :=
  by decide +kernel

#print axioms phaseE
#print axioms phaseN
#print axioms digitSpace
#print axioms safe512

end PackedFallback
