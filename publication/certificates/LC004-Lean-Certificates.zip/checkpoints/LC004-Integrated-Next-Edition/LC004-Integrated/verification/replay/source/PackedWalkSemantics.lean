import PackedFallback
namespace PackedFallback

abbrev base : Nat := 2^width

/-- A list records one current height, offset by +2, per surviving weighted path. -/
def encode : List Nat → Nat
  | [] => 0
  | h::xs => base^h + encode xs

def zeros : List Nat → Nat
  | [] => 0
  | 0::xs => 1 + zeros xs
  | (_+1)::xs => zeros xs

/-- Descend once, killing each path whose current offset height is zero. -/
def down : List Nat → List Nat
  | [] => []
  | 0::xs => down xs
  | (h+1)::xs => h :: down xs

def copies (k : Nat) (xs : List Nat) : List Nat :=
  match k with
  | 0 => []
  | j+1 => xs ++ copies j xs

theorem encode_append (x y : List Nat) : encode (x++y) = encode x + encode y := by
  induction x with
  | nil => simp [encode]
  | cons a t ih => simp [encode, ih, Nat.add_assoc]

theorem encode_copies (k : Nat) (x : List Nat) : encode (copies k x) = k*encode x := by
  induction k with
  | zero => simp [copies,encode]
  | succ k ih => simp [copies,encode_append,ih,Nat.succ_mul,Nat.add_comm]

theorem copies_len (k : Nat) (x : List Nat) : (copies k x).length = k*x.length := by
  induction k with
  | zero => simp [copies]
  | succ k ih => simp [copies,ih,Nat.succ_mul,Nat.add_comm]

theorem encode_up (x : List Nat) : encode (x.map Nat.succ) = encode x * base := by
  induction x with
  | nil => simp [encode]
  | cons a t ih => simp [encode,Nat.pow_succ,ih,Nat.add_mul]

theorem zeros_le (xs : List Nat) : zeros xs ≤ xs.length := by
  induction xs with
  | nil => simp [zeros]
  | cons a t ih => cases a <;> simp [zeros] <;> omega

theorem down_len (xs : List Nat) : (down xs).length ≤ xs.length := by
  induction xs with
  | nil => simp [down]
  | cons a t ih => cases a <;> simp [down] <;> omega

theorem encode_split (x : List Nat) : encode x = zeros x + base * encode (down x) := by
  induction x with
  | nil => simp [encode,zeros,down]
  | cons a t ih =>
    cases a with
    | zero => simp [encode,zeros,down,ih,Nat.add_assoc]
    | succ h => simp only [encode,zeros,down,Nat.pow_succ,Nat.mul_add,ih]
                rw [Nat.mul_comm (base^h) base]
                omega

theorem encode_down (x : List Nat) (hl : x.length < base) :
    encode x >>> width = encode (down x) := by
  have h : zeros x < base := Nat.lt_of_le_of_lt (zeros_le x) hl
  rw [Nat.shiftRight_eq_div_pow, encode_split, Nat.add_mul_div_left _ _ (Nat.pow_pos (by decide : 0 < 2) : 0 < base),
      Nat.div_eq_of_lt h, Nat.zero_add]

theorem encode_low (x : List Nat) (hl : x.length < base) :
    encode x &&& lowMask = zeros x := by
  rw [lowMask, Nat.one_shiftLeft, Nat.and_two_pow_sub_one_eq_mod, encode_split]
  change (zeros x + base * encode (down x)) % base = zeros x
  rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (Nat.lt_of_le_of_lt (zeros_le x) hl)]

def stepPaths (e n : List Nat) : List Nat × List Nat :=
  ((copies 4 e ++ copies 2 n).map Nat.succ, copies 2 e ++ n ++ copies 3 (down n))

theorem step_encode (e n : List Nat) (hl : n.length < base) :
   (encode (stepPaths e n).1, encode (stepPaths e n).2) =
    ((4*encode e+2*encode n) <<< width, 2*encode e + encode n + 3*(encode n >>> width)) := by
  simp only [stepPaths,encode_up,encode_append,encode_copies,encode_down n hl,Nat.shiftLeft_eq]

theorem step_mass (e n : List Nat) :
 (stepPaths e n).1.length + (stepPaths e n).2.length ≤ 6*(e.length+n.length) := by
  simp only [stepPaths,List.length_map,List.length_append,copies_len]
  have := down_len n
  omega

/-- Iterate the literal multiset recursion, with multiplicities 4,2,2,1,3. -/
def paths (k : Nat) (e n : List Nat) : List Nat × List Nat :=
 match k with
 | 0 => (e,n)
 | i+1 => paths i (stepPaths e n).1 (stepPaths e n).2

theorem evolve_encodes (k : Nat) (e n : List Nat) (h : 6^k*(e.length+n.length) < base) :
   evolve k (encode e) (encode n) =
    (encode (paths k e n).1, encode (paths k e n).2) := by
  induction k generalizing e n with
  | zero => rfl
  | succ k ih =>
    have htotal : n.length ≤ 6^(k+1)*(e.length+n.length) := by
      have ht : 1 ≤ 6^(k+1) := Nat.pow_pos (by decide)
      have hle := Nat.mul_le_mul_right (e.length+n.length) ht
      simp at hle
      omega
    have hd := step_encode e n (Nat.lt_of_le_of_lt htotal h)
    have hm := Nat.mul_le_mul_left (6^k) (step_mass e n)
    rw [← Nat.mul_assoc, ← Nat.pow_succ] at hm
    simp only [evolve,paths]
    have he := congrArg Prod.fst hd
    have hn := congrArg Prod.snd hd
    simp only [Prod.fst,Prod.snd] at he hn
    rw [← he, ← hn]
    exact ih _ _ (Nat.lt_of_le_of_lt hm h)


/-- Sum of weights k through k+m-1 on the first m height classes. -/
def pay (m k : Nat) : List Nat → Nat
 | [] => 0
 | h::xs => (if h < m then k+h else 0) + pay m k xs

theorem pay_step (m k : Nat) (xs : List Nat) :
    pay (m+1) k xs = k * zeros xs + pay m (k+1) (down xs) := by
  induction xs with
  | nil => simp [pay, zeros, down]
  | cons h t ih =>
    cases h with
    | zero => simp [pay,down,zeros,ih,Nat.mul_add,Nat.add_assoc]
    | succ j =>
      simp only [pay,down,zeros,ih,Nat.succ_lt_succ_iff]
      split <;> omega

theorem pay_zero (k : Nat) (x : List Nat) : pay 0 k x = 0 := by
  induction x with
  | nil => rfl
  | cons a x ih => simp [pay, ih]

theorem weighted_encodes (m k : Nat) (xs : List Nat) (hh : xs.length < base) :
    weighted m k (encode xs) = pay m k xs := by
  induction m generalizing k xs with
  | zero => simp only [weighted, pay_zero]
  | succ m ih =>
    simp only [weighted,encode_low xs hh,encode_down xs hh]
    rw [ih (k+1) (down xs) (Nat.lt_of_le_of_lt (down_len xs) hh), pay_step]

def dropHeights (m : Nat) (xs : List Nat) : List Nat :=
 match m with
 | 0 => xs
 | k+1 => dropHeights k (down xs)

theorem drop_len (m : Nat) (xs : List Nat) : (dropHeights m xs).length ≤ xs.length := by
 induction m generalizing xs with
 | zero => simp [dropHeights]
 | succ m ih => exact Nat.le_trans (ih (down xs)) (down_len xs)

theorem drop_encodes (m : Nat) (xs : List Nat) (hh : xs.length < base) :
    encode xs >>> (m*width) = encode (dropHeights m xs) := by
  induction m generalizing xs with
  | zero => simp [dropHeights]
  | succ m ih =>
    rw [Nat.succ_mul, Nat.add_comm, Nat.shiftRight_add, encode_down xs hh]
    exact ih (down xs) (Nat.lt_of_le_of_lt (down_len xs) hh)

theorem paths_mass (k : Nat) (e n : List Nat) :
   (paths k e n).1.length + (paths k e n).2.length ≤ 6^k*(e.length+n.length) := by
  induction k generalizing e n with
  | zero => simp [paths]
  | succ k ih =>
    have h := Nat.mul_le_mul_left (6^k) (step_mass e n)
    rw [← Nat.mul_assoc, ← Nat.pow_succ] at h
    exact Nat.le_trans (ih (stepPaths e n).1 (stepPaths e n).2) h

def literalExcess (L u : Nat) (startE : Bool) : Nat :=
  let r := if startE then paths L [2] [] else paths L [] [2]
  pay (L-u) 1 (dropHeights (u+3) (r.1 ++ r.2))

theorem one_eq : (1 : Nat) <<< (2*width) = encode [2] := by
  simp [encode, Nat.one_shiftLeft, Nat.pow_mul, Nat.mul_comm 2 width, base]

/-- The compact calculation evaluates the path-by-path killed fallback score. -/
theorem excess_literal (L u : Nat) (startE : Bool) (h : 6^L < base) :
    excess L u startE = literalExcess L u startE := by
  have aux (e n : List Nat) (hr : e.length + n.length = 1) :
      weighted (L-u) 1 (((evolve L (encode e) (encode n)).1 +
        (evolve L (encode e) (encode n)).2) >>> ((u+3)*width)) =
       pay (L-u) 1 (dropHeights (u+3) ((paths L e n).1 ++ (paths L e n).2)) := by
    have hh : 6^L*(e.length+n.length) < base := by simpa [hr] using h
    have sz := Nat.lt_of_le_of_lt (paths_mass L e n) hh
    have sz' : ((paths L e n).1 ++ (paths L e n).2).length < base := by simpa using sz
    rw [evolve_encodes L e n hh]
    simp only [Prod.fst,Prod.snd]
    rw [← encode_append, drop_encodes _ _ sz', weighted_encodes _ _ _
      (Nat.lt_of_le_of_lt (drop_len _ _) sz')]
  cases startE with
  | true => simpa [excess,literalExcess,one_eq,encode] using aux [2] [] (by decide)
  | false => simpa [excess,literalExcess,one_eq,encode] using aux [] [2] (by decide)

theorem literalSafe512 :
    (189+3)*148*6^512 + 10000*literalExcess 512 189 true < 30000*6^512 ∧
    (186+3)*148*6^512 + 10000*literalExcess 512 186 false < 30000*6^512 := by
  have h : 6^512 < base := by simpa only [Nat.one_shiftLeft] using digitSpace
  rw [← excess_literal 512 189 true h, ← excess_literal 512 186 false h]
  exact safe512

def bounded (b : Nat) (xs : List Nat) : Prop := ∀ h ∈ xs, h ≤ b

theorem bounded_append {b : Nat} {x y : List Nat} (hx : bounded b x) (hy : bounded b y) :
 bounded b (x++y) := by
  intro a h
  exact (List.mem_append.mp h).elim (hx a) (hy a)

theorem bounded_copies (k : Nat) {b : Nat} {x : List Nat} (hx : bounded b x) :
 bounded b (copies k x) := by
  induction k with
  | zero => simp [bounded,copies]
  | succ k ih => exact bounded_append hx ih

theorem bounded_down {b : Nat} {x : List Nat} (hx : bounded b x) : bounded b (down x) := by
  induction x with
  | nil => simp [bounded,down]
  | cons h t ih =>
    have ht : bounded b t := fun a ha => hx a (List.mem_cons_of_mem h ha)
    cases h with
    | zero => exact ih ht
    | succ j =>
      intro a ha
      cases List.mem_cons.mp ha with
      | inl eq => have hj := hx (j+1) (by simp)
                  omega
      | inr mem => exact ih ht a mem

theorem bounded_relax {b : Nat} {x : List Nat} (hx : bounded b x) : bounded (b+1) x :=
  fun a ha => Nat.le_trans (hx a ha) (Nat.le_succ b)

theorem step_bounded (b : Nat) (e n : List Nat) (he : bounded b e) (hn : bounded b n) :
 bounded (b+1) (stepPaths e n).1 ∧ bounded (b+1) (stepPaths e n).2 := by
 constructor
 · intro h hh
   obtain ⟨a, ha, rfl⟩ := List.mem_map.mp hh
   exact Nat.succ_le_succ (bounded_append (bounded_copies 4 he) (bounded_copies 2 hn) a ha)
 · exact bounded_relax (bounded_append (bounded_append (bounded_copies 2 he) hn)
     (bounded_copies 3 (bounded_down hn)))

theorem paths_bounded (k b : Nat) (e n : List Nat) (he : bounded b e) (hn : bounded b n) :
 bounded (b+k) (paths k e n).1 ∧ bounded (b+k) (paths k e n).2 := by
 induction k generalizing b e n with
 | zero => simpa [paths] using And.intro he hn
 | succ k ih =>
   have hs := step_bounded b e n he hn
   simpa only [paths, Nat.add_assoc, Nat.add_comm 1 k, Nat.succ_eq_add_one] using
      ih (b+1) _ _ hs.1 hs.2

theorem drop_cons (m h : Nat) (xs : List Nat) :
 dropHeights m (h::xs) = if m ≤ h then (h-m)::dropHeights m xs else dropHeights m xs := by
 induction m generalizing h xs with
 | zero => simp [dropHeights]
 | succ m ih =>
   cases h with
   | zero => simp [dropHeights, down]
   | succ j => simp [dropHeights,down,ih]

def positiveScore (u : Nat) : List Nat → Nat
 | [] => 0
 | h::xs => (h-(u+2)) + positiveScore u xs

theorem drop_nil (m : Nat) : dropHeights m [] = [] := by
  induction m <;> simp_all [dropHeights,down]

theorem pay_positive (L u : Nat) (x : List Nat) (hx : bounded (L+2) x) :
    pay (L-u) 1 (dropHeights (u+3) x) = positiveScore u x := by
  induction x with
  | nil => simp [drop_nil,pay,positiveScore]
  | cons h t ih =>
    have ht : bounded (L+2) t := fun a ha => hx a (List.mem_cons_of_mem h ha)
    have hmax := hx h (List.mem_cons_self)
    rw [drop_cons]
    by_cases ok : u+3 ≤ h
    · rw [if_pos ok]
      have hr : h-(u+3) < L-u := by omega
      simp only [pay,if_pos hr,ih ht,positiveScore]
      omega
    · rw [if_neg ok, ih ht]
      simp [positiveScore, Nat.sub_eq_zero_of_le (by omega : h ≤ u+2)]

def directExcess (L u : Nat) (startE : Bool) : Nat :=
  let r := if startE then paths L [2] [] else paths L [] [2]
  positiveScore u (r.1 ++ r.2)

theorem literal_direct (L u : Nat) (startE : Bool) :
    literalExcess L u startE = directExcess L u startE := by
  have h1 : bounded 2 [2] := by simp [bounded]
  have h0 : bounded 2 [] := by simp [bounded]
  have f (e n : List Nat) (he : bounded 2 e) (hn : bounded 2 n) :
      pay (L-u) 1 (dropHeights (u+3) ((paths L e n).1 ++ (paths L e n).2)) =
         positiveScore u ((paths L e n).1 ++ (paths L e n).2) := by
    have hh := paths_bounded L 2 e n he hn
    exact pay_positive _ _ _ (by simpa only [Nat.add_comm 2 L] using bounded_append hh.1 hh.2)
  cases startE with
  | true => exact f _ _ h1 h0
  | false => exact f _ _ h0 h1

theorem directSafe512 :
    (189+3)*148*6^512 + 10000*directExcess 512 189 true < 30000*6^512 ∧
    (186+3)*148*6^512 + 10000*directExcess 512 186 false < 30000*6^512 := by
  simpa only [literal_direct] using literalSafe512

#print axioms directSafe512

#print axioms literalSafe512
#print axioms excess_literal

#print axioms evolve_encodes
#print axioms encode_low
end PackedFallback
