import Std
import Lean.Elab.Tactic.Omega

namespace RawBlockDomination

-- A controller at high height increases by at most x. At low height the
-- next height is bounded by cap. Follow both cases with one reflected walk.
def walk (cap : Int) : List Int → Int
  | [] => cap
  | x :: xs => max cap (walk cap xs + x)

def controls (threshold cap : Int) : List Int → Int → Prop
  | [], h => h ≤ cap
  | x :: xs, h => ∃ prev, controls threshold cap xs prev ∧
      (prev < threshold → h ≤ cap) ∧ (threshold ≤ prev → h ≤ prev + x)

theorem dominated (threshold cap : Int) (xs : List Int) (h : Int)
    (hh : controls threshold cap xs h) : h ≤ walk cap xs := by
  induction xs generalizing h with
  | nil => exact hh
  | cons x xs ih =>
    obtain ⟨prev, hp, hlo, hhi⟩ := hh
    have bound := ih prev hp
    unfold walk
    by_cases c : prev < threshold
    · have hc := hlo c
      omega
    · have hc := hhi (by omega)
      omega

-- In reverse time, the maximum of all ordinary forward-time suffix sums.
def peak : List Int → Int
  | [] => 0
  | x :: xs => max 0 (peak xs + x)

theorem walk_eq (cap : Int) (xs : List Int) : walk cap xs = cap + peak xs := by
  induction xs with
  | nil => simp [walk, peak]
  | cons x xs ih => simp only [walk, peak, ih]; omega

theorem peak_witness (xs : List Int) : ∃ n, n ≤ xs.length ∧
    peak xs = (xs.take n).sum := by
  induction xs with
  | nil => exact ⟨0, by decide, rfl⟩
  | cons x xs ih =>
    obtain ⟨n, nle, hn⟩ := ih
    by_cases c : peak xs + x ≤ 0
    · refine ⟨0, Nat.zero_le _, ?_⟩
      simp only [peak, List.take_zero, List.sum_nil]; omega
    · refine ⟨n+1, by simp; omega, ?_⟩
      simp only [List.take_succ_cons, List.sum_cons, peak]; omega

#print axioms dominated
#print axioms walk_eq
#print axioms peak_witness

end RawBlockDomination
