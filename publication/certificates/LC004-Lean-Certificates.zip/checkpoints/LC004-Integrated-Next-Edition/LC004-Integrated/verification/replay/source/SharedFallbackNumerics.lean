import Std

namespace SharedFallbackNumerics
-- The supplied tail inputs are upper bounds rounded on a 10^9 grid.
def safe (q u tail : Nat) : Prop := (3+u)*q*100000 + tail < 3000000000
theorem E448 : safe 166 168 154171758 := by unfold safe; decide
theorem N448 : safe 166 165 163158438 := by unfold safe; decide
theorem E512 : safe 148 189 147026644 := by unfold safe; decide
theorem N512 : safe 148 186 153319795 := by unfold safe; decide
theorem E768 : safe 104 271 125554525 := by unfold safe; decide
theorem N768 : safe 104 268 125795137 := by unfold safe; decide
#print axioms E448
#print axioms N448
#print axioms E512
#print axioms N512
#print axioms E768
#print axioms N768
end SharedFallbackNumerics
