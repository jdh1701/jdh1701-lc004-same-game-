import Lean

namespace LC004.ThreePacketDrift

def cost (packets heightChange : Int) (miss : Bool) : Int :=
  if miss then heightChange else -packets

def missBit (miss : Bool) : Int := if miss then 1 else 0

/-- A bound valid even when the fallback outcome and miss event are
    arbitrarily correlated. -/
theorem pointwise (packets heightChange cutoff : Int) (miss : Bool) :
    cost packets heightChange miss ≤
      -packets + (packets + cutoff) * missBit miss + max 0 (heightChange-cutoff) := by
  cases miss <;> simp [cost,missBit] <;> omega

/-- Exact two-state signed-height distribution indexed with offset 'cap'. -/
def step (cap : Nat) (e n : Array Nat) (kill : Bool) : Array Nat × Array Nat := Id.run do
  let size := 2*cap+1
  let mut ee := Array.replicate size 0
  let mut nn := Array.replicate size 0
  for i in [0:size] do
    let a := e[i]!
    let b := n[i]!
    if i+1 < size then
      ee := ee.set! (i+1) (ee[i+1]! + 4*a + 2*b)
    nn := nn.set! i (nn[i]! + 2*a+b)
    if i > 0 && (!kill || cap ≤ i+1) then
      nn := nn.set! (i-1) (nn[i-1]!+3*b)
  return (ee,nn)

def excess (cap cutoff : Nat) (startE : Bool) (kill : Bool := false) : Nat := Id.run do
  let blank := Array.replicate (2*cap+1) 0
  let initial := blank.set! cap 1
  let mut es := if startE then initial else blank
  let mut ns := if startE then blank else initial
  for _ in [0:cap] do
    let (e,n) := step cap es ns kill
    es := e
    ns := n
  let mut total := 0
  for i in [cap+cutoff+1:2*cap+1] do
    total := total + (i-cap-cutoff)*(es[i]!+ns[i]!)
  return total

def suff (cap cutoff excessThousand missThousand : Nat) : Prop :=
  1000 * excess cap cutoff true < excessThousand * 6^cap ∧
  1000 * excess cap cutoff false < excessThousand * 6^cap ∧
  (cutoff+3)*missThousand+excessThousand < 3000

instance (cap cutoff excessThousand missThousand : Nat) :
    Decidable (suff cap cutoff excessThousand missThousand) :=
  inferInstanceAs (Decidable (_ ∧ _ ∧ (_ < 3000)))

theorem target384 : suff 384 148 156 18 := by native_decide
theorem target512 : suff 512 190 150 14 := by native_decide
theorem target768 : suff 768 273 122 10 := by native_decide

def killedSuff (cap uE uN qTenThousand : Nat) : Prop :=
  (uE+3)*qTenThousand*6^cap+10000*excess cap uE true true < 30000*6^cap ∧
  (uN+3)*qTenThousand*6^cap+10000*excess cap uN false true < 30000*6^cap

instance (cap uE uN qTenThousand : Nat) :
    Decidable (killedSuff cap uE uN qTenThousand) :=
  inferInstanceAs (Decidable (_ ∧ _))

theorem killed512 : killedSuff 512 189 186 147 := by native_decide

theorem small_potential_range : 100000001^768 < (2 : Nat) * 100000000^768 := by
  decide +kernel

#print axioms pointwise
#print axioms target512
#print axioms killed512
#print axioms small_potential_range
end LC004.ThreePacketDrift
