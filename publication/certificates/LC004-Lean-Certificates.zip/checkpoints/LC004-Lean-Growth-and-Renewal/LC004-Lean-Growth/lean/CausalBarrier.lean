import Lean

namespace LC004.CausalBarrier

/-- Optimal success mass for a controller carrying one proper stack and
committing after observing the present packet. True means top=last raw color.
Every packet step has six equally weighted tickets. -/
def opt : Nat → Nat → Bool → Nat
  | 0, h, _ => if h = 0 then 1 else 0
  | n+1, 0, _ => 6^(n+1)
  | n+1, h+1, e =>
    let push := opt n (h+2) true
    let skip := opt n (h+1) false
    let matched := max (opt n h false) (opt n (h+1) true)
    let longMiss := max push skip
    if e then 4*push + 2*longMiss else 3*matched + 2*push + longMiss

theorem empty (n : Nat) (b : Bool) : opt n 0 b = 6^n := by
  cases n <;> rfl

private theorem maxScaled (a b p z : Nat)
    (ha : p*a ≤ z) (hb : p*b ≤ z) : p*(max a b) ≤ z := by
  by_cases h : a ≤ b
  · simpa [Nat.max_eq_right h] using hb
  · simpa [Nat.max_eq_left (by omega : b ≤ a)] using ha

theorem envelope (n h : Nat) :
    4^(h+1)*opt n (h+1) true ≤ 2*(3^h*6^n) ∧
    4^(h+1)*opt n (h+1) false ≤ 3*(3^h*6^n) := by
  induction n generalizing h with
  | zero => simp [opt]
  | succ n ih =>
    let p := 4^(h+1)
    let z := 3^h*6^n
    have nowE : p*opt n (h+1) true ≤ 2*z := (ih h).1
    have nowD : p*opt n (h+1) false ≤ 3*z := (ih h).2
    have pushed : 4*(p*opt n (h+2) true) ≤ 6*z := by
      have hh := (ih (h+1)).1
      rw [Nat.pow_succ 4 (h+1),Nat.pow_succ 3 h,
        Nat.mul_right_comm (4^(h+1)) 4, Nat.mul_right_comm (3^h) 3] at hh
      rw [show h+1+1 = h+2 by omega] at hh
      change 4*(4^(h+1)*opt n (h+2) true) ≤ 6*(3^h*6^n)
      omega
    have popped : 3*(p*opt n h false) ≤ 12*z := by
      cases h with
      | zero => simp [p,z,empty]; omega
      | succ k =>
        have hh := (ih k).2
        dsimp [p,z]
        rw [Nat.pow_succ 4 (k+1), Nat.pow_succ 3 k]
        rw [Nat.mul_right_comm (4^(k+1)) 4, Nat.mul_right_comm (3^k) 3]
        omega
    have longMiss := maxScaled _ _ p (3*z) (by omega : p*opt n (h+2) true ≤ 3*z) nowD
    have matched := maxScaled _ _ p (4*z) (by omega : p*opt n h false ≤ 4*z)
                                         (by omega : p*opt n (h+1) true ≤ 4*z)
    change p*(4*opt n (h+2) true + 2*max _ _) ≤ 2*(3^h*6^(n+1)) ∧
      p*(3*max _ _ + 2*opt n (h+2) true + max _ _) ≤ 3*(3^h*6^(n+1))
    rw [Nat.pow_succ 6 n, ← Nat.mul_assoc (3^h), ← show z = 3^h*6^n from rfl]
    simp only [Nat.mul_add, Nat.mul_left_comm p 4, Nat.mul_left_comm p 2,
      Nat.mul_left_comm p 3]
    omega

theorem singletonCausalCeiling (n : Nat) : 2*opt n 1 true ≤ 6^n := by
  have hh := (envelope n 0).1
  simp only [Nat.pow_zero, Nat.one_mul] at hh
  change 4*opt n 1 true ≤ 2*6^n at hh
  omega

#print axioms singletonCausalCeiling
end LC004.CausalBarrier
