import FirstHit
namespace LC004.CertifiedParser
open LC004.PhaseDispatch
abbrev Word := List (Packet (Fin 3))

def mate (c : Fin 3) : Word → List Word
  | (d,_)::xs => if d = c then [xs] else []
  | [] => []

theorem mem_mate (c : Fin 3) (u v : Word) :
    v ∈ mate c u ↔ ∃ f, u = (c,f)::v := by
  cases u with
  | nil => simp [mate]
  | cons a u =>
    obtain ⟨d,f⟩ := a
    by_cases hd : d = c
    · subst d; simp [mate,eq_comm]
    · simp [mate,hd]

/-- Each result is a remainder after parsing one clearing prefix. -/
def ends : Nat → Word → List Word
  | 0, w => [w]
  | _+1, [] => [[]]
  | n+1, (c,f)::xs =>
    let smaller := ends n
    let afterOne := (smaller xs).flatMap (mate c)
    let afterTwo := (afterOne.flatMap smaller).flatMap (mate c)
    ((c,f)::xs) :: ((if f then smaller xs else []) ++
      afterOne.flatMap smaller ++ afterTwo.flatMap smaller)

theorem exactEnds (n : Nat) (w r : Word) :
    (r ∈ ends n w → ∃ p, w = p ++ r ∧ Clears p) ∧
    (∀ p, w = p ++ r → Clears p → p.length ≤ n → r ∈ ends n w) := by
  induction n generalizing w r with
  | zero =>
    constructor
    · simp only [ends,List.mem_singleton]; rintro rfl; exact ⟨[],rfl,.nil⟩
    · intro p eq _ le; cases p <;> simp_all [ends]
  | succ n ih =>
    constructor
    · cases w with
      | nil =>
        intro h; have : r=[] := by simpa [ends] using h
        subst r; exact ⟨[],rfl,.nil⟩
      | cons cf xs =>
        obtain ⟨c,f⟩ := cf
        simp only [ends,List.mem_cons,List.mem_append,List.mem_flatMap,mem_mate]
        rintro (rfl | ((skip | pair) | triple))
        · exact ⟨[],rfl,.nil⟩
        · cases f with
          | false => simp at skip
          | true =>
            obtain ⟨u,eq,hu⟩ := (ih _ _).1 skip
            exact ⟨(c,true)::u,by simp [eq],.skip _ _ hu⟩
        · obtain ⟨v,⟨u,hu,f',rfl⟩,hv⟩ := pair
          obtain ⟨g,rfl,hg⟩ := (ih _ _).1 hu
          obtain ⟨s,rfl,hs⟩ := (ih _ _).1 hv
          exact ⟨_,by simp [List.append_assoc],Clears.pair c f f' g s hg hs⟩
        · obtain ⟨z,⟨y,⟨v,⟨u,hu,b,rfl⟩,hv⟩,d,rfl⟩,hz⟩ := triple
          obtain ⟨g,rfl,hg⟩ := (ih _ _).1 hu
          obtain ⟨h,rfl,hh⟩ := (ih _ _).1 hv
          obtain ⟨s,rfl,hs⟩ := (ih _ _).1 hz
          exact ⟨_,by simp [List.append_assoc],Clears.triple c f b d g h s hg hh hs⟩
    · intro p eq hp bound
      subst w
      cases hp with
      | nil =>
        cases r with
        | nil => simp [ends]
        | cons cf xs => obtain ⟨c,f⟩ := cf; simp [ends]
      | skip c t ht =>
        simp only [List.length_cons] at bound
        have h := (ih (t++r) r).2 t rfl ht (by omega)
        simp [ends,h]
      | pair c f b g t hg ht =>
        simp only [List.length_cons,List.length_append,List.length_singleton] at bound
        have a := (ih (g++(c,b)::(t++r)) ((c,b)::(t++r))).2 g rfl hg (by omega)
        have z := (ih (t++r) r).2 t rfl ht (by omega)
        simp only [List.cons_append,List.append_assoc,List.singleton_append, ends,
          List.mem_cons,List.mem_append,List.mem_flatMap,mem_mate]
        exact Or.inr (Or.inr (Or.inl ⟨_,⟨_,a,b,rfl⟩,z⟩))
      | triple c f b d g h t hg hh ht =>
        simp only [List.length_cons,List.length_append,List.length_singleton] at bound
        let rest := (c,d)::(t++r)
        have a := (ih (g++(c,b)::(h++rest)) ((c,b)::(h++rest))).2 g rfl hg (by omega)
        have m := (ih (h++rest) rest).2 h rfl hh (by omega)
        have z := (ih (t++r) r).2 t rfl ht (by omega)
        simp only [List.cons_append,List.append_assoc,List.singleton_append, ends,
          List.mem_cons,List.mem_append,List.mem_flatMap,mem_mate]
        exact Or.inr (Or.inr (Or.inr ⟨_,⟨_,⟨_,⟨_,a,b,rfl⟩,m⟩,d,rfl⟩,z⟩))

def clears (w : Word) : Bool := (ends w.length w).contains []
theorem clears_correct (w : Word) : clears w = true ↔ Clears w := by
  simp only [clears,List.contains_iff_mem]
  constructor
  · intro a; obtain ⟨p,h,hp⟩ := (exactEnds _ _ _).1 a
    simp_all
  · intro a; exact (exactEnds _ _ _).2 w (by simp) a (by omega)
#print axioms clears_correct
end LC004.CertifiedParser
