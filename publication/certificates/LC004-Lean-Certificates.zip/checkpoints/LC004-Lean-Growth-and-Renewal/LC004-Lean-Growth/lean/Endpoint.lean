import Splice
namespace LC004.Splice
open LC004.PhaseDispatch
variable {α : Type}

def InWord (block w : W α) : Prop := ∃ l r, w=l++block++r
def Frozen (w : W α) : Prop :=
  (∀ c, ¬InWord [(c,true)] w) ∧
  (∀ c b f, ¬InWord [(c,b),(c,f)] w)

theorem frozenFactor {g : W α} (l r : W α) (h : Frozen (l++g++r)) : Frozen g := by
  have lift (u : W α) (hu : InWord u g) : InWord u (l++g++r) := by
    obtain ⟨a,b,rfl⟩ := hu
    exact ⟨l++a,b++r,by simp [List.append_assoc]⟩
  exact ⟨fun c hc => h.1 c (lift _ hc),fun c b f hc => h.2 c b f (lift _ hc)⟩

theorem frozenEmpty {w : W α} (hw : Clears w) : Frozen w → w=[] := by
  induction hw with
  | nil => simp
  | skip c t ht ih =>
    intro h; exact (h.1 c ⟨[],t,rfl⟩).elim
  | pair c b f g t hg ht ig it =>
    intro h
    have hh := frozenFactor [(c,b)] ((c,f)::t)
      (by simpa [List.append_assoc] using h :
        Frozen ([(c,b)]++g++(c,f)::t))
    obtain rfl := ig hh
    exact (h.2 c b f ⟨[],t,rfl⟩).elim
  | triple c b d f g s t hg hs ht ig is it =>
    intro h
    have hh := frozenFactor [(c,b)] ((c,d)::(s++(c,f)::t))
      (by simpa [List.append_assoc] using h :
        Frozen ([(c,b)]++g++(c,d)::(s++(c,f)::t)))
    obtain rfl := ig hh
    exact (h.2 c b d ⟨[],s++(c,f)::t,by simp [List.append_assoc]⟩).elim

theorem firstFreshEndpoint (a : α) (s x : W α) (frozen : Frozen ((a,false)::s))
    (hit : Clears (((a,false)::s)++x))
    (first : ∀ u v : W α, x=u++v → v≠[] → ¬Clears (((a,false)::s)++u)) :
    ∃ p f, (((a,false)::s)++x) = p++[(a,f)] := by
  apply firstHitEndpoint a (s++x) hit
  intro p t eq hp ht hclear
  change ((a,false)::s)++x = p++t at eq
  rcases List.append_eq_append_iff.mp eq with ⟨u,hp',hx⟩ | ⟨u,hold,_⟩
  · exact first u t hx ht (hp' ▸ hclear)
  · have hblock : Frozen ([]++p++u) := by simpa only [List.nil_append,←hold] using frozen
    exact hp (frozenEmpty hclear (frozenFactor [] u hblock))

#print axioms firstFreshEndpoint
end LC004.Splice
