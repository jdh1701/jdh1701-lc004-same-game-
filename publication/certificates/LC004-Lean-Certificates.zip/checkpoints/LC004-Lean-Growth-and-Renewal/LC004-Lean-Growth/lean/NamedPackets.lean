import CausalBarrier
namespace LC004.CausalBarrier

abbrev Color := Fin 3
def nextA (c : Color) : Color := c+1
def nextB (c : Color) : Color := c+2
private theorem neighbors (c : Color) : nextA c ≠ c ∧ nextB c ≠ c := by
  revert c; decide
private theorem other (a c : Color) (h : a ≠ c) :
    (nextA c = a ∧ nextB c ≠ a) ∨ (nextB c = a ∧ nextA c ≠ a) := by
  have allCases : ∀ a c : Color, a ≠ c →
      (nextA c = a ∧ nextB c ≠ a) ∨ (nextB c = a ∧ nextA c ≠ a) := by decide
  exact allCases a c h

def Proper : List Color → Prop
  | [] => True
  | a::tail => tail.head? ≠ some a ∧ Proper tail

def branch (f : List Color → Color → Nat) (a : Color) (s : List Color) (c : Color) :=
  if c = a then 3 * max (f s c) (f (a::s) c)
  else 2 * f (c::a::s) c + max (f (c::a::s) c) (f (a::s) c)

/-- The exact finite perfect-observation, single-stack Bellman recursion.
Singleton mismatches must push. Long mismatches may skip. A match
may pop or stay, with either flag. The two next colors are equiprobable. -/
def named : Nat → List Color → Color → Nat
  | 0, s, _ => if s.isEmpty then 1 else 0
  | n+1, [], _ => 6^(n+1)
  | n+1, a::s, c =>
    branch (named n) a s (nextA c) + branch (named n) a s (nextB c)

theorem named_eq_opt (n : Nat) (s : List Color) (c : Color) (hp : Proper s) :
    named n s c = opt n s.length (s.head? == some c) := by
  induction n generalizing s c with
  | zero => cases s <;> rfl
  | succ n ih =>
    cases s with
    | nil => rfl
    | cons a tail =>
      obtain ⟨hne, ht⟩ := hp
      have heq (x : Color) (hx : x = a) :
          branch (named n) a tail x =
            3*max (opt n tail.length false) (opt n (tail.length+1) true) := by
        subst x
        simp [branch, ih tail a ht, ih (a::tail) a (And.intro hne ht), beq_eq_false_iff_ne.mpr hne]
      have hdiff (x : Color) (hx : x ≠ a) :
          branch (named n) a tail x =
            2*opt n (tail.length+2) true +
            max (opt n (tail.length+2) true) (opt n (tail.length+1) false) := by
        have hnew : Proper (x::a::tail) := ⟨by simpa using Ne.symm hx,hne,ht⟩
        simp [branch,hx,Ne.symm hx, ih (x::a::tail) x hnew,
          ih (a::tail) x (And.intro hne ht), beq_eq_false_iff_ne.mpr (Ne.symm hx)]
      simp only [named,List.length_cons,List.head?_cons]
      by_cases hac : a = c
      · subst c
        rw [hdiff _ (neighbors a).1, hdiff _ (neighbors a).2]
        simp [opt]; omega
      · rcases other a c hac with ⟨h1,h2⟩ | ⟨h1,h2⟩
        · rw [heq _ h1, hdiff _ h2]; simp [opt,hac]; omega
        · rw [heq _ h1, hdiff _ h2]; simp [opt,hac]; omega

theorem named_singleton_ceiling (c : Color) (n : Nat) :
    2*named n [c] c ≤ 6^n := by
  rw [named_eq_opt _ _ _ (by simp [Proper])]
  simpa using singletonCausalCeiling n

#print axioms named_singleton_ceiling
end LC004.CausalBarrier
