import NamedPackets
namespace LC004.CausalBarrier

/-- Literal moves for one active mandatory stack, with top stored first. -/
inductive Move (a : Color) (s : List Color) (c : Color) (long : Bool) : List Color → Prop
  | pop (eq : c = a) : Move a s c long s
  | stay (eq : c = a) : Move a s c long (a::s)
  | push (ne : c ≠ a) : Move a s c long (c::a::s)
  | skip (ok : long = true) : Move a s c long (a::s)

/-- Each child has its own continuation tree. Decisions can use the entire
observed history but must select one successor for the packet just read. -/
inductive PolicyMass : Nat → List Color → Color → Nat → Prop
  | empty (n c) : PolicyMass n [] c (6^n)
  | timeout (a s c) : PolicyMass 0 (a::s) c 0
  | step {n a s c s₁ s₂ s₃ s₄ u v w z}
      (m₁ : Move a s (nextA c) false s₁) (m₂ : Move a s (nextA c) true s₂)
      (m₃ : Move a s (nextB c) false s₃) (m₄ : Move a s (nextB c) true s₄)
      (r₁ : PolicyMass n s₁ (nextA c) u) (r₂ : PolicyMass n s₂ (nextA c) v)
      (r₃ : PolicyMass n s₃ (nextB c) w) (r₄ : PolicyMass n s₄ (nextB c) z) :
      PolicyMass (n+1) (a::s) c (2*u+v+(2*w+z))

private theorem branches (f : List Color → Color → Nat) {a s c u v}
    (single : Move a s c false u) (long : Move a s c true v) :
    2*f u c + f v c ≤ branch f a s c := by
  by_cases eq : c=a
  · have bound {x b} (m : Move a s c b x) :
        f x c ≤ max (f s c) (f (a::s) c) := by
      cases m with
      | pop => exact Nat.le_max_left _ _
      | stay => exact Nat.le_max_right _ _
      | push bad => exact (bad eq).elim
      | skip => exact Nat.le_max_right _ _
    have := bound single; have := bound long
    simp only [branch,if_pos eq]; omega
  · have hu : u=c::a::s := by cases single <;> simp_all
    have hv : f v c ≤ max (f (c::a::s) c) (f (a::s) c) := by
      cases long with
      | pop h | stay h => exact (eq h).elim
      | push => exact Nat.le_max_left _ _
      | skip => exact Nat.le_max_right _ _
    simp only [hu,branch,if_neg eq]; omega

theorem policyBound {n s c z} (h : PolicyMass n s c z) : z ≤ named n s c := by
  induction h with
  | empty n c => cases n <;> exact Nat.le_refl _
  | timeout => exact Nat.zero_le _
  | @step n a s c _ _ _ _ _ _ _ _ m₁ m₂ m₃ m₄ _ _ _ _ i₁ i₂ i₃ i₄ =>
    have := branches (named n) m₁ m₂
    have := branches (named n) m₃ m₄
    simp only [named]; omega

theorem everyPolicyAtMostHalf {n c z} (h : PolicyMass n [c] c z) : 2*z ≤ 6^n := by
  have := policyBound h
  have := named_singleton_ceiling c n
  omega
#print axioms everyPolicyAtMostHalf
end LC004.CausalBarrier
