import ClearParser
import NamedPackets
namespace LC004.PrefixTarget
open LC004.PhaseDispatch LC004.CertifiedParser LC004.CausalBarrier

def HasHit (w : Word) : Prop := ∃ u v : Word, w = u ++ v ∧ u ≠ [] ∧ Clears u

def hasHit (w : Word) : Bool := (ends w.length w).any (fun r => r.length < w.length)

theorem hasHit_correct (w : Word) : hasHit w = true ↔ HasHit w := by
  simp only [hasHit, List.any_eq_true, decide_eq_true_eq]
  constructor
  · rintro ⟨r,mem,lt⟩
    obtain ⟨u,eq,clear⟩ := (exactEnds _ _ _).1 mem
    refine ⟨u,r,eq,?_,clear⟩
    intro h; subst u; simp_all
  · rintro ⟨u,r,eq,nonempty,clear⟩
    have hh : 0 < u.length := List.length_pos_iff.mpr nonempty
    have hl : w.length = u.length + r.length := by simp [eq]
    exact ⟨r,(exactEnds _ _ _).2 u eq clear (by omega),by omega⟩

/-- For a mandatory singleton, the first mate suffices. A triple at the
root can be cut at its first mate, retaining an earlier clearing prefix. -/
theorem firstMate (a : Color) (xs : Word) :
    HasHit ((a,false)::xs) ↔
      ∃ gap flag rest, xs = gap ++ (a,flag)::rest ∧ Clears gap := by
  constructor
  · rintro ⟨u,v,eq,hn,hc⟩
    cases u with
    | nil => exact False.elim (hn rfl)
    | cons x u =>
      simp only [List.cons_append,List.cons.injEq] at eq
      obtain ⟨rfl,rfl⟩ := eq
      cases hc with
      | pair _ _ f g t hg _ => exact ⟨g,f,t++v,by simp,hg⟩
      | triple _ _ b f g h t hg _ _ => exact ⟨g,b,h++[(a,f)]++t++v,by simp,hg⟩
  · rintro ⟨g,f,t,rfl,hg⟩
    exact ⟨(a,false)::(g++[(a,f)]),t,by simp,by simp,
      by simpa using Clears.pair a false f g [] hg Clears.nil⟩

/-- The mass is the number of miss tickets out of 6^n. Earlier hits are
detected at the leaf because hasHit tests all nonempty prefixes. -/
def weight (accept : Word → Bool) : Nat → Word → Color → Nat
  | 0,w,_ => if accept w then 0 else 1
  | n+1,w,c =>
    let branch := fun d =>
      2*weight accept n (w++[(d,false)]) d + weight accept n (w++[(d,true)]) d
    branch (nextA c) + branch (nextB c)

def miss (n : Nat) := weight hasHit n [(0,false)] 0

/-- Precisely the singleton sufficient target in the paper; an open proposition. -/
def Target512 : Prop := 1000000*miss 512 ≤ 10192*6^512

/-- For the singleton root, a span parser can seek the first mate directly. -/
def mateHit (a : Color) (xs : Word) : Bool :=
  (ends xs.length xs).any (fun r => r.head?.map Prod.fst == some a)

theorem mateHit_correct (a : Color) (xs : Word) :
    mateHit a xs = hasHit ((a,false)::xs) := by
  apply Bool.eq_iff_iff.mpr
  rw [hasHit_correct,firstMate]
  simp only [mateHit,List.any_eq_true,beq_iff_eq]
  constructor
  · rintro ⟨r,mem,hd⟩
    obtain ⟨g,eq,hg⟩ := (exactEnds _ _ _).1 mem
    cases r with
    | nil => simp at hd
    | cons cf t =>
      obtain ⟨c,f⟩ := cf
      simp at hd; subst c; exact ⟨g,f,t,eq,hg⟩
  · rintro ⟨g,f,t,eq,hg⟩
    exact ⟨_,(exactEnds _ _ _).2 g eq hg (by simp [eq]),by simp⟩

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem small_replay : miss 4 = 954 := by decide +kernel

#print axioms firstMate
#print axioms hasHit_correct
#print axioms mateHit_correct
#print axioms small_replay
end LC004.PrefixTarget
