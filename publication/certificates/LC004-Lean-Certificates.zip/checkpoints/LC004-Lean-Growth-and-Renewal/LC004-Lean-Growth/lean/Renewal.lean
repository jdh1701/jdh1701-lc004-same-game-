import Lean
namespace LC004.Renewal

/-- A row carries lower and actual arrival mass at a time cut and the
guaranteed payoff for an arrival there, in common integer units. -/
structure Row where
  certified : Nat
  actual : Nat
  payoff : Nat

inductive Dominates : Nat → Nat → List Row → Prop
  | nil (surplus cap : Nat) : Dominates surplus cap []
  | cons (s bound next : Nat) (r : Row) (rs : List Row)
      (balance : s+r.actual = r.certified+next)
      (decreasing : r.payoff ≤ bound)
      (tail : Dominates next r.payoff rs) : Dominates s bound (r::rs)

def lower : List Row → Nat
  | [] => 0
  | r::rs => r.certified*r.payoff + lower rs

def actual : List Row → Nat
  | [] => 0
  | r::rs => r.actual*r.payoff + actual rs

/-- Cumulative upper domination of a proposed arrival distribution suffices;
the actual mass in a particular bin can be smaller than the proposed mass. -/
theorem summation (s bound : Nat) (rs : List Row) (h : Dominates s bound rs) :
    lower rs ≤ s*bound + actual rs := by
  induction h with
  | nil => simp [lower,actual]
  | cons s cap next r rs hb hd _ ih =>
    have ht := congrArg (fun v => v*r.payoff) hb
    simp only [Nat.add_mul] at ht
    have hs := Nat.mul_le_mul_left s hd
    simp only [lower,actual]
    omega

theorem zero_initial (bound : Nat) (rs : List Row) (h : Dominates 0 bound rs) :
    lower rs ≤ actual rs := by simpa using summation 0 bound rs h

#print axioms zero_initial
end LC004.Renewal
