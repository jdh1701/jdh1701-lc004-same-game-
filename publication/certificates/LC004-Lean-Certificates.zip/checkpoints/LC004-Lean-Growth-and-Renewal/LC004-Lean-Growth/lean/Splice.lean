import FirstHit
namespace LC004.Splice
open LC004.PhaseDispatch
variable {α : Type}
abbrev W (α : Type) := List (Packet α)

theorem join {u v : W α} (hu : Clears u) (hv : Clears v) : Clears (u++v) := by
  induction hu with
  | nil => simpa using hv
  | skip c t _ ih => exact .skip c _ ih
  | pair c b f g t hg _ _ ih =>
    simpa [List.append_assoc] using Clears.pair c b f g (t++v) hg ih
  | triple c b d f g h t hg hh _ _ _ ih =>
    simpa [List.append_assoc] using Clears.triple c b d f g h (t++v) hg hh ih

/-- Locate a cut in a gap followed by a marked letter and another gap. -/
private theorem locate {β : Type} {g t l r : List β} {a : β}
    (cut : g ++ a::t = l++r) :
    (∃ b, g=l++b ∧ r=b++a::t) ∨ (∃ b, l=g++a::b ∧ t=b++r) := by
  rcases List.append_eq_append_iff.mp cut with ⟨b,hl,hr⟩ | hit
  · cases b with
    | nil => exact Or.inl ⟨[],by simpa using hl.symm,by simpa using hr.symm⟩
    | cons x b =>
      simp only [List.cons_append,List.cons.injEq] at hr
      obtain ⟨rfl,hr⟩ := hr
      exact Or.inr ⟨b,hl,hr⟩
  · exact Or.inl hit

theorem insert {w z : W α} (hw : Clears w) (hz : Clears z) :
    ∀ l r, w=l++r → Clears (l++z++r) := by
  induction hw with
  | nil =>
    intro l r form
    obtain ⟨rfl,rfl⟩ := List.append_eq_nil_iff.mp form.symm
    simpa using hz
  | skip c t ht ih =>
    intro l r form
    cases l with
    | nil => simp_all only [List.nil_append]; exact join hz (form ▸ Clears.skip _ _ ht)
    | cons a l =>
      obtain ⟨rfl,cut⟩ := List.cons.inj form
      exact Clears.skip _ _ (ih l r cut)
  | pair c b f g t hg ht ig it =>
    intro l r form
    cases l with
    | nil => simp only [List.nil_append] at *; exact join hz (form ▸ Clears.pair c b f g t hg ht)
    | cons a l =>
      obtain ⟨rfl,cut⟩ := List.cons.inj form
      rcases locate (by simpa [List.append_assoc] using cut : g++(c,f)::t = l++r) with
        ⟨b',hg',hr⟩ | ⟨b',hl',ht'⟩
      · simpa [hr,List.append_assoc] using Clears.pair c b f _ t (ig l b' hg') ht
      · simpa [hl',List.append_assoc] using Clears.pair c b f g _ hg (it b' r ht')
  | triple c b d f g h t hg hh ht ig ih it =>
    intro l r form
    cases l with
    | nil => simp only [List.nil_append] at *; exact join hz (form ▸ Clears.triple c b d f g h t hg hh ht)
    | cons a l =>
      obtain ⟨rfl,cut⟩ := List.cons.inj form
      rcases locate (by simpa [List.append_assoc] using cut :
        g++(c,d)::(h++(c,f)::t) = l++r) with ⟨b',hg',hr⟩ | ⟨b',hl',ht'⟩
      · simpa [hr,List.append_assoc] using Clears.triple c b d f _ h t (ig l b' hg') hh ht
      · rcases locate ht' with ⟨b'',hh',hr⟩ | ⟨b'',hb,ht''⟩
        · simpa [hl',hr,List.append_assoc] using Clears.triple c b d f g _ t hg (ih b' b'' hh') ht
        · simpa [hl',hb,List.append_assoc] using Clears.triple c b d f g h _ hg hh (it b'' r ht'')

theorem nestedReturn {base top first rest : W α}
    (inner : Clears (top++first)) (outer : Clears (base++rest)) :
    Clears ((base++top)++(first++rest)) := by
  simpa [List.append_assoc] using insert outer inner base rest rfl

#print axioms nestedReturn
end LC004.Splice
