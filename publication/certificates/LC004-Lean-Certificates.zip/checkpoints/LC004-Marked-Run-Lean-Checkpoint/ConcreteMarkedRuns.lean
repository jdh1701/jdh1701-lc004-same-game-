import MarkedRunBudget
import LC004.Transition

namespace LC004.MarkedRunBudget

def marks : RunState → Nat
  | [] => 0
  | (_, b) :: xs => (if b then 1 else 0) + marks xs

theorem marks_append (u v : RunState) : marks (u ++ v) = marks u + marks v := by
  induction u with
  | nil => simp [marks]
  | cons h t ih =>
      rcases h with ⟨c,b⟩
      simp [marks, ih, Nat.add_assoc]

/-- Complete histories in the repository's concrete capped-run step relation. -/
inductive ConcreteWin : RunState → Prop where
  | done : ConcreteWin []
  | next {u v : RunState} : LC004.Step u v → ConcreteWin v → ConcreteWin u

theorem concrete_budget {u : RunState} (h : ConcreteWin u) :
    ∃ xs, Successful u.length (marks u) xs := by
  induction h with
  | done => exact ⟨[], Successful.done⟩
  | next hstep _ ih =>
      obtain ⟨xs, hx⟩ := ih
      cases hstep with
      | @noMerge pre post c hb =>
        refine ⟨.erase :: xs, ?_⟩
        have hs := Successful.erase hx
        simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
          Nat.add_comm] using hs
      | @merge pre post c d bp bq =>
        have hp : 0 < (pre ++ (c,true) :: post).length := by
          simp [List.length_append]; omega
        cases bp <;> cases bq
        · refine ⟨.clean :: xs, ?_⟩
          have hs := Successful.clean hp hx
          simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
            Nat.add_comm] using hs
        · refine ⟨.fuseOne :: xs, ?_⟩
          have hs := Successful.fuseOne hp hx
          simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
            Nat.add_comm] using hs
        · refine ⟨.fuseOne :: xs, ?_⟩
          have hs := Successful.fuseOne hp hx
          simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
            Nat.add_comm] using hs
        · refine ⟨.fuseTwo :: xs, ?_⟩
          have hs := Successful.fuseTwo hp hx
          have htwo (n : Nat) : 2 + n = 1 + (1 + n) := by omega
          simpa [htwo, List.length_append, marks_append, marks, Nat.add_assoc,
            Nat.add_left_comm, Nat.add_comm] using hs


theorem concrete_three_even {u : RunState} (h : ConcreteWin u) (hu : marks u = 3)
    (he : u.length % 2 = 0) :
    ∃ xs, Successful u.length (marks u) xs ∧
      noFusionCount xs = 2 ∧ oneCount xs = 1 ∧ twoCount xs = 0 := by
  obtain ⟨xs, hx⟩ := concrete_budget h
  have hp : 0 < u.length := by
    cases u with
    | nil => simp [marks] at hu
    | cons c t => simp
  exact ⟨xs, hx, three_mark_even (hu ▸ hx) hp he⟩

#print axioms concrete_budget
#print axioms concrete_three_even


def singletonColors : RunState → List Nat
  | [] => []
  | (a, b) :: xs => if b then singletonColors xs else a :: singletonColors xs

theorem singleton_append (u v : RunState) :
    singletonColors (u ++ v) = singletonColors u ++ singletonColors v := by
  induction u with
  | nil => rfl
  | cons h t ih =>
    rcases h with ⟨a,b⟩
    cases b <;> simp [singletonColors, ih]

inductive PairClears : List Nat → Prop where
  | done : PairClears []
  | pair (l r : List Nat) (a : Nat) :
      PairClears (l ++ r) → PairClears (l ++ a :: a :: r)

theorem concrete_budget_with_trace {u : RunState} (h : ConcreteWin u) :
    ∃ xs, Successful u.length (marks u) xs ∧
      (oneCount xs = 0 → twoCount xs = 0 → PairClears (singletonColors u)) := by
  induction h with
  | done => exact ⟨[], Successful.done, fun _ _ => PairClears.done⟩
  | next hstep _ ih =>
      obtain ⟨xs, hx, htrace⟩ := ih
      cases hstep with
      | @noMerge pre post c hb =>
        refine ⟨.erase :: xs, ?_, ?_⟩
        · have hs := Successful.erase hx
          simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
            Nat.add_comm] using hs
        · intro hOne hTwo
          simpa [singleton_append, singletonColors] using htrace hOne hTwo
      | @merge pre post c d bp bq =>
        have hp : 0 < (pre ++ (c,true) :: post).length := by
          simp [List.length_append]; omega
        cases bp <;> cases bq
        · refine ⟨.clean :: xs, ?_, ?_⟩
          · have hs := Successful.clean hp hx
            simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
              Nat.add_comm] using hs
          · intro hOne hTwo
            have hh : PairClears (singletonColors pre ++ singletonColors post) := by
              simpa [singleton_append, singletonColors] using htrace hOne hTwo
            simpa [singleton_append, singletonColors] using
              PairClears.pair (singletonColors pre) (singletonColors post) c hh
        · refine ⟨.fuseOne :: xs, ?_, ?_⟩
          · have hs := Successful.fuseOne hp hx
            simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
              Nat.add_comm] using hs
          · intro hOne
            simp [oneCount] at hOne
        · refine ⟨.fuseOne :: xs, ?_, ?_⟩
          · have hs := Successful.fuseOne hp hx
            simpa [List.length_append, marks_append, marks, Nat.add_assoc, Nat.add_left_comm,
              Nat.add_comm] using hs
          · intro hOne
            simp [oneCount] at hOne
        · refine ⟨.fuseTwo :: xs, ?_, ?_⟩
          · have hs := Successful.fuseTwo hp hx
            have htwo (n : Nat) : 2 + n = 1 + (1 + n) := by omega
            simpa [htwo, List.length_append, marks_append, marks, Nat.add_assoc,
              Nat.add_left_comm, Nat.add_comm] using hs
          · intro _ hTwo
            simp [twoCount] at hTwo



theorem concrete_two_even_necessary {u : RunState} (h : ConcreteWin u)
    (hu : marks u = 2) (he : u.length % 2 = 0) :
    PairClears (singletonColors u) := by
  obtain ⟨xs,hx,htrace⟩ := concrete_budget_with_trace h
  have hp : 0 < u.length := by
    cases u with
    | nil => simp [marks] at hu
    | cons c t => simp
  obtain ⟨_,ho,ht⟩ := two_mark_even (hu ▸ hx) hp he
  exact htrace ho ht

#print axioms concrete_budget_with_trace
#print axioms concrete_two_even_necessary

end LC004.MarkedRunBudget
