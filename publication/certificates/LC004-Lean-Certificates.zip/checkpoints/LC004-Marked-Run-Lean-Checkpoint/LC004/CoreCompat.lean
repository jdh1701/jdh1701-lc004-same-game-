import Lean

theorem List.replicate_add {α : Type u} (m n : Nat) (a : α) :
    List.replicate (m+n) a = List.replicate m a ++ List.replicate n a := by
  induction m with
  | zero => simp
  | succ m ih =>
      rw [Nat.succ_add]
      rw [List.replicate_succ, ih, List.replicate_succ]; rfl
