import Lean

namespace LC004.MarkedRunBudget

/-- Which kind of change a deletion makes in the proper run skeleton. -/
inductive Step where
  | erase       -- no fusion
  | clean       -- fusion of two unmarked neighbors
  | fuseOne     -- fusion of a marked and an unmarked neighbor
  | fuseTwo     -- fusion of two marked neighbors

def noFusionCount : List Step → Nat
  | [] => 0
  | .erase :: xs => noFusionCount xs + 1
  | _ :: xs => noFusionCount xs

def cleanCount : List Step → Nat
  | [] => 0
  | .clean :: xs => cleanCount xs + 1
  | _ :: xs => cleanCount xs

def oneCount : List Step → Nat
  | [] => 0
  | .fuseOne :: xs => oneCount xs + 1
  | _ :: xs => oneCount xs

def twoCount : List Step → Nat
  | [] => 0
  | .fuseTwo :: xs => twoCount xs + 1
  | _ :: xs => twoCount xs

/-- Abstract successful histories; indices are initial runs and initial marks.
Every fusion leaves at least one run, so a fusion cannot be the last event.
This relation intentionally forgets colors and does not assert realizability. -/
inductive Successful : Nat → Nat → List Step → Prop where
  | done : Successful 0 0 []
  | erase {r m : Nat} {xs : List Step} :
      Successful r m xs → Successful (r+1) (m+1) (.erase :: xs)
  | clean {r m : Nat} {xs : List Step} :
      0 < r → Successful r m xs → Successful (r+2) m (.clean :: xs)
  | fuseOne {r m : Nat} {xs : List Step} :
      0 < r → Successful r m xs → Successful (r+2) (m+1) (.fuseOne :: xs)
  | fuseTwo {r m : Nat} {xs : List Step} :
      0 < r → Successful r m xs → Successful (r+2) (m+2) (.fuseTwo :: xs)

theorem accounting {r m : Nat} {xs : List Step} (h : Successful r m xs) :
    r = noFusionCount xs + 2 * (cleanCount xs + oneCount xs + twoCount xs) ∧
    m = noFusionCount xs + oneCount xs + 2 * twoCount xs := by
  induction h with
  | done => simp [noFusionCount, cleanCount, oneCount, twoCount]
  | erase h ih =>
      rcases ih with ⟨hr, hm⟩
      simp only [noFusionCount, cleanCount, oneCount, twoCount]
      omega
  | clean hp h ih =>
      rcases ih with ⟨hr, hm⟩
      simp only [noFusionCount, cleanCount, oneCount, twoCount]
      omega
  | fuseOne hp h ih =>
      rcases ih with ⟨hr, hm⟩
      simp only [noFusionCount, cleanCount, oneCount, twoCount]
      omega
  | fuseTwo hp h ih =>
      rcases ih with ⟨hr, hm⟩
      simp only [noFusionCount, cleanCount, oneCount, twoCount]
      omega

theorem noFusion_pos {r m : Nat} {xs : List Step} (h : Successful r m xs) :
    0 < r → 0 < noFusionCount xs := by
  induction h with
  | done => omega
  | erase h ih =>
      intro _
      simp only [noFusionCount]
      omega
  | clean hp h ih =>
      intro _
      simpa [noFusionCount] using ih hp
  | fuseOne hp h ih =>
      intro _
      simpa [noFusionCount] using ih hp
  | fuseTwo hp h ih =>
      intro _
      simpa [noFusionCount] using ih hp

theorem noFusion_parity {r m : Nat} {xs : List Step} (h : Successful r m xs) :
    noFusionCount xs % 2 = r % 2 := by
  rcases accounting h with ⟨hr, _⟩
  omega

theorem two_mark_even {r : Nat} {xs : List Step} (h : Successful r 2 xs)
    (hp : 0 < r) (he : r % 2 = 0) :
    noFusionCount xs = 2 ∧ oneCount xs = 0 ∧ twoCount xs = 0 := by
  rcases accounting h with ⟨hr, hm⟩
  have hd := noFusion_pos h hp
  have hmod := noFusion_parity h
  omega

theorem two_mark_odd {r : Nat} {xs : List Step} (h : Successful r 2 xs)
    (hp : 0 < r) (ho : r % 2 = 1) :
    noFusionCount xs = 1 ∧ oneCount xs = 1 ∧ twoCount xs = 0 := by
  rcases accounting h with ⟨hr, hm⟩
  have hd := noFusion_pos h hp
  have hmod := noFusion_parity h
  omega

theorem three_mark_even {r : Nat} {xs : List Step} (h : Successful r 3 xs)
    (hp : 0 < r) (he : r % 2 = 0) :
    noFusionCount xs = 2 ∧ oneCount xs = 1 ∧ twoCount xs = 0 := by
  rcases accounting h with ⟨hr, hm⟩
  have hd := noFusion_pos h hp
  have hmod := noFusion_parity h
  omega

theorem three_mark_odd {r : Nat} {xs : List Step} (h : Successful r 3 xs)
    (hp : 0 < r) (ho : r % 2 = 1) :
    (noFusionCount xs = 3 ∧ oneCount xs = 0 ∧ twoCount xs = 0) ∨
    (noFusionCount xs = 1 ∧ oneCount xs = 2 ∧ twoCount xs = 0) ∨
    (noFusionCount xs = 1 ∧ oneCount xs = 0 ∧ twoCount xs = 1) := by
  rcases accounting h with ⟨hr, hm⟩
  have hd := noFusion_pos h hp
  have hmod := noFusion_parity h
  omega

#print axioms accounting
#print axioms noFusion_parity
#print axioms two_mark_even
#print axioms two_mark_odd
#print axioms three_mark_even
#print axioms three_mark_odd

end LC004.MarkedRunBudget

