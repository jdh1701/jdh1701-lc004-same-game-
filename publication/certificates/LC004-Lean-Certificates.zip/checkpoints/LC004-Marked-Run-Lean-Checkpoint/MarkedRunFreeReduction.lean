import LC004.RawWinCore

namespace LC004
def freeReducePush {q : Nat} (s : List (Fin q)) (a : Fin q) : List (Fin q) :=
  match s with
  | [] => [a]
  | b :: t => if a = b then t else a :: b :: t

def freeReduceAux {q : Nat} (s : List (Fin q)) : List (Fin q) → List (Fin q)
  | [] => s
  | a :: w => freeReduceAux (freeReducePush s a) w

theorem freeReduceAux_erases {q : Nat} (s w : List (Fin q)) :
    Erases (s.reverse ++ w) (freeReduceAux s w).reverse := by
  induction w generalizing s with
  | nil => simpa [freeReduceAux] using Erases.refl s.reverse
  | cons a w ih =>
      cases s with
      | nil => simpa [freeReduceAux, freeReducePush] using ih [a]
      | cons b t =>
          by_cases h : a = b
          · subst b
            have hp : SmallErase (t.reverse ++ [a,a] ++ w) (t.reverse ++ w) :=
              SmallErase.pair t.reverse w a
            simpa [freeReduceAux, freeReducePush, List.reverse_cons, List.append_assoc]
              using Erases.next hp (ih t)
          · simpa [freeReduceAux, freeReducePush, h, List.reverse_cons, List.append_assoc]
              using ih (a :: b :: t)

theorem freeReduce_empty_erases {q : Nat} {w : List (Fin q)}
    (h : freeReduceAux [] w = []) : Erases w [] := by
  simpa [h] using freeReduceAux_erases [] w

theorem erases_replicate_unless_one {q : Nat} (a : Fin q) :
    ∀ n : Nat, n ≠ 1 → Erases (List.replicate n a) []
  | 0, _ => Erases.refl []
  | 1, h => (h rfl).elim
  | 2, _ => by
      simpa [List.replicate_succ] using
        Erases.next (SmallErase.pair [] [] a) (Erases.refl [])
  | 3, _ => by
      simpa [List.replicate_succ] using
        Erases.next (SmallErase.triple [] [] a) (Erases.refl [])
  | n+4, _ => by
      have hn : n+2 ≠ 1 := by omega
      have h := erases_replicate_unless_one a (n+2) hn
      simpa [List.replicate_succ] using
        Erases.next (SmallErase.pair [] (List.replicate (n+2) a) a) h

def expandedRunList {q : Nat} : List (Fin q × Nat) → List (Fin q)
  | [] => []
  | (a,n) :: t => List.replicate n a ++ expandedRunList t

def singletonRunTrace {q : Nat} : List (Fin q × Nat) → List (Fin q)
  | [] => []
  | (a,n) :: t => if n = 1 then a :: singletonRunTrace t else singletonRunTrace t

theorem erase_non_singleton_runs {q : Nat} (rs : List (Fin q × Nat)) :
    Erases (expandedRunList rs) (singletonRunTrace rs) := by
  induction rs with
  | nil => exact Erases.refl []
  | cons r rs ih =>
      obtain ⟨a,n⟩ := r
      by_cases hn : n = 1
      · subst n
        simpa [expandedRunList, singletonRunTrace] using erases_context ih [a] []
      · have h := erases_replicate_unless_one a n hn
        have hh : Erases (List.replicate n a ++ expandedRunList rs) (expandedRunList rs) := by
          simpa using erases_context h [] (expandedRunList rs)
        simpa [expandedRunList, singletonRunTrace, hn] using erases_trans hh ih

theorem free_singleton_trace_erases {q : Nat} {rs : List (Fin q × Nat)}
    (h : freeReduceAux [] (singletonRunTrace rs) = []) :
    Erases (expandedRunList rs) [] :=
  erases_trans (erase_non_singleton_runs rs) (freeReduce_empty_erases h)

end LC004

namespace LC004

theorem free_singleton_trace_wins {q : Nat} {rs : List (Fin q × Nat)}
    (h : freeReduceAux [] (singletonRunTrace rs) = []) :
    RawMaxErases (expandedRunList rs) [] :=
  aux_erases_to_raw_max_win (free_singleton_trace_erases h)

#print axioms free_singleton_trace_wins

end LC004

namespace LC004

inductive FreeProper {q : Nat} : List (Fin q) → Prop where
  | nil : FreeProper []
  | cons {x : Fin q} {s : List (Fin q)} :
      s.head? ≠ some x → FreeProper s → FreeProper (x :: s)

theorem freeReducePush_proper {q : Nat} {s : List (Fin q)} (hs : FreeProper s)
    (a : Fin q) : FreeProper (freeReducePush s a) := by
  cases hs with
  | nil => exact FreeProper.cons (by simp) FreeProper.nil
  | @cons b t hb ht =>
      by_cases h : a = b
      · simpa [freeReducePush, h] using ht
      · apply (show FreeProper (a :: b :: t) → _ by simp [freeReducePush,h])
        exact FreeProper.cons (by simpa [eq_comm] using h) (FreeProper.cons hb ht)

theorem freeReducePush_involutive {q : Nat} {s : List (Fin q)} (hs : FreeProper s)
    (a : Fin q) : freeReducePush (freeReducePush s a) a = s := by
  cases hs with
  | nil => simp [freeReducePush]
  | @cons b t hb ht =>
      by_cases h : a = b
      · subst b
        cases t with
        | nil => simp [freeReducePush]
        | cons c u =>
            have hn : a ≠ c := by simpa [eq_comm] using hb
            simp [freeReducePush, hn]
      · simp [freeReducePush, h]

theorem freeReduceAux_proper {q : Nat} {s : List (Fin q)} (hs : FreeProper s)
    (w : List (Fin q)) : FreeProper (freeReduceAux s w) := by
  induction w generalizing s with
  | nil => exact hs
  | cons a w ih => exact ih (freeReducePush_proper hs a)

theorem freeReduceAux_append {q : Nat} (s u v : List (Fin q)) :
    freeReduceAux s (u ++ v) = freeReduceAux (freeReduceAux s u) v := by
  induction u generalizing s with
  | nil => rfl
  | cons a u ih => exact ih (freeReducePush s a)

theorem freeReduceAux_pair_context {q : Nat} (l r : List (Fin q)) (a : Fin q) :
    freeReduceAux [] (l ++ [a,a] ++ r) = freeReduceAux [] (l ++ r) := by
  rw [List.append_assoc]
  simp only [freeReduceAux_append, freeReduceAux]
  rw [freeReducePush_involutive (freeReduceAux_proper FreeProper.nil l)]

#print axioms freeReduceAux_pair_context

end LC004
