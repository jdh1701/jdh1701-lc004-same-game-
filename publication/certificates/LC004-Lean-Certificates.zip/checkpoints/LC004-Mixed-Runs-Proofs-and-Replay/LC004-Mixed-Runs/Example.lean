import FixedExteriorCount
open LC004
#eval (List.range 6).map (fun m => fixedExteriorRec m (exteriorTargets ([0,0,1] : List (Fin 3)) [0,1,1,2,2]))
