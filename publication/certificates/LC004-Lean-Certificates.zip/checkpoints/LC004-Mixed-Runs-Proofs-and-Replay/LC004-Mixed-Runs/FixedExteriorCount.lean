import OverlapCount

namespace LC004

/-- One target per boundary pair. Duplicates and redundant targets are harmless
because the acceptance test is existential. -/
def exteriorTargets {q : Nat} (u v : List (Fin q)) : List (List (Fin q)) :=
  ((fusionReach [] u).sort (· ≤ ·)).flatMap fun s =>
    ((fusionReach [] v.reverse).sort (· ≤ ·)).map fun t => stackRoute s t

def targetHit {q : Nat} (targets : List (List (Fin q))) (schedule : List (Fin q)) : Prop :=
  ∃ p ∈ targets, p.Sublist schedule

theorem exterior_targets_win_iff {q : Nat} (u v : List (Fin q)) (h : List (Fin q × Nat)) :
    RawMaxErases ((u ++ physicalHeavy h) ++ v) [] ↔ targetHit (exteriorTargets u v) (h.map Prod.fst) := by
  rw [heavy_middle_context_iff]
  constructor
  · rintro ⟨s,hs,t,ht,sub⟩
    refine ⟨stackRoute s t,List.mem_flatMap.mpr ⟨s,(Finset.mem_sort _).mpr hs,?_⟩,sub⟩
    exact List.mem_map.mpr ⟨t,(Finset.mem_sort _).mpr ht,rfl⟩
  · rintro ⟨p,hp,sub⟩
    obtain ⟨s,hs,hm⟩ := List.mem_flatMap.mp hp
    obtain ⟨t,ht,rfl⟩ := List.mem_map.mp hm
    exact ⟨s,(Finset.mem_sort _).mp hs,t,(Finset.mem_sort _).mp ht,sub⟩

/-- Consume the first required color exactly when the next schedule color matches it. -/
def advanceRoute {q : Nat} (a : Fin q) : List (Fin q) → List (Fin q)
  | [] => []
  | b::rest => if b=a then rest else b::rest

private theorem advanceRoute_sublist {q : Nat} (a : Fin q) (p h : List (Fin q)) :
    p.Sublist (a::h) ↔ (advanceRoute a p).Sublist h := by
  cases p with
  | nil => simp [advanceRoute]
  | cons b p =>
    by_cases eq : b=a
    · subst b; simp [advanceRoute]
    · simp [advanceRoute,eq,List.sublist_cons_iff]

theorem targetHit_cons {q : Nat} (targets : List (List (Fin q))) (a : Fin q) (h : List (Fin q)) :
    targetHit targets (a::h) ↔ targetHit (targets.map (advanceRoute a)) h := by
  constructor
  · rintro ⟨p,hp,sub⟩
    exact ⟨_,List.mem_map.mpr ⟨p,hp,rfl⟩,(advanceRoute_sublist a p h).mp sub⟩
  · rintro ⟨r,hr,sub⟩
    obtain ⟨p,hp,rfl⟩ := List.mem_map.mp hr
    exact ⟨p,hp,(advanceRoute_sublist a p h).mpr sub⟩

/-- Exact recursion with a deterministic target-list transition for each color. -/
def fixedExteriorRec : Nat → List (List (Fin 3)) → Nat
  | 0, targets => if [] ∈ targets then 1 else 0
  | m+1, targets => ∑ a : Fin 3, fixedExteriorRec m (targets.map (advanceRoute a))

noncomputable def scheduleUnionCount (m : Nat) (targets : List (List (Fin 3))) : Nat :=
  ∑ v : Fin m → Fin 3, @ite Nat (targetHit targets (List.ofFn v)) (Classical.propDecidable _) 1 0

theorem target_union_count_recurrence (m : Nat) (targets : List (List (Fin 3))) :
    scheduleUnionCount m targets = fixedExteriorRec m targets := by
  classical
  induction m generalizing targets with
  | zero => simp [scheduleUnionCount,fixedExteriorRec,targetHit]
  | succ m ih =>
    unfold scheduleUnionCount
    rw [sum_schedule_cons m (fun h => if targetHit targets h then 1 else 0)]
    unfold fixedExteriorRec
    apply Finset.sum_congr rfl
    intro a _
    rw [← ih]
    unfold scheduleUnionCount
    apply Finset.sum_congr rfl
    intro v _
    simp only [targetHit_cons]

/-- Unbounded heavy interval, arbitrary fixed exterior words. Each ternary
schedule contributes once regardless of the number of successful boundary pairs. -/
theorem fixed_exterior_winning_count (u v : List (Fin 3)) (m : Nat) (e : Fin m → Nat) :
    (∑ c : Fin m → Fin 3, @ite Nat (RawMaxErases
      ((u ++ physicalHeavy (List.ofFn (fun i => (c i,e i)))) ++ v) [])
      (Classical.propDecidable _) 1 0) = fixedExteriorRec m (exteriorTargets u v) := by
  rw [← target_union_count_recurrence]
  unfold scheduleUnionCount
  apply Finset.sum_congr rfl
  intro c _
  have hw := exterior_targets_win_iff u v (List.ofFn (fun i => (c i,e i)))
  have eq : RawMaxErases ((u ++ physicalHeavy (List.ofFn (fun i => (c i,e i)))) ++ v) [] ↔
      targetHit (exteriorTargets u v) (List.ofFn c) := by
    simpa only [List.map_ofFn,Function.comp_def] using hw
  by_cases hits : targetHit (exteriorTargets u v) (List.ofFn c)
  · rw [if_pos (eq.mpr hits),if_pos hits]
  · rw [if_neg (fun h => hits (eq.mp h)),if_neg hits]

/-- Residual target after a full schedule. -/
def routeResidual {q : Nat} (w p : List (Fin q)) : List (Fin q) :=
  w.foldl (fun r a => advanceRoute a r) p

private theorem residualSuffix {q : Nat} (w p : List (Fin q)) :
    (routeResidual w p).IsSuffix p := by
  induction w generalizing p with
  | nil => exact ⟨[],rfl⟩
  | cons a w ih =>
    change (routeResidual w (advanceRoute a p)).IsSuffix p
    apply (ih _).trans
    cases p with
    | nil => exact ⟨[],rfl⟩
    | cons b p =>
      by_cases h : b=a
      · simp [advanceRoute,h]
      · simp [advanceRoute,h]

theorem iterated_target_transition {q : Nat} (w : List (Fin q)) (ps : List (List (Fin q))) :
    w.foldl (fun state a => state.map (advanceRoute a)) ps = ps.map (routeResidual w) := by
  induction w generalizing ps with
  | nil => change ps = ps.map id; simp
  | cons a w ih =>
    rw [List.foldl_cons,ih,List.map_map]
    rfl

/-- Explicit finite family of target-list states indexed by residual suffixes. -/
def suffixStates {q : Nat} : List (List (Fin q)) → List (List (List (Fin q)))
  | [] => [[]]
  | p::ps => p.tails.flatMap fun r => (suffixStates ps).map (r::·)

theorem residual_state_in_family {q : Nat} (w : List (Fin q)) (ps : List (List (Fin q))) :
    ps.map (routeResidual w) ∈ suffixStates ps := by
  induction ps with
  | nil => simp [suffixStates]
  | cons p ps ih =>
    apply List.mem_flatMap.mpr
    exact ⟨routeResidual w p,(List.mem_tails _ _).mpr (residualSuffix _ _),
      List.mem_map.mpr ⟨_,ih,rfl⟩⟩

theorem suffix_state_family_size {q : Nat} (ps : List (List (Fin q))) :
    (suffixStates ps).length = (ps.map (fun p => p.length+1)).prod := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    simp [suffixStates,List.length_flatMap,ih,List.map_const',List.length_tails]

end LC004
