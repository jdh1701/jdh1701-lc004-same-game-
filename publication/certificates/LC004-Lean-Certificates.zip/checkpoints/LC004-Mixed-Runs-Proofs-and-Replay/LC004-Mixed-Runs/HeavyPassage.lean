import ProperCore

namespace LC004

/-- Move along the unique stack edge carrying color a. -/
def edgeFlip {q : Nat} (a : Fin q) (s : List (Fin q)) : List (Fin q) :=
  if s.head? = some a then s.tail else a::s

private theorem flipProper {q : Nat} (a : Fin q) (s : List (Fin q)) (hs : FusionProper s) :
    FusionProper (edgeFlip a s) := by
  by_cases h : s.head? = some a
  · obtain ⟨v,rfl⟩ := List.head?_eq_some_iff.mp h
    simpa [edgeFlip] using hs.2
  · simpa [edgeFlip,h] using (show FusionProper (a::s) from ⟨h,hs⟩)

private theorem flipTwice {q : Nat} (a : Fin q) (s : List (Fin q)) (hs : FusionProper s) :
    edgeFlip a (edgeFlip a s) = s := by
  by_cases h : s.head? = some a
  · obtain ⟨v,rfl⟩ := List.head?_eq_some_iff.mp h
    simp [edgeFlip,hs.1]
  · simp [edgeFlip,h]

private theorem stayBefore {q : Nat} (a : Fin q) (s : List (Fin q)) (n : Nat)
    {w t : List (Fin q)} (h : FusionEval (a::s) w t) :
    FusionEval (a::s) (List.replicate n a ++ w) t := by
  induction n with
  | zero => exact h
  | succ n ih => simpa [List.replicate_succ] using FusionEval.stay a ih

private theorem monoEndpoints {q : Nat} (a : Fin q) (n : Nat) (s t : List (Fin q))
    (hs : FusionProper s) (ev : FusionEval s (List.replicate n a) t) :
    t=s ∨ t=edgeFlip a s := by
  induction n generalizing s with
  | zero => cases ev; exact Or.inl rfl
  | succ n ih =>
    rw [List.replicate_succ] at ev
    cases ev with
    | push _ hn e =>
      simpa [edgeFlip,hn, or_comm] using ih (a::_) ⟨hn,hs⟩ e
    | pop _ e =>
      simpa [edgeFlip,hs.1, or_comm] using ih _ hs.2 e
    | stay _ e => exact ih _ hs e

/-- A heavy block may remain at its incoming proper stack or traverse one edge. -/
theorem heavy_block_endpoints {q : Nat} (a : Fin q) (n : Nat) (s t : List (Fin q))
    (hs : FusionProper s) :
    FusionEval s (List.replicate (n+2) a) t ↔ t=s ∨ t=edgeFlip a s := by
  refine ⟨monoEndpoints _ _ _ _ hs,?_⟩
  intro h
  by_cases top : s.head?=some a
  · obtain ⟨v,rfl⟩ := List.head?_eq_some_iff.mp top
    rcases h with rfl | rfl
    · simpa using stayBefore a v (n+2) (FusionEval.done _)
    · rw [List.replicate_succ']
      simpa [edgeFlip] using stayBefore a v (n+1) (FusionEval.pop a (FusionEval.done _))
  · rcases h with rfl | rfl
    · rw [List.replicate_succ,List.replicate_succ']
      exact FusionEval.push a top (stayBefore a _ n (FusionEval.pop a (FusionEval.done _)))
    · rw [List.replicate_succ]
      apply FusionEval.push a top
      simpa [edgeFlip,top] using stayBefore a s (n+1) (FusionEval.done _)

/-- The reduced edge word from s to t, with stacks stored top first. -/
def stackRoute {q : Nat} (s t : List (Fin q)) : List (Fin q) := s.foldr edgeFlip t.reverse

private theorem foldProper {q : Nat} (l x : List (Fin q)) (hx : FusionProper x) :
    FusionProper (l.foldr edgeFlip x) := by
  induction l with
  | nil => exact hx
  | cons a l ih => exact flipProper _ _ ih

private theorem foldInject {q : Nat} (l x y : List (Fin q)) (hx : FusionProper x)
    (hy : FusionProper y) (h : l.foldr edgeFlip x = l.foldr edgeFlip y) : x=y := by
  induction l with
  | nil => exact h
  | cons a l ih =>
    apply ih
    have hh := congrArg (edgeFlip a) h
    simpa only [List.foldr_cons,flipTwice a _ (foldProper l x hx),
      flipTwice a _ (foldProper l y hy)] using hh

private theorem routeSelf {q : Nat} (s : List (Fin q)) : stackRoute s s=[] := by
  induction s using List.reverseRecOn with
  | nil => rfl
  | append_singleton s a ih => simpa [stackRoute,List.foldr_append,edgeFlip] using ih

private theorem routeZero {q : Nat} (s t : List (Fin q)) (hs : FusionProper s) (ht : FusionProper t) :
    stackRoute s t = [] ↔ s=t := by
  constructor
  · intro h
    have e := foldInject s t.reverse s.reverse (proper_reverse_for_route _ ht) (proper_reverse_for_route _ hs)
      (h.trans (routeSelf s).symm)
    simpa using (congrArg List.reverse e.symm)
  · rintro rfl; exact routeSelf _

private theorem routeFlip {q : Nat} (a : Fin q) (s t : List (Fin q)) (ht : FusionProper t) :
    stackRoute (edgeFlip a s) t = edgeFlip a (stackRoute s t) := by
  by_cases h : s.head?=some a
  · obtain ⟨v,rfl⟩ := List.head?_eq_some_iff.mp h
    have hv := flipTwice a _ (foldProper v t.reverse (proper_reverse_for_route _ ht))
    simpa [stackRoute,edgeFlip] using hv.symm
  · simp [edgeFlip,h,stackRoute]

private theorem flipSub {q : Nat} (a : Fin q) (s l : List (Fin q)) (h : (edgeFlip a s).Sublist l) :
    s.Sublist (a::l) := by
  by_cases top : s.head? = some a
  · obtain ⟨v,rfl⟩ := List.head?_eq_some_iff.mp top
    exact (show v.Sublist l from by simpa [edgeFlip] using h).cons₂ a
  · have ha : (a::s).Sublist l := by simpa [edgeFlip,top] using h
    exact ((List.sublist_cons_self a s).trans ha).cons a

/-- Heavy blocks listed in physical reading order; each natural number is
the block length minus two. -/
def physicalHeavy {q : Nat} : List (Fin q × Nat) → List (Fin q)
  | [] => []
  | (a,e)::h => List.replicate (e+2) a ++ physicalHeavy h

/-- Exact transition relation between arbitrary proper stacks through a heavy region. -/
theorem heavy_passage_iff {q : Nat} (h : List (Fin q × Nat)) (s t : List (Fin q))
    (hs : FusionProper s) (ht : FusionProper t) :
    FusionEval s (physicalHeavy h) t ↔ (stackRoute s t).Sublist (h.map Prod.fst) := by
  induction h generalizing s with
  | nil =>
    constructor
    · intro ev; cases ev; simp [routeSelf]
    · intro sub
      have eq := (routeZero s t hs ht).mp (List.sublist_nil.mp sub)
      subst t; exact FusionEval.done _
  | cons b h ih =>
    obtain ⟨a,e⟩ := b
    constructor
    · intro ev
      obtain ⟨u,hb,tail⟩ := fusionEval_split (show FusionEval s
        (List.replicate (e+2) a ++ physicalHeavy h) t from ev)
      rcases (heavy_block_endpoints _ _ _ _ hs).mp hb with rfl | rfl
      · exact ((ih _ hs).mp tail).cons a
      · apply flipSub
        rw [← routeFlip a s t ht]
        exact (ih _ (flipProper a s hs)).mp tail
    · intro sub
      rcases List.sublist_cons_iff.mp sub with skip | ⟨v,eq,rest⟩
      · exact fusionEval_append ((heavy_block_endpoints _ _ _ _ hs).mpr (Or.inl rfl)) ((ih _ hs).mpr skip)
      · apply fusionEval_append ((heavy_block_endpoints a e s _ hs).mpr (Or.inr rfl))
        apply (ih _ (flipProper a s hs)).mpr
        rw [routeFlip a s t ht,eq]
        simpa [edgeFlip] using rest

/-- Exact original-game criterion for a heavy middle and two proper flanks.
The physical left flank is the reversal of its top-first boundary stack. -/
theorem proper_flanks_heavy_iff {q : Nat} (h : List (Fin q × Nat)) (s t : List (Fin q))
    (hs : FusionProper s) (ht : FusionProper t) :
    RawMaxErases ((s.reverse ++ physicalHeavy h) ++ t) [] ↔
      (stackRoute s t).Sublist (h.map Prod.fst) := by
  rw [raw_max_win_append_proper_iff _ _ ht,mem_fusionReach_iff]
  constructor
  · intro ev
    obtain ⟨u,eu,et⟩ := fusionEval_split ev
    have eq := (proper_from_empty s.reverse _ (proper_reverse_for_route s hs)).mp eu
    simp only [List.reverse_reverse] at eq
    subst u
    exact (heavy_passage_iff h s t hs ht).mp et
  · intro seq
    apply fusionEval_append (fusionEval_reverse (fusionEval_pop_all s) hs)
    exact (heavy_passage_iff h s t hs ht).mpr seq

/-- For fixed proper flanks, the count over arbitrary ternary block assignments
depends only on the number of blocks and the length of their reduced route. -/
theorem proper_flanks_heavy_binomial (m : Nat) (e : Fin m → Nat) (s t : List (Fin 3))
    (hs : FusionProper s) (ht : FusionProper t) :
    (∑ v : Fin m → Fin 3, @ite Nat
      (RawMaxErases ((s.reverse ++ physicalHeavy (List.ofFn (fun i => (v i,e i)))) ++ t) [])
      (Classical.propDecidable _) 1 0) =
      if (stackRoute s t).length ≤ m then
        ∑ j ∈ Finset.range (m-(stackRoute s t).length+1), m.choose j * 2^j else 0 := by
  calc
    _ = scheduleHits m (stackRoute s t) := by
      unfold scheduleHits
      apply Finset.sum_congr rfl
      intro v _
      classical
      have hw := proper_flanks_heavy_iff (List.ofFn (fun i => (v i,e i))) s t hs ht
      simp only [hw,List.map_ofFn,Function.comp_def]
    _ = _ := by
      rw [scheduleHits_eq_tail,ternaryHitTail_closed]
      rfl

end LC004
