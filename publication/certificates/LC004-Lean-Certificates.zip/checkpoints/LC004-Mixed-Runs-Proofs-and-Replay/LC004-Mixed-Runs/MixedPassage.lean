import HeavyPassage

namespace LC004

/-- Input segments in physical reading order. A single letter permits a stay
only on a matching stack top. A heavy segment is a list of fixed long blocks. -/
inductive InputSegment (q : Nat) where
  | single (a : Fin q)
  | heavy (blocks : List (Fin q × Nat))

def segmentWord {q : Nat} : List (InputSegment q) → List (Fin q)
  | [] => []
  | .single a :: rest => a :: segmentWord rest
  | .heavy blocks :: rest => physicalHeavy blocks ++ segmentWord rest

/-- An exact relational test. Intermediate stacks are existential witnesses;
several may certify the same input. -/
def segmentPass {q : Nat} : List (InputSegment q) → List (Fin q) → List (Fin q) → Prop
  | [], s, t => s=t
  | .single a :: rest, s, t =>
      segmentPass rest (edgeFlip a s) t ∨ (s.head?=some a ∧ segmentPass rest s t)
  | .heavy blocks :: rest, s, t =>
      ∃ u, FusionProper u ∧ (stackRoute s u).Sublist (blocks.map Prod.fst) ∧ segmentPass rest u t

private theorem singleEval {q : Nat} (a : Fin q) (s w t : List (Fin q)) :
    FusionEval s (a::w) t ↔
      FusionEval (edgeFlip a s) w t ∨ (s.head?=some a ∧ FusionEval s w t) := by
  by_cases h : s.head?=some a
  · obtain ⟨u,rfl⟩ := List.head?_eq_some_iff.mp h
    simp [edgeFlip]
    constructor
    · intro ev
      cases ev with
      | push _ hn _ => exact (hn rfl).elim
      | pop _ e => exact Or.inl e
      | stay _ e => exact Or.inr e
    · rintro (e|e)
      · exact FusionEval.pop _ e
      · exact FusionEval.stay _ e
  · simp [edgeFlip,h]
    constructor
    · intro ev
      cases ev with
      | push _ _ e => exact e
      | pop _ _ => exact (h rfl).elim
      | stay _ _ => exact (h rfl).elim
    · exact FusionEval.push a h

theorem segmentPass_iff_fusionEval {q : Nat} (z : List (InputSegment q)) (s t : List (Fin q))
    (hs : FusionProper s) : segmentPass z s t ↔ FusionEval s (segmentWord z) t := by
  induction z generalizing s with
  | nil =>
    constructor
    · rintro rfl; exact FusionEval.done _
    · intro e; cases e; rfl
  | cons part rest ih =>
    cases part with
    | single a =>
      have step : FusionEval s [a] (edgeFlip a s) := (singleEval a s [] _).mpr (Or.inl (FusionEval.done _))
      change (_ ∨ _) ↔ FusionEval s (a::segmentWord rest) t
      rw [singleEval, ← ih s hs, ← ih (edgeFlip a s) (fusionEval_preserves_proper step hs)]
    | heavy blocks =>
      constructor
      · rintro ⟨u,hu,hb,hr⟩
        exact fusionEval_append ((heavy_passage_iff blocks s u hs hu).mpr hb) ((ih u hu).mp hr)
      · intro ev
        obtain ⟨u,eb,er⟩ := fusionEval_split
          (show FusionEval s (physicalHeavy blocks ++ segmentWord rest) t from ev)
        have hu := fusionEval_preserves_proper eb hs
        exact ⟨u,hu,(heavy_passage_iff blocks s u hs hu).mp eb,(ih u hu).mpr er⟩

theorem mixed_segments_win_iff {q : Nat} (z : List (InputSegment q)) :
    RawMaxErases (segmentWord z) [] ↔ segmentPass z [] [] := by
  rw [raw_max_win_iff_fusionEval,segmentPass_iff_fusionEval z [] [] trivial]

theorem segmentWord_all_singles {q : Nat} (w : List (Fin q)) :
    segmentWord (w.map InputSegment.single) = w := by
  induction w with
  | nil => rfl
  | cons a w ih => simpa [segmentWord] using congrArg (List.cons a) ih

/-- A heavy interval between arbitrary exterior words accepts the union of
the subsequence tests for the two finite boundary supports. -/
theorem heavy_middle_context_iff {q : Nat} (u v : List (Fin q)) (h : List (Fin q × Nat)) :
    RawMaxErases ((u ++ physicalHeavy h) ++ v) [] ↔
      ∃ s ∈ fusionReach [] u, ∃ t ∈ fusionReach [] v.reverse,
        (stackRoute s t).Sublist (h.map Prod.fst) := by
  rw [raw_max_win_append_iff_common_fusion_stack]
  constructor
  · rintro ⟨t,ht,hv⟩
    obtain ⟨s,es,em⟩ := fusionEval_split ((mem_fusionReach_iff _ _ _).mp ht)
    have hu := (mem_fusionReach_iff _ _ _).mpr es
    exact ⟨s,hu,t,hv,(heavy_passage_iff h s t (fusionReach_proper hu) (fusionReach_proper hv)).mp em⟩
  · rintro ⟨s,hu,t,hv,sub⟩
    exact ⟨t,(mem_fusionReach_iff _ _ _).mpr (fusionEval_append ((mem_fusionReach_iff _ _ _).mp hu)
      ((heavy_passage_iff h s t (fusionReach_proper hu) (fusionReach_proper hv)).mpr sub)),hv⟩

/-- Distinct boundary pairs with different one-letter routes accept the same
ternary word 001 | 0011 | 01122. The singleton letters at the two joins are genuine. -/
theorem mixed_pair_overlap_example :
    let left : List (Fin 3) := [0,0,1]
    let right : List (Fin 3) := [0,1,1,2,2]
    let colors : List (Fin 3) := [0,1]
    let accepts := fun s t => s ∈ fusionReach [] left ∧ t ∈ fusionReach [] right.reverse ∧
      (stackRoute s t).Sublist colors
    accepts [1] [0,1] ∧ accepts [1,0] [0] ∧
      stackRoute [1] ([0,1] : List (Fin 3)) = [0] ∧
      stackRoute [1,0] ([0] : List (Fin 3)) = [1] := by decide

end LC004
