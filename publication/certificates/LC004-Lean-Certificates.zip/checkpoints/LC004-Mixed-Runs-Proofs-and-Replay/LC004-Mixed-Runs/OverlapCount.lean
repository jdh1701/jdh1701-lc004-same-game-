import MixedPassage

namespace LC004

/-- A concrete mixed exterior reduces eight boundary pairs to two minimal targets. -/
theorem mixed_example_accept_iff (h : List (Fin 3 × Nat)) :
    RawMaxErases (([0,0,1] ++ physicalHeavy h) ++ [0,1,1,2,2]) [] ↔
      0 ∈ h.map Prod.fst ∨ 1 ∈ h.map Prod.fst := by
  let l : List (Fin 3) := [0,0,1]
  let r : List (Fin 3) := [0,1,1,2,2]
  change RawMaxErases ((l ++ physicalHeavy h) ++ r) [] ↔ _
  rw [heavy_middle_context_iff]
  have cover : ∀ s ∈ fusionReach [] l, ∀ t ∈ fusionReach [] r.reverse,
      [0].Sublist (stackRoute s t) ∨ [1].Sublist (stackRoute s t) := by decide
  constructor
  · rintro ⟨s,hs,t,ht,sub⟩
    rcases cover s hs t ht with h0|h1
    · exact Or.inl (List.singleton_sublist.mp (h0.trans sub))
    · exact Or.inr (List.singleton_sublist.mp (h1.trans sub))
  · rintro (h0|h1)
    · exact ⟨[1],by decide,[0,1],by decide,
        (show stackRoute [1] ([0,1] : List (Fin 3)) = [0] by decide) ▸ List.singleton_sublist.mpr h0⟩
    · exact ⟨[1,0],by decide,[0],by decide,
        (show stackRoute [1,0] ([0] : List (Fin 3)) = [1] by decide) ▸ List.singleton_sublist.mpr h1⟩

/-- For this exterior the only losing heavy-block assignment is all twos. -/
theorem mixed_example_fixed_lengths_count (m : Nat) (e : Fin m → Nat) :
    (∑ v : Fin m → Fin 3, @ite Nat (RawMaxErases
        (([0,0,1] ++ physicalHeavy (List.ofFn (fun i => (v i,e i)))) ++ [0,1,1,2,2]) [])
        (Classical.propDecidable _) 1 0) = 3^m - 1 := by
  classical
  let onlyTwo : Fin m → Fin 3 := fun _ => 2
  have good (v : Fin m → Fin 3) :
      RawMaxErases (([0,0,1] ++ physicalHeavy (List.ofFn (fun i => (v i,e i)))) ++ [0,1,1,2,2]) [] ↔
        v ≠ onlyTwo := by
    rw [mixed_example_accept_iff]
    simp only [List.map_ofFn, Function.comp_def, List.mem_ofFn]
    constructor
    · rintro (⟨i,hi⟩|⟨i,hi⟩) rfl <;> simp [onlyTwo] at hi
    · intro hn
      by_contra! none
      apply hn
      funext i
      have z := none.1 i
      have o := none.2 i
      change v i = 2
      generalize v i = a at z o ⊢
      fin_cases a <;> simp_all
  have total :
      (∑ v : Fin m → Fin 3, @ite Nat (RawMaxErases
        (([0,0,1] ++ physicalHeavy (List.ofFn (fun i => (v i,e i)))) ++ [0,1,1,2,2]) [])
        (Classical.propDecidable _) 1 0) +
      (∑ v : Fin m → Fin 3, if v=onlyTwo then 1 else 0) = ∑ _v : Fin m → Fin 3, (1:Nat) := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro v _
    simp only [good v]
    by_cases h : v=onlyTwo <;> simp [h]
  have ones : (∑ v : Fin m → Fin 3, if v=onlyTwo then 1 else 0 : Nat) = 1 := by simp
  have all : (∑ _v : Fin m → Fin 3, (1:Nat)) = 3^m := by simp
  rw [ones,all] at total
  omega

end LC004
