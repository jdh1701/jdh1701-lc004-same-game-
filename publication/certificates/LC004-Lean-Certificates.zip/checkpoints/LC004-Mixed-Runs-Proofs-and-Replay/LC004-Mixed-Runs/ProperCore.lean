import HeavySchedule

namespace LC004

private theorem properParts {q : Nat} (u v : List (Fin q)) (hp : FusionProper (u++v)) :
    FusionProper u ∧ FusionProper v := by
  induction u with
  | nil => exact ⟨trivial,hp⟩
  | cons a u ih =>
    obtain ⟨hu,hv⟩ := ih hp.2
    refine ⟨⟨?_,hu⟩,hv⟩
    cases u with
    | nil => simp
    | cons b t => exact hp.1

/-- A proper input whose first letter differs from the top forces only pushes. -/
theorem proper_forced_pushes {q : Nat} (a : Fin q) (s w t : List (Fin q))
    (hp : FusionProper w) (hn : w.head? ≠ some a) (ev : FusionEval (a::s) w t) :
    t = w.reverse ++ a::s := by
  induction w generalizing a s with
  | nil => cases ev; rfl
  | cons b w ih =>
    cases ev with
    | push _ _ e => simpa [List.reverse_cons,List.append_assoc] using ih b (a::s) hp.2 hp.1 e
    | pop _ _ => exact (hn rfl).elim
    | stay _ _ => exact (hn rfl).elim

/-- A proper input crossing any boundary is a subsequence of the incoming
stack followed by the reversal of the outgoing stack. -/
theorem proper_crossing_sublist {q : Nat} (w s t : List (Fin q)) (hp : FusionProper w)
    (ev : FusionEval s w t) : w.Sublist (s ++ t.reverse) := by
  induction w generalizing s with
  | nil => exact List.nil_sublist _
  | cons a w ih =>
    cases ev with
    | push _ _ e =>
      rw [proper_forced_pushes a _ w _ hp.2 hp.1 e]
      simp only [List.reverse_append,List.reverse_cons,List.reverse_reverse,List.append_assoc,
        List.singleton_append]
      exact List.sublist_append_right _ _ |>.trans (List.sublist_append_right _ _)
    | pop _ e => exact (ih _ hp.2 e).cons₂ a
    | stay _ e =>
      rw [proper_forced_pushes a _ w _ hp.2 hp.1 e]
      simp only [List.reverse_append,List.reverse_cons,List.reverse_reverse,List.append_assoc,
        List.singleton_append]
      exact List.sublist_append_right _ _ |>.trans (List.sublist_append_right _ _)

private theorem canPushProper {q : Nat} (w s : List (Fin q)) (hp : FusionProper w)
    (hn : ∀ a, w.head? = some a → s.head? ≠ some a) : FusionEval s w (w.reverse ++ s) := by
  induction w generalizing s with
  | nil => exact FusionEval.done _
  | cons a w ih =>
    simp only [List.reverse_cons,List.append_assoc,List.singleton_append]
    apply FusionEval.push a (hn a rfl)
    apply ih _ hp.2
    intro b hb eq
    have h : a = b := Option.some.inj eq
    exact hp.1 (h ▸ hb)

theorem proper_from_empty {q : Nat} (p t : List (Fin q)) (hp : FusionProper p) :
    FusionEval [] p t ↔ t=p.reverse := by
  constructor
  · intro ev
    cases p with
    | nil => cases ev; rfl
    | cons a p =>
      cases ev with
      | push _ _ e =>
        simpa [List.reverse_cons] using proper_forced_pushes a [] p t hp.2 hp.1 e
  · rintro rfl
    simpa using canPushProper p [] hp (by simp)

theorem proper_reverse_for_route {q : Nat} (s : List (Fin q)) (hs : FusionProper s) :
    FusionProper s.reverse :=
  fusionEval_preserves_proper ((proper_from_empty s _ hs).mpr rfl) trivial

private theorem coreSeam {q : Nat} (l p r : List (Fin q)) :
    RawMaxErases ((l++p)++r.reverse) [] ↔
    ∃ s t, s ∈ fusionReach [] l ∧ FusionEval s p t ∧ t ∈ fusionReach [] r := by
  rw [raw_max_win_append_iff_common_fusion_stack,List.reverse_reverse]
  constructor
  · rintro ⟨t,ht,hr⟩
    obtain ⟨s,hs,ht⟩ := fusionEval_split ((mem_fusionReach_iff _ _ _).mp ht)
    exact ⟨s,t,(mem_fusionReach_iff _ _ _).mpr hs,ht,hr⟩
  · rintro ⟨s,t,hs,hp,hr⟩
    exact ⟨t,(mem_fusionReach_iff _ _ _).mpr
      (fusionEval_append ((mem_fusionReach_iff _ _ _).mp hs) hp),hr⟩

/-- For heavy flanks enclosing any proper core, winning is one subsequence test. -/
theorem heavy_proper_core_iff {q : Nat} (l r : List (Fin q × Nat)) (p : List (Fin q))
    (hp : FusionProper p) :
    RawMaxErases ((heavySchedule l ++ p) ++ (heavySchedule r).reverse) [] ↔
      p.Sublist (l.map Prod.fst ++ (r.map Prod.fst).reverse) := by
  rw [coreSeam]
  constructor
  · rintro ⟨s,t,hs,ev,ht⟩
    have sl := ((heavySchedule_support_iff _ _).mp hs).2
    have tr := ((heavySchedule_support_iff _ _).mp ht).2
    exact (proper_crossing_sublist _ _ _ hp ev).trans (sl.append tr.reverse)
  · intro h
    obtain ⟨u,v,he,hu,hv⟩ := List.sublist_append_iff.mp h
    subst p
    obtain ⟨pu,pv⟩ := properParts u v hp
    have fromEmpty : FusionEval [] v v.reverse := by
      simpa using canPushProper v [] pv (by simp)
    refine ⟨u,v.reverse,(heavySchedule_support_iff _ _).mpr ⟨pu,hu⟩,
      fusionEval_append (fusionEval_pop_all _) fromEmpty,(heavySchedule_support_iff _ _).mpr ⟨?_,?_⟩⟩
    · exact fusionEval_preserves_proper fromEmpty trivial
    · simpa using hv.reverse

/-- Insert the proper core at a cut in the top-first matching schedule.
Within each physical flank the block colors are read in reverse matching order. -/
def splitHeavyCore {q : Nat} (h : List (Fin q × Nat)) (cut : Nat) (p : List (Fin q)) :
    List (Fin q) :=
  (heavySchedule (h.take cut) ++ p) ++ (heavySchedule (h.drop cut).reverse).reverse

theorem splitHeavyCore_win_iff {q : Nat} (h : List (Fin q × Nat)) (cut : Nat)
    (p : List (Fin q)) (hp : FusionProper p) :
    RawMaxErases (splitHeavyCore h cut p) [] ↔ p.Sublist (h.map Prod.fst) := by
  unfold splitHeavyCore
  rw [heavy_proper_core_iff _ _ _ hp]
  simp [List.map_reverse, ← List.map_append]

/-- An arbitrary interior cut leaves the fixed-profile ternary binomial count invariant. -/
theorem heavy_core_fixed_lengths_binomial (m cut : Nat) (e : Fin m → Nat)
    (p : List (Fin 3)) (hp : FusionProper p) :
    (∑ v : Fin m → Fin 3, @ite Nat
        (RawMaxErases (splitHeavyCore (List.ofFn (fun i => (v i,e i))) cut p) [])
        (Classical.propDecidable _) 1 0) =
      if p.length ≤ m then ∑ j ∈ Finset.range (m-p.length+1), m.choose j * 2^j else 0 := by
  calc
    _ = scheduleHits m p := by
      unfold scheduleHits
      apply Finset.sum_congr rfl
      intro v _
      classical
      have hw := splitHeavyCore_win_iff (List.ofFn (fun i => (v i,e i))) cut p hp
      simp only [hw,List.map_ofFn,Function.comp_def]
    _ = _ := by
      rw [scheduleHits_eq_tail, ternaryHitTail_closed]
      rfl

end LC004
