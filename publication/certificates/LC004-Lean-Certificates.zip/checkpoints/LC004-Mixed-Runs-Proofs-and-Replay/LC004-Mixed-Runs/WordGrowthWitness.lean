import LC004.FusionStack

namespace LC004

/-- Lexicographic list of all ternary words of the given length. -/
def growthWords : Nat → List (List (Fin 3))
  | 0 => [[]]
  | n+1 => ([0,1,2] : List (Fin 3)).flatMap fun a => (growthWords n).map (a::·)

def growthWinners (n : Nat) : List (List (Fin 3)) :=
  (growthWords n).filter fun w => decide ([] ∈ fusionReach [] w)

theorem growthWords_mem (n : Nat) (w : List (Fin 3)) : w ∈ growthWords n ↔ w.length=n := by
  induction n generalizing w with
  | zero => simp [growthWords]
  | succ n ih =>
    cases w with
    | nil => simp [growthWords]
    | cons a w => fin_cases a <;> simp [growthWords,ih]

theorem growthWinners_mem (n : Nat) (w : List (Fin 3)) :
    w ∈ growthWinners n ↔ w.length=n ∧ RawMaxErases w [] := by
  simp [growthWinners,growthWords_mem,raw_max_win_iff_fusionReach]

set_option maxRecDepth 20000 in
set_option maxHeartbeats 3000000 in
theorem six_word_witness : (growthWinners 6).toFinset.card = 105 := by decide

/-- Concatenation is safe even when the boundary letters agree. -/
theorem append_raw_winners {q : Nat} {u v : List (Fin q)}
    (hu : RawMaxErases u []) (hv : RawMaxErases v []) : RawMaxErases (u++v) [] :=
  (raw_max_win_iff_fusionEval _).mpr (fusionEval_append
    ((raw_max_win_iff_fusionEval _).mp hu) ((raw_max_win_iff_fusionEval _).mp hv))

def winnerSet (n : Nat) : Finset (List (Fin 3)) := (growthWinners n).toFinset

private theorem memWinner {n : Nat} {w : List (Fin 3)} :
    w ∈ winnerSet n ↔ w.length=n ∧ RawMaxErases w [] := by
  simp [winnerSet,growthWinners_mem]

theorem winner_count_supermultiplicative (m n : Nat) :
    (winnerSet m).card * (winnerSet n).card ≤ (winnerSet (m+n)).card := by
  let pairs := (winnerSet m).product (winnerSet n)
  let join := fun p : List (Fin 3) × List (Fin 3) => p.1 ++ p.2
  have inj : Set.InjOn join (↑pairs) := by
    intro x hx y hy eq
    have xm := memWinner.mp (Finset.mem_product.mp hx).1
    have ym := memWinner.mp (Finset.mem_product.mp hy).1
    have parts := List.append_inj eq (xm.1.trans ym.1.symm)
    exact Prod.ext parts.1 parts.2
  have sub : pairs.image join ⊆ winnerSet (m+n) := by
    intro w hw
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hw
    have a := memWinner.mp (Finset.mem_product.mp hp).1
    have b := memWinner.mp (Finset.mem_product.mp hp).2
    exact memWinner.mpr ⟨by simp [join,a.1,b.1],append_raw_winners a.2 b.2⟩
  have count := Finset.card_le_card sub
  rw [Finset.card_image_of_injOn inj] at count
  simpa [pairs] using count

theorem six_block_lower_bound (m : Nat) : 105^m ≤ (winnerSet (6*m)).card := by
  induction m with
  | zero => decide
  | succ m ih =>
    have six : (winnerSet 6).card = 105 := six_word_witness
    rw [pow_succ,Nat.mul_succ 6 m]
    calc
      _ ≤ (winnerSet (6*m)).card * (winnerSet 6).card := by
        rw [six]; exact Nat.mul_le_mul_right _ ih
      _ ≤ _ := winner_count_supermultiplicative _ _

end LC004
