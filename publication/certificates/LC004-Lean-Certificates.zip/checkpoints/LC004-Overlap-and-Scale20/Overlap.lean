import FiniteBlock
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
namespace LC004.RawGrowth

private def revVec {n : ℕ} (f : Fin n → Fin 3) (i : Fin n) :=
  (List.ofFn f).reverse.get (i.cast (by simp))

private theorem revVec_spec {n : ℕ} (f : Fin n → Fin 3) :
    List.ofFn (revVec f) = (List.ofFn f).reverse :=
  (List.ofFn_congr (show (List.ofFn f).reverse.length = n by simp)
      (List.ofFn f).reverse.get).symm.trans (List.ofFn_get _)

private abbrev PairWords (n : ℕ) := (Fin n → Fin 3) × (Fin n → Fin 3)

/-- An integer score may count multiple differently weighted shared stacks.
Positive mass requires at least one literal matching boundary. -/
theorem overlap_moments (n : ℕ) (score : PairWords n → ℕ)
    (sound : ∀ p, score p ≠ 0 → ∃ s, FusionEval [] (List.ofFn p.1) s ∧
                                        FusionEval [] (List.ofFn p.2) s) :
    (∑ p, score p)^2 ≤ labeledWinningCount 3 (n+n) * ∑ p, (score p)^2 := by
  classical
  let live := Finset.univ.filter (fun p => score p ≠ 0)
  let F (p : ↥live) : {w : Fin (n+n) → Fin 3 // RawMaxErases (List.ofFn w) []} :=
    ⟨Fin.append p.val.1 (revVec p.val.2), by
      have hl : score p.val ≠ 0 := (Finset.mem_filter.mp p.property).2
      obtain ⟨s,h,g⟩ := sound p.val hl
      rw [List.ofFn_fin_append,revVec_spec,raw_max_win_iff_fusionEval]
      exact fusionEval_append h (fusionEval_reverse g trivial)⟩
  have inj : Function.Injective F := by
    intro p q h
    apply Subtype.ext
    apply Prod.ext
    · funext i
      simpa only [F,Fin.append_left] using congrArg (fun w => w.val (Fin.castAdd n i)) h
    · have e : revVec p.val.2 = revVec q.val.2 := by
        funext i
        simpa only [F,Fin.append_right] using congrArg (fun w => w.val (Fin.natAdd n i)) h
      have g := congrArg List.reverse (congrArg List.ofFn e)
      simpa [revVec_spec] using g
  have upper : live.card ≤ labeledWinningCount 3 (n+n) := by
    simpa [Nat.card_eq_fintype_card,labeledWinningCount] using Nat.card_le_card_of_injective F inj
  have cs := Finset.sum_mul_sq_le_sq_mul_sq (s := live) (fun _ => (1:ℕ)) score
  have same₁ : (∑ p ∈ live,score p) = ∑ p,score p := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro p _ hp
    simpa [live] using hp
  have same₂ : (∑ p ∈ live, (score p)^2) = ∑ p,(score p)^2 := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro p _ hp
    have e : score p = 0 := by simpa [live] using hp
    simp [e]
  have bound : (∑ p, score p)^2 ≤ live.card * ∑ p, (score p)^2 := by
    simpa [same₁,same₂] using cs
  exact bound.trans (Nat.mul_le_mul_right _ upper)

private theorem gram_first {X I : Type} [Fintype X] [Fintype I]
    (w : X → I → ℕ) :
    (∑ p : X × X, ∑ i, w p.1 i * w p.2 i) = ∑ i, (∑ x, w x i)^2 := by
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  rw [sq,Finset.sum_mul,Fintype.sum_prod_type]
  simp_rw [Finset.mul_sum]

private theorem gram_second {X I : Type} [Fintype X] [Fintype I]
    (w : X → I → ℕ) :
    (∑ p : X × X, (∑ i, w p.1 i * w p.2 i)^2) =
      ∑ ij : I × I, (∑ x, w x ij.1 * w x ij.2)^2 := by
  rw [← gram_first (fun x (ij : I × I) => w x ij.1 * w x ij.2)]
  apply Finset.sum_congr rfl
  intro p _
  rw [sq,Finset.sum_mul,Fintype.sum_prod_type]
  simp_rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  ring

/-- Half-word marginal counts and two-stack joint counts suffice for a
sound lower bound on distinct winning words. Scores are arbitrary natural
weights that vanish when the literal stack cannot be reached. -/
theorem halfword_gram (n : ℕ) {I : Type} [Fintype I] (stack : I → List (Fin 3))
    (w : (Fin n → Fin 3) → I → ℕ)
    (valid : ∀ x i, w x i ≠ 0 → FusionEval [] (List.ofFn x) (stack i)) :
    (∑ i, (∑ x, w x i)^2)^2 ≤ labeledWinningCount 3 (n+n) *
      ∑ ij : I × I, (∑ x, w x ij.1 * w x ij.2)^2 := by
  classical
  rw [← gram_first w,← gram_second w]
  apply overlap_moments
  intro p hn
  by_contra! no
  apply hn
  apply Finset.sum_eq_zero
  intro i _
  by_cases h : w p.1 i = 0
  · simp [h]
  · have h₂ : w p.2 i = 0 := by
      by_contra bad
      exact no (stack i) (valid _ _ h) (valid _ _ bad)
    simp [h₂]

/-- B dictionary entries with overlap score at most K give an incidence
bound. For binary incidence and k chosen entries per covered prefix, this
improves A² ≤ B W to A² k ≤ B W. -/
theorem dictionary_mass (n : ℕ) {I : Type} [Fintype I] (stack : I → List (Fin 3))
    (w : (Fin n → Fin 3) → I → ℕ)
    (valid : ∀ x i, w x i ≠ 0 → FusionEval [] (List.ofFn x) (stack i))
    (K : ℕ) (cap : ∀ p : PairWords n, (∑ i, w p.1 i * w p.2 i) ≤ K) :
    (∑ x, ∑ i, w x i)^2 ≤ Fintype.card I * (K * labeledWinningCount 3 (n+n)) := by
  classical
  let score (p : PairWords n) := ∑ i, w p.1 i * w p.2 i
  have sound (p) (hn : score p ≠ 0) : ∃ s, FusionEval [] (List.ofFn p.1) s ∧
      FusionEval [] (List.ofFn p.2) s := by
    by_contra! no
    apply hn
    apply Finset.sum_eq_zero
    intro i _
    by_cases h : w p.1 i = 0
    · simp [h]
    · have h₂ : w p.2 i = 0 := by
        by_contra bad
        exact no (stack i) (valid _ _ h) (valid _ _ bad)
      simp [h₂]
  have mom := overlap_moments n score sound
  have hi : (∑ p, score p^2) ≤ K * ∑ p, score p := by
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum fun p _ => by rw [sq]; exact Nat.mul_le_mul_right _ (cap p)
  have lin : (∑ p, score p) ≤ K * labeledWinningCount 3 (n+n) := by
    by_cases h : (∑ p, score p) = 0
    · simp [h]
    · have e := mom.trans (Nat.mul_le_mul_left _ hi)
      rw [sq,←Nat.mul_assoc,Nat.mul_comm (labeledWinningCount 3 (n+n)) K] at e
      exact Nat.le_of_mul_le_mul_right e (Nat.pos_of_ne_zero h)
  have cs := Finset.sum_mul_sq_le_sq_mul_sq (s := Finset.univ)
    (fun _ : I => (1:ℕ)) (fun i => ∑ x, w x i)
  rw [Finset.sum_comm]
  have count : (∑ i, ∑ x, w x i)^2 ≤ Fintype.card I * (∑ i, (∑ x, w x i)^2) := by simpa using cs
  apply count.trans
  apply Nat.mul_le_mul_left
  simpa only [score,gram_first] using lin

#print axioms dictionary_mass
#print axioms halfword_gram
#print axioms overlap_moments
end LC004.RawGrowth
