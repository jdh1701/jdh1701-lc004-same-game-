import PolicyBounds
#print axioms LC004.fusion_one_letter_lift
#print axioms LC004.retained_move_lift
#print axioms LC004.residual_obstruction
#print axioms LC004.primal_decimal
#print axioms LC004.dual_decimal
#print axioms LC004.fusion_relabel
#print axioms LC004.context_decimal
