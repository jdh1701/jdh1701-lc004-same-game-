import LC004
import Lean.Util.FoldConsts
import Lean.Util.CollectAxioms

open Lean Elab Command in
set_option maxHeartbeats 0 in
run_cmd do
  let env ← getEnv
  let selected : List String := [
    "LC004.raw_max_win_iff_certificate",
    "LC004.labeledWinningCount_signed_joins",
    "LC004.winningJoinCoefficient_incidence",
    "LC004.winningJoinCoefficient_noncrossing_product",
    "LC004.noncrossingClosure_eq_iff_regions_connected",
    "LC004.weighted_connected_fiber_product",
    "LC004.labeledWinningCount_connected_expansion",
    "LC004.ncConnected_every_class_crossed",
    "LC004.join_small_class_no_cross",
    "LC004.four_gap_indicator_below",
    "LC004.winningJoinCoefficient_crossed_four_zero",
    "LC004.winningJoinCoefficient_nonzero_crossed_min_five",
    "LC004.ncConnected_nonzero_every_class_min_five",
    "LC004.connectedGamePolynomial_coeff_zero",
    "LC004.connectedGamePolynomial_natDegree_le",
    "LC004.connectedGamePolynomial_constant_zero",
    "LC004.connectedGamePolynomial_eval",
    "LC004.connectedGameWeight_binary_interpolation",
    "LC004.connectedGameWeight_ternary_cubic_correction",
    "LC004.ncConnected_nonzero_threshold_all_five",
    "LC004.connectedClassCoefficient_first_excess",
    "LC004.winningJoinCoefficient_five_original_law",
    "LC004.raw_max_win_iff_fusionEval",
    "LC004.raw_max_win_append_iff_common_fusion_stack",
    "LC004.fusionTrim_eq_iff_bounded_continuations",
    "LC004.winningColorPatternCount_second_diagonal",
    "LC004.winning_iff_heavy_face_decomposition",
    "LC004.unconditional_executable_unique_first_iff_path",
    "LC004.unconditional_unique_choice_iff_unique_path",
    "LC004.winningJoinCoefficient_eq_class_cut_face_sum",
    "LC004.winningJoinCoefficient_five_rows_class_cuts"]
  let mut project : NameSet := {}
  for (owner, data) in env.header.moduleNames.zip env.header.moduleData do
    if owner == `LC004 || (`LC004).isPrefixOf owner then
      for info in data.constants do
        if !info.isUnsafe && !info.isPartial then
          project := project.insert info.name
  for name in project do
    let some info := env.find? name | continue
    let some owner ← findModuleOf? name | continue
    let mut strs : Array String := #[]
    for dep in info.getUsedConstantsAsSet do
      if project.contains dep then strs := strs.push dep.toString
    let mut axText := "-"
    if selected.contains name.toString then
      let axioms ← collectAxioms name
      axText := String.intercalate "|" (axioms.toList.map fun n => n.toString)
    IO.println (String.intercalate "\t" [name.toString, owner.toString, String.intercalate "|" strs.toList, axText])
