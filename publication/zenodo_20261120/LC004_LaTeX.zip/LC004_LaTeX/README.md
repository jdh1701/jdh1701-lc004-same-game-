# Editable LC004 manuscripts

From the unpacked LC004_LaTeX directory, run:

~~~sh
sh scripts/build_pdfs.sh ./papers
~~~

Requires pdfLaTeX, latin modern fonts, latexmk and BibTeX with standard TeX Live mathematics and typesetting packages. The two entrance files are manuscripts/LC004_Comprehensive.tex and manuscripts/LC004_Concise.tex. Both read manuscripts/shared.bib, abstract.tex, core.tex, the worked figure and application.tex. The archival register and coefficient tables are already typeset in the included source fragments. To regenerate the tables, rebuild the formal source indexes or replay the calculations use LC004_Reproducibility.zip.

Version 1.0-draft, 19 November 2026. The two papers report the same contribution.
