#!/bin/sh
set -eu
root=$(CDPATH='' cd -- "$(dirname -- "$0")/.." && pwd)
destination=$root/papers
if [ "$#" -gt 0 ]; then
  mkdir -p "$1"
  destination=$(CDPATH='' cd -- "$1" && pwd)
fi
mkdir -p "$destination"
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT HUP INT TERM
# A fixed timestamp also fixes ordinary LaTeX date and trailer metadata.
export SOURCE_DATE_EPOCH=1795132800 FORCE_SOURCE_DATE=1 TZ=UTC
cd "$root/manuscripts"
for title in LC004_Comprehensive LC004_Concise; do
  mkdir -p "$work/$title"
  latexmk -pdf -file-line-error -interaction=nonstopmode -halt-on-error \
    -outdir="$work/$title" "$title.tex"
  cp "$work/$title/$title.pdf" "$destination/$title.pdf"
done
