import sys,itertools,functools,collections,time,json
sys.path.insert(0,'research/global_fusion_20261101')
from fusion import step
ps=tuple(itertools.permutations(range(3)))
@functools.lru_cache(None)
def canonical(S):
    return min(tuple(sorted(tuple(p[a] for a in s) for s in S)) for p in ps)
@functools.lru_cache(None)
def futures(S,r):
    S=tuple(s for s in S if len(s)<=r)
    if r==0:return int(() in S)
    if not S:return 0
    return sum(futures(canonical(tuple(sorted(s for s in step(S,a) if len(s)<r))),r-1) for a in range(3))
cur={((),)}
rows=[]
for m in range(7):
    if m:cur={canonical(tuple(sorted(step(S,a)))) for S in cur for a in range(3)}
    start=time.monotonic();groups=collections.defaultdict(set)
    for S in cur:
        v=tuple(futures(S,r) for r in range(m+9));D=canonical(tuple(sorted(s[::-1] for s in S)))
        groups[v].add(min(S,D))
    assert all(len(v)==1 for v in groups.values())
    vectors=groups
    row={'prefix_length':m,'support_orbits':len(cur),'suffix_lengths_through':m+8,'count_vectors':len(vectors),'each_group_one_reversal_orbit':True,'cache':futures.cache_info().currsize,'seconds':time.monotonic()-start};rows.append(row);print(row,flush=True)
    open('/tmp/lc004-average-residual.json','w').write(json.dumps(rows,indent=2)+'\n')
